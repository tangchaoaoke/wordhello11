package com.movie58.http;

import com.movie58.util.FastJsonUtil;
import com.movie58.util.LogUtil;
import com.orhanobut.logger.Logger;
import com.yanzhenjie.kalle.Response;
import com.yanzhenjie.kalle.simple.Converter;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.lang.reflect.Type;

/**
 * Created by yangxing on 2018/10/9 0009.
 */
public class JsonConverter implements Converter {

    @Override
    public <S, F> SimpleResponse<S, F> convert(Type succeed, Type failed, Response response, boolean fromCache) throws Exception {
        S succeedData = null; // The data when the business successful.
        F failedData = null; // The data when the business failed.

        int code = response.code();
        String serverJson = response.body().string();
        LogUtil.d("Server Data: " + serverJson);
        Logger.json(serverJson);
        if (code >= 200 && code < 300) { // Http is successful.
            HttpEntity httpEntity;
            try {
                httpEntity = FastJsonUtil.toBean(serverJson, HttpEntity.class);
            } catch (Exception e) {
                httpEntity = new HttpEntity();
                httpEntity.setCode(0);
                httpEntity.setMsg("请求失败");
            }

            if (httpEntity.getCode() == 1) {
                try {
                    succeedData = FastJsonUtil.toBean(httpEntity.getData(), succeed);
                } catch (Exception e) {
                    failedData = (F) "服务器数据格式错误";
                }
            }else {
                failedData = (F) httpEntity.getMsg();
            }

        } else if (code >= 400 && code < 500) {
            failedData = (F) "未知服务异常";
        } else if (code >= 500) {
            failedData = (F) "服务器开小差啦";
        }

        return SimpleResponse.<S, F>newBuilder()
                .code(response.code())
                .headers(response.headers())
                .fromCache(fromCache)
                .succeed(succeedData)
                .failed(failedData)
                .build();
    }
}
