package com.movie58.newdemand.interfaces;

import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.net.ApiTool;
import com.movie58.account.Account;
import com.movie58.http.HttpUrl;

import org.xutils.http.RequestParams;

public class Other {


    //片单导航栏
    public void d(ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "setting/setting/getAppInfo");
        if (Account.getInstance().isLogined()) {
            params.addHeader("XX-Token", Account.getInstance().getToken());
        }
        params.addHeader("XX-Device-Type", "android");
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "getAppInfo");
    }

    //片单导航栏
    public void c(String rule_id, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/task_center/getGoldReward");
        if (Account.getInstance().isLogined()) {
            params.addHeader("XX-Token", Account.getInstance().getToken());
        }
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("rule_id", rule_id);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "getGoldReward");
    }

}
