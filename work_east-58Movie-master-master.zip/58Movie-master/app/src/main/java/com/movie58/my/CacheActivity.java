package com.movie58.my;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.DownloadInfo;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/8/5 0005.
 */
public class CacheActivity extends BaseUseActivity {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvEdit;
    @BindView(R.id.layout_tab)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp)
    ViewPager vp;

    private String[] mTitles = new String[]{"正在缓存", "已缓存"};

    @Override
    protected void initView() {

        tvTitle.setText("离线缓存");
        tvEdit.setText("编辑");
        tvEdit.setVisibility(View.GONE);

        List<DownloadInfo> list = (List<DownloadInfo>) getIntent().getSerializableExtra("cache");


        ArrayList<Fragment> fragments = new ArrayList<>();

        fragments.add(CacheFragment.newInstance(list));
        fragments.add(CacheFragment1.newInstance());

        layoutTab.setViewPager(vp, mTitles, CacheActivity.this, fragments);

        vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
//                selPos = i;
//                tvEdit.setText("编辑");
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
//                selPos = position;
//                tvEdit.setText("编辑");
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void click(View v){
        switch (v.getId()){
            case  R.id.iv_back:
                finish();
                break;
            case R.id.tv_right:

                break;
        }
    }


    @Override
    protected int getLayout() {
        return R.layout.activity_collect;
    }
}
