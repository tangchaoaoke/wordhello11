package com.movie58.newdemand.ui.tscreen;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.core.BottomPopupView;
import com.lxj.xpopup.util.XPopupUtils;
import com.movie58.R;
import com.movie58.bean.DetailInfo;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;
import com.yqritc.recyclerviewflexibledivider.VerticalDividerItemDecoration;

import java.util.List;

/**
 * Created by yangxing on 2019/5/20 0020.
 */
public class MovieMore2Dialog extends BottomPopupView {

    ImageView ivClose;
    TextView tvCount;
    RecyclerView rvList;

    DetailInfo detailInfo;

    public MovieMore2Dialog(@NonNull Context context, DetailInfo detailInfo) {
        super(context);
        this.detailInfo = detailInfo;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_detail_more;
    }

    @Override
    protected void onCreate() {
        super.onCreate();

        ivClose = findViewById(R.id.iv_close);
        tvCount = findViewById(R.id.tv_count);
        rvList = findViewById(R.id.rv_list);

        if (detailInfo.getUpdate_schedule() == 1) {
            if ("综艺".equals(detailInfo.getCat_name())) {
                tvCount.setText("已完结" + detailInfo.getSource_content().size() + "期");
            } else {
                tvCount.setText("已完结" + detailInfo.getSource_content().size() + "集");
            }

        } else {
            if ("综艺".equals(detailInfo.getCat_name())) {
                tvCount.setText("更新至" + detailInfo.getSource_content().get(detailInfo.getSource_content().size() - 1).getPlay_title());
            } else {
                tvCount.setText("更新至" + detailInfo.getSource_content().get(detailInfo.getSource_content().size() - 1).getPlay_title() + "集");
            }
        }

        XuanjiAdapter adapter = new XuanjiAdapter(detailInfo.getSource_content());
        if ("综艺".equals(detailInfo.getCat_name())) {
            rvList.setLayoutManager(new GridLayoutManager(getContext(), 2));
        } else {
            rvList.setLayoutManager(new GridLayoutManager(getContext(), 4));
        }
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getContext())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getContext().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        rvList.addItemDecoration(new VerticalDividerItemDecoration.Builder(getContext())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getContext().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        adapter.bindToRecyclerView(rvList);
        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                for (DetailInfo.SourceContentBean bean : detailInfo.getSource_content()) {
                    bean.setCheck(false);
                }
                if (anInterface != null) {
                    anInterface.select(position);
                }
                detailInfo.getSource_content().get(position).setCheck(true);
                adapter.notifyDataSetChanged();
//                EventBus.getDefault().post(new Event(Event.CODE_08_SCHOOL_SEARCH).setObj1(position));
                dismiss();
            }
        });

        ivClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }


    public interface IndexMovieMore2DialogInterface {
        void select(int index);
    }

    private IndexMovieMore2DialogInterface anInterface;

    public void setIndexMovieMore2DialogInterface(IndexMovieMore2DialogInterface anInterface) {
        this.anInterface = anInterface;
    }

    @Override
    protected int getMaxHeight() {
        return (int) (XPopupUtils.getWindowHeight(getContext()) * .60f);
    }

    private class XuanjiAdapter extends BaseQuickAdapter<DetailInfo.SourceContentBean, BaseViewHolder> {

        public XuanjiAdapter(@Nullable List<DetailInfo.SourceContentBean> data) {
            super(R.layout.item_xuanji, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, DetailInfo.SourceContentBean item) {
            if (item.isCheck()) {
                helper.setChecked(R.id.rb_xuanji, true);
            } else {
                helper.setChecked(R.id.rb_xuanji, false);
            }
            helper.setText(R.id.rb_xuanji, item.getPlay_title());
        }
    }
}
