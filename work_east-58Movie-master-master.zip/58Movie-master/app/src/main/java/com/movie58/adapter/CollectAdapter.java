package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.widget.CompoundButton;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.CollectInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/5/10 0010.
 */
public class CollectAdapter extends BaseQuickAdapter<CollectInfo, BaseViewHolder> {

    boolean isEdit = false;
    int catId;

    public CollectAdapter(@Nullable List<CollectInfo> data, int catId) {
        super(R.layout.item_collect, data);
        this.catId = catId;
    }

    public void edit(boolean edit){
        isEdit = edit;
        if (!isEdit) {
            for(CollectInfo info : getData()){
                info.setCheck(false);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, CollectInfo item) {
        helper.setText(R.id.tv_name, item.getSource_name());
        ImageView ivImg = helper.getView(R.id.iv_player);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
        helper.addOnClickListener(R.id.iv_share);
        if (isEdit) {
            helper.setGone(R.id.cb, true);
        }else{

            helper.setGone(R.id.cb, false);
        }
        helper.setChecked(R.id.cb, item.isCheck());
        helper.setOnCheckedChangeListener(R.id.cb, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                item.setCheck(isChecked);
            }
        });
    }
}
