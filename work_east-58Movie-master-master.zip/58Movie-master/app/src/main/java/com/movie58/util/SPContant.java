package com.movie58.util;

/**
 * Created by yangxing on 2019/5/12 0012.
 */
public class SPContant {

    public static String CACHE_100 = "cache_100";
    public static String CACHE_34 = "cache_34";
    public static String PHONE = "phone";
    public static String TOKEN = "token";
    public static String USER_ID = "user_id";
    public static String USER_NAME = "user_name";
    public static String AVATAR = "avatar";
    public static String SEX = "sex";
    public static String LEVEL = "level";
    public static String GOLD = "gold";
    public static String INVITE_CODE = "inviteCode";
    public static String PLAY_HISTORY = "history";
    public static String LOGIN_SUC = "login_suc";
    public static String PLAY_PROGRESS = "progress";
    public static String PLAY_30 = "player_30";
    public static String SPLASH_IMAGE = "splash_image";
    public static String WELCOME_IMAGE = "welcome_image";
    public static String MOBILE = "mobile";
}
