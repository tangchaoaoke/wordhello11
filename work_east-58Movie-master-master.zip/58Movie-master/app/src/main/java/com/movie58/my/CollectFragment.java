package com.movie58.my;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;

import com.allen.library.SuperButton;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.CollectAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.CollectInfo;
import com.movie58.event.Event;
import com.movie58.home.MovieDetailActivity;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/6 0006.
 */
public class CollectFragment extends BaseFragment {


    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.btn_del)
    SuperButton btnDel;
    @BindView(R.id.btn_all)
    SuperButton btnAll;
    @BindView(R.id.layout_bottom)
    RelativeLayout layoutBottom;


    int catId;

    CollectAdapter mAdapter;

    boolean isEdit;

    int page = 1;

    public static CollectFragment newInstance(int catid) {
        CollectFragment fragment = new CollectFragment();
        Bundle b = new Bundle();
        b.putInt("catid", catid);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        catId = b.getInt("catid");
    }

    @Override
    protected void initView() {
        mAdapter = new CollectAdapter(new ArrayList<>(), catId);
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                String id = mAdapter.getItem(position).getVod_id();
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("id", id);
                startActivity(MovieDetailActivity.class, map);
            }
        });

        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });

        layoutRefresh.autoRefresh();
    }

    @OnClick({R.id.btn_del, R.id.btn_all})
    void click(View v){
        switch (v.getId()){
            case R.id.btn_del:
                String ids = "";
                for(CollectInfo info : mAdapter.getData()){
                    if (info.isCheck()) {
                        ids = ids + "," + info.getId();
                    }
                }
                if (TextUtils.isEmpty(ids)) {
                    return;
                }
                cancel(ids.substring(1));
                break;
            case R.id.btn_all:
                for(CollectInfo info : mAdapter.getData()){
                    info.setCheck(true);
                }
                mAdapter.notifyDataSetChanged();
                break;
        }
    }

    private void getList(){
        Kalle.post(HttpUrl.COLLECT_LIST)
                .tag(tag + catId)
                .param("cat_id", catId)
                .param("page", page)
                .param("size", 10)
                .perform(new NormalCallback<List<CollectInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<CollectInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else{
                            ToastUtils.show(response.failed());
                            layoutRefresh.finishRefresh();
                            layoutRefresh.finishLoadMore();
                        }
                    }
                });
    }

    void initList(List<CollectInfo> list) {
        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                isEdit = false;
                mAdapter.edit(false);
                layoutBottom.setVisibility(View.GONE);
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
        }else{
            mAdapter.addData(list);
        }
        layoutRefresh.finishRefresh();
        layoutRefresh.finishLoadMore();
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }
    }

    private void cancel(String ids){
        Kalle.post(HttpUrl.COLLECT_CANCEL)
                .tag(tag + catId)
                .param("collect_ids", ids)
                .perform(new LoadingCallback<List<CollectInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<CollectInfo>, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("取消成功");
                            page = 1;
                            getList();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_02_SCHOOL_REVIEW:{
                int id = (int) event.getObj1();
                boolean edit = (boolean) event.getObj2();
                if (catId == id) {
                    if (edit) {
                        if (mAdapter != null && !mAdapter.getData().isEmpty()) {
                            isEdit = true;
                            mAdapter.edit(true);
                            EventBus.getDefault().post(new Event(Event.CODE_03_SCHOOL_REVIEW_BTN));
                            layoutBottom.setVisibility(View.VISIBLE);
                        }
                    }else{
                        if (mAdapter != null && !mAdapter.getData().isEmpty()) {
                            isEdit = false;
                            mAdapter.edit(false);
                            layoutBottom.setVisibility(View.GONE);
                        }
                    }

                }
            }
                break;
        }
    }

    @Override
    public void onSupportInvisible() {
        super.onSupportInvisible();
        if (isEdit) {
            if (mAdapter != null && !mAdapter.getData().isEmpty()) {
                isEdit = false;
                mAdapter.edit(false);
                layoutBottom.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Kalle.cancel(tag + catId);
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_collect;
    }

}
