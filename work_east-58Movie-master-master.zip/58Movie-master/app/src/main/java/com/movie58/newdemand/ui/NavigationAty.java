package com.movie58.newdemand.ui;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.zhy.autolayout.utils.AutoUtils;

import java.util.ArrayList;
import java.util.Collections;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class NavigationAty extends BaseAty {

    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;

    @BindView(R.id.tv_title)
    TextView tv_title;
    @BindView(R.id.tv_right)
    TextView tv_right;
    @BindView(R.id.relay)
    RelativeLayout relay;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;

    private ArrayList<String> listTab;
    private ArrayList<String> listTab2;

    @Override
    public int getLayoutId() {
        return R.layout.aty_navigation;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        listTab = getIntent().getStringArrayListExtra("data");
        listTab2 = getIntent().getStringArrayListExtra("data2");


    }

    @Override
    public void requestData() {
    }

    private GoldRecyclerAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        initTopview(relay, relay_top);
        tv_title.setText("导航");
        tv_right.setText("编辑");
        tv_right.setVisibility(View.VISIBLE);


        GridLayoutManager manager = new GridLayoutManager(this, 3);
        manager.setOrientation(OrientationHelper.VERTICAL);
        recyclerview.setLayoutManager(manager);
        adapter = new GoldRecyclerAdapter(this);
        recyclerview.setAdapter(adapter);
        helper.attachToRecyclerView(recyclerview);
    }

    @OnClick({R.id.relay_back, R.id.tv_right})
    void click(View v) {
        switch (v.getId()) {
            case R.id.relay_back:
                finish();
                break;
            case R.id.tv_right:
                if (tv_right.getText().toString().equals("编辑")) {
                    tv_right.setText("完成");
                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    Intent intent = new Intent();
                    intent.putStringArrayListExtra("data", listTab);
                    setResult(RESULT_OK, intent);
                    finish();
                }
                break;
        }
    }


    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.aitem_navigation, parent, false);
            return new GoldRecyclerAdapter.fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            fGoldViewHolder holder1 = (fGoldViewHolder) holder;
            holder1.tv_name.setText(listTab2.get(position));

            if (tv_right.getText().toString().equals("编辑")) {
                holder1.imgv_cb.setVisibility(View.GONE);
            } else {
                holder1.imgv_cb.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public int getItemCount() {
            return listTab.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {


            @BindView(R.id.tv_name)
            TextView tv_name;
            @BindView(R.id.imgv_cb)
            ImageView imgv_cb;


            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }

    ItemTouchHelper helper = new ItemTouchHelper(new ItemTouchHelper.Callback() {
        @Override
        public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
            int dragFrlg = 0;
            if (recyclerView.getLayoutManager() instanceof GridLayoutManager) {
                dragFrlg = ItemTouchHelper.UP | ItemTouchHelper.DOWN | ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
            } else if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
                dragFrlg = ItemTouchHelper.UP | ItemTouchHelper.DOWN;
            }
            return makeMovementFlags(dragFrlg, 0);
        }

        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
            //滑动事件  下面注释的代码，滑动后数据和条目错乱，被舍弃
//            Collections.swap(datas,viewHolder.getAdapterPosition(),target.getAdapterPosition());
//            ap.notifyItemMoved(viewHolder.getAdapterPosition(),target.getAdapterPosition());

            if (tv_right.getText().toString().equals("编辑")) {
                return true;
            }
            //得到当拖拽的viewHolder的Position
            int fromPosition = viewHolder.getAdapterPosition();
            //拿到当前拖拽到的item的viewHolder
            int toPosition = target.getAdapterPosition();
            if (fromPosition < toPosition) {
                for (int i = fromPosition; i < toPosition; i++) {
                    Collections.swap(listTab2, i, i + 1);
                    Collections.swap(listTab, i, i + 1);
                }
            } else {
                for (int i = fromPosition; i > toPosition; i--) {
                    Collections.swap(listTab2, i, i - 1);
                    Collections.swap(listTab, i, i - 1);
                }
            }
            adapter.notifyItemMoved(fromPosition, toPosition);
            return true;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
            //侧滑删除可以使用；
        }

        @Override
        public boolean isLongPressDragEnabled() {
            return true;
        }

        /**
         * 长按选中Item的时候开始调用
         * 长按高亮
         * @param viewHolder
         * @param actionState
         */
        @Override
        public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState) {
            if (actionState != ItemTouchHelper.ACTION_STATE_IDLE) {
                viewHolder.itemView.setBackgroundColor(0xfff5f5f5);
                //获取系统震动服务//震动70毫秒
                Vibrator vib = (Vibrator) getSystemService(Service.VIBRATOR_SERVICE);
                vib.vibrate(70);
            }
            super.onSelectedChanged(viewHolder, actionState);
        }

        /**
         * 手指松开的时候还原高亮
         * @param recyclerView
         * @param viewHolder
         */
        @Override
        public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
            super.clearView(recyclerView, viewHolder);
            viewHolder.itemView.setBackgroundColor(0);
            adapter.notifyDataSetChanged();  //完成拖动后刷新适配器，这样拖动后删除就不会错乱
        }
    });
}
