package com.movie58.task;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.widget.TextView;

import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.ConvertRecordAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.ConvertRecordInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/6/26 0026.
 */
public class ConvertRecordActivity extends BaseUseActivity {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    ConvertRecordAdapter mAdapter;

    int page = 1;

    @Override
    protected void initView() {
        tvTitle.setText("兑换记录");

        mAdapter = new ConvertRecordAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).build());
        mAdapter.bindToRecyclerView(rvList);
        layoutRefresh.setEnableRefresh(false);

        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });

        getList();
    }

    @OnClick(R.id.iv_back)
    void back(){
        finish();
    }

    private void  getList(){

        Kalle.get(HttpUrl.GOLD_HIS)
                .param("page", page)
                .param("size", 10)
                .perform(new NormalCallback<List<ConvertRecordInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<ConvertRecordInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else{
                            ToastUtils.show(response.succeed());
                        }
                    }
                });
    }

    void initList(List<ConvertRecordInfo> list){
        if (list == null) {
            list = new ArrayList<>();
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
        }else{
            mAdapter.addData(list);
        }
        layoutRefresh.finishRefresh();
        layoutRefresh.finishLoadMore();
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }


    @Override
    protected int getLayout() {
        return R.layout.activity_convert_record;
    }

}
