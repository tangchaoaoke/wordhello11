package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/8 0008.
 */
public class HomeTab {
    /**
     * id : 1
     * cat_name : 电视剧
     * create_time : null
     * update_time : null
     * sort : 2
     * page_name : tv
     */

    private int id;
    private String cat_name;
    private Object create_time;
    private Object update_time;
    private int sort;
    private String page_name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }

    public Object getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Object create_time) {
        this.create_time = create_time;
    }

    public Object getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Object update_time) {
        this.update_time = update_time;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public String getPage_name() {
        return page_name;
    }

    public void setPage_name(String page_name) {
        this.page_name = page_name;
    }

    @Override
    public String toString() {
        return "HomeTab{" +
                "id=" + id +
                ", cat_name='" + cat_name + '\'' +
                ", create_time=" + create_time +
                ", update_time=" + update_time +
                ", sort=" + sort +
                ", page_name='" + page_name + '\'' +
                '}';
    }
}
