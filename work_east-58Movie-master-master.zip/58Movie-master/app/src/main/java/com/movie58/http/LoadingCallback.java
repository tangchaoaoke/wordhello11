package com.movie58.http;

import android.content.Context;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.yanzhenjie.kalle.exception.ConnectTimeoutError;
import com.yanzhenjie.kalle.exception.HostError;
import com.yanzhenjie.kalle.exception.NetworkError;
import com.yanzhenjie.kalle.exception.ParseError;
import com.yanzhenjie.kalle.exception.ReadTimeoutError;
import com.yanzhenjie.kalle.exception.URLError;
import com.yanzhenjie.kalle.exception.WriteException;
import com.yanzhenjie.kalle.simple.Callback;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Created by yangxing on 2018/10/9 0009.
 */
public abstract class LoadingCallback<S> extends Callback<S, String> {

    BasePopupView loadingPopup;

    public LoadingCallback(Context context) {
        loadingPopup = new XPopup.Builder(context)
                .asLoading("加载中...");
    }

    @Override
    public Type getSucceed() {
        // 通过反射获取业务成功的数据类型。
        Type superClass = getClass().getGenericSuperclass();
        return ((ParameterizedType) superClass).getActualTypeArguments()[0];
    }

    @Override
    public Type getFailed() {
        // 返回失败时的数据类型，String。
        return String.class;
    }

    @Override
    public void onStart() {
        // 请求开始啦，显示Dialog。
        if (loadingPopup != null && !loadingPopup.isShow()) {
            loadingPopup.show();
        }
    }

    @Override
    public void onException(Exception e) {
        // 发生异常了，回调到onResonse()中。
        String message;
        if (e instanceof NetworkError) {
            message = "网络不可用";
        } else if (e instanceof URLError) {
            message = "Url格式错误";
        } else if (e instanceof HostError) {
            message = "没有找到Url指定服务器";
        } else if (e instanceof ConnectTimeoutError) {
            message = "连接服务器超时，请重试";
        } else if (e instanceof WriteException) {
            message = "发送数据错误，请检查网络";
        } else if (e instanceof ReadTimeoutError) {
            message = "读取服务器数据超时，请检查网络";
        } else if (e instanceof ParseError) {
            message = "解析数据时发生异常";
        } else {
            message = "发生未知异常，请稍后重试";
        }

        SimpleResponse<S, String> response = SimpleResponse.<S, String>newBuilder()
                .failed(message)
                .build();
        onResponse(response);
    }


    @Override
    public void onResponse(SimpleResponse<S, String> response) {

        try {
            onFinaly(response);
        } catch (Exception e) {

        }
    }

    public void onFinaly(SimpleResponse<S, String> response) {

    }


    @Override
    public void onCancel() {
        // 请求被取消了，如果开发者需要，请自行处理。
        if (loadingPopup != null) {
            loadingPopup.dismiss();
        }
    }

    @Override
    public void onEnd() {
        // 请求结束啦，关闭Dialog。
        if (loadingPopup != null) {
            loadingPopup.dismiss();
        }
    }
}
