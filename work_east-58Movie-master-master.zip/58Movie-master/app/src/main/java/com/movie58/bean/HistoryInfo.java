package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class HistoryInfo {
    /**
     * id : 22
     * vod_id : 108
     * user_id : 8
     * played_time : 0
     * play_anthology : 1
     * create_time : 2019-05-25 15:36:04
     * update_time : 2019-05-25 15:36:04
     * total_time : 7227067
     * source_name : 流浪地球
     * source_img : https://pic.china-gif.com/pic/upload/vod/2019-02/15494025274.jpg
     */

    private int id;
    private String vod_id;
    private int user_id;
    private int played_time;
    private String play_anthology;
    private String create_time;
    private String update_time;
    private int total_time;
    private String source_name;
    private String source_img;
    private String timeshow;
    private boolean show;
    private boolean check;


    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public String getTimeshow() {
        return timeshow;
    }

    public void setTimeshow(String timeshow) {
        this.timeshow = timeshow;
    }

    public boolean isShow() {
        return show;
    }

    public void setShow(boolean show) {
        this.show = show;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVod_id() {
        return vod_id;
    }

    public void setVod_id(String vod_id) {
        this.vod_id = vod_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getPlayed_time() {
        return played_time;
    }

    public void setPlayed_time(int played_time) {
        this.played_time = played_time;
    }

    public String getPlay_anthology() {
        return play_anthology;
    }

    public void setPlay_anthology(String play_anthology) {
        this.play_anthology = play_anthology;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public int getTotal_time() {
        return total_time;
    }

    public void setTotal_time(int total_time) {
        this.total_time = total_time;
    }

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public String getSource_img() {
        return source_img;
    }

    public void setSource_img(String source_img) {
        this.source_img = source_img;
    }
}
