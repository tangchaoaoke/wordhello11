package com.movie58.my;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.bean.SystemInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class MsgSystemFragment extends BaseFragment {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    int page = 1;

    SystemAdapter mAdapter;

    public static MsgSystemFragment newInstance() {
        return new MsgSystemFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("系统消息");

        mAdapter = new SystemAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).colorResId(R.color.line)
                .margin(getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_15), 0).build());
        mAdapter.bindToRecyclerView(rvList);


        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    @Override
    protected void initData() {
        layoutRefresh.autoRefresh();
    }

    private void getList(){
        Kalle.get(HttpUrl.MSG_SYSTEM)
                .param("page", page)
                .param("szie", 10)
                .perform(new LoadingCallback<List<SystemInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<SystemInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initList(List<SystemInfo> list){


        if (list == null) {
            list = new ArrayList<>();
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
            layoutRefresh.finishRefresh();
        }else{
            mAdapter.addData(list);
            layoutRefresh.finishLoadMore();
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }

    @OnClick({R.id.iv_back})
    void Click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;

        }
    }


    @Override
    protected int getLayout() {
        return R.layout.fragment_msg_system;
    }

    class SystemAdapter extends BaseQuickAdapter<SystemInfo, BaseViewHolder> {

        public SystemAdapter(@Nullable List<SystemInfo> data) {
            super(R.layout.item_system, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, SystemInfo item) {
            helper.setText(R.id.tv_title, item.getMessage_title())
                    .setText(R.id.tv_time, item.getCreate_time())
                    .setText(R.id.tv_content, item.getMessage_content());
        }
    }


}
