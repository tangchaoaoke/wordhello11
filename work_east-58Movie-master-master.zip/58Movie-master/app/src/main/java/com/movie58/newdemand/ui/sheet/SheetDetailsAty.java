package com.movie58.newdemand.ui.sheet;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.movie58.newdemand.flow.FlowLayout;
import com.movie58.newdemand.interfaces.Sheet;
import com.movie58.newdemand.utils.ImagesUtils;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.account.Account;
import com.movie58.home.MovieDetailActivity;
import com.zhy.autolayout.utils.AutoUtils;

import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SheetDetailsAty extends BaseAty {


    @BindView(R.id.relay_back)
    RelativeLayout relayBack;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.relay)
    RelativeLayout relay;
    @BindView(R.id.relay_top)
    RelativeLayout relayTop;
    @BindView(R.id.tv_all)
    TextView tv_all;
    @BindView(R.id.tv_del)
    TextView tv_del;
    @BindView(R.id.linlay_bottom)
    LinearLayout linlay_bottom;
    private String data;
    private ArrayList<Map<String, String>> list;
    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    @BindView(R.id.flowlayout)
    FlowLayout flowlayout;
    @BindView(R.id.linlay_02)
    LinearLayout linlay_02;
    @BindView(R.id.imgv_head)
    ImageView imgv_head;
    @BindView(R.id.tv_num)
    TextView tv_num;
    @BindView(R.id.tv_time)
    TextView tv_time;
    @BindView(R.id.imgv)
    ImageView imgv;
    @BindView(R.id.relay_02)
    RelativeLayout relay_02;


    private GoldRecyclerAdapter adapter;
    private ArrayList<Integer> list_cb;
    private String sheet_name;
    private String sheet_id;
    private ArrayList<String> list_str;
    private ArrayList<String> list_id;

    @Override
    public int getLayoutId() {
        return R.layout.aty_sheet_details;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        sheet = new Sheet();
        list_cb = new ArrayList<>();
        list_id = new ArrayList<>();
        data = getIntent().getStringExtra("vod_list");
        sheet_name = getIntent().getStringExtra("sheet_name");
        sheet_id = getIntent().getStringExtra("sheet_id");
        list_str = new ArrayList<>();
        list_str.add("动作");
        list_str.add("搞笑");
        list_str.add("爱情");
        list_str.add("古代");
        list_str.add("谍战悬疑");
        list_str.add("警匪");
        list_str.add("特种兵");
        list_str.add("战争");
        list_str.add("孙悟空");
        list_str.add("武侠");
    }

    @Override
    public void requestData() {
    }

    private Sheet sheet;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 520) {
                startProgressDialog();
                sheet.d3(this);
            }
            if (requestCode == 11) {
                String name = data.getStringExtra("name");
                tvTitle.setText(name);

            }
        }
    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        stopProgressDialog();
        if (type.equals("sheetVodList")) {
            ArrayList<Map<String, String>> list2 = JSONUtils.parseDataToMapList(var2);
            for (int i = 0; i < list2.size(); i++) {
                if (list2.get(i).get("id").equals(sheet_id)) {
                    list = JSONUtils.parseKeyAndValueToMapList(list2.get(i).get("vod_list"));
                    break;
                }
            }

            if (list != null && adapter != null) {
                reSet();
            }

            if (list == null || list.size() == 0) {
                initLayout(list_str);
                linlay_02.setVisibility(View.VISIBLE);
                recyclerview.setVisibility(View.GONE);
                relay_02.setVisibility(View.GONE);
            } else {
                linlay_02.setVisibility(View.GONE);
                recyclerview.setVisibility(View.VISIBLE);
                relay_02.setVisibility(View.VISIBLE);
            }

            if (list == null || list.size() == 0) {
                tv_num.setText("0部");
            } else {
                tv_num.setText(list.size() + "部");
                ImagesUtils.disImg2(this, list.get(0).get("source_img"), imgv, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);
            }
        }

        if (type.equals("delVodSheet")) {
            startProgressDialog();
            sheet.d3(this);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        initTopview(relay, relayTop, AutoUtils.getPercentHeightSize(400));
        list = JSONUtils.parseKeyAndValueToMapList(data);
        tvTitle.setText(sheet_name);
        tvRight.setText("编辑");
        list_cb.clear();
        list_id.clear();
        for (int i = 0; i < list.size(); i++) {
            list_cb.add(0);
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        adapter = new GoldRecyclerAdapter(this);
        recyclerview.setAdapter(adapter);

        if (list == null || list.size() == 0) {
            initLayout(list_str);
            linlay_02.setVisibility(View.VISIBLE);
            recyclerview.setVisibility(View.GONE);
            relay_02.setVisibility(View.GONE);
        } else {
            linlay_02.setVisibility(View.GONE);
            recyclerview.setVisibility(View.VISIBLE);
            relay_02.setVisibility(View.VISIBLE);
        }

        ImagesUtils.disImgCircleNo2(this, Account.getInstance().getAvatar(), imgv_head, R.drawable.avatar, R.drawable.avatar);
        if (list == null || list.size() == 0) {
            tv_num.setText("0部");
        } else {
            tv_num.setText(list.size() + "部");
            ImagesUtils.disImg2(this, list.get(0).get("source_img"), imgv, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);
        }

    }

    public void reSet() {
        tvRight.setText("编辑");
        linlay_bottom.setVisibility(View.GONE);
        list_cb.clear();
        list_id.clear();
        tv_del.setText("删除");
        tv_all.setText("全选");
        tv_del.setTextColor(0xaa444444);
        for (int i = 0; i < list.size(); i++) {
            list_cb.add(0);
        }

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    @OnClick({R.id.relay_back, R.id.tv_title, R.id.tv_right, R.id.relay, R.id.relay_top
            , R.id.tv_add, R.id.relay_02, R.id.tv_del, R.id.tv_all,R.id.tv_search})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.relay_back:
                finish();
                break;
            case R.id.tv_title:
                break;
            case R.id.tv_right:
                if (tvRight.getText().toString().equals("编辑")) {
                    showPopFormBottom();
                } else {
                    reSet();
                }
                break;
            case R.id.relay:
                break;
            case R.id.relay_top:
                break;
            case R.id.tv_search:
            case R.id.relay_02:
            case R.id.tv_add:
                Bundle bundle = new Bundle();
                bundle.putString("sheet_id", sheet_id);
                startActivityForResult(SheetFindAty.class, bundle, 520);
                break;
            case R.id.tv_del:
                list_id.clear();
                for (int i = 0; i < list_cb.size(); i++) {
                    if (list_cb.get(i) == 1) {
                        list_id.add(list.get(i).get("id"));
                    }
                }
                if (list_id == null || list_id.size() == 0) {
                    return;
                }

                StringBuffer stringBuffer = new StringBuffer();
                for (int i = 0; i < list_id.size(); i++) {
                    stringBuffer.append(list_id.get(i));
                    if (i != list_id.size() - 1) {
                        stringBuffer.append(",");
                    }
                }
                startProgressDialog();
                sheet.e2(sheet_id, stringBuffer.toString(), this);
                break;
            case R.id.tv_all:
                if (tv_all.getText().toString().equals("全选")) {
                    tv_all.setText("取消全选");
                    for (int i = 0; i < list_cb.size(); i++) {
                        list_cb.set(i, 1);
                    }
                    tv_del.setText("删除(" + list.size() + ")");
                    tv_del.setTextColor(0xaaCE5E52);
                } else {
                    tv_all.setText("全选");
                    for (int i = 0; i < list_cb.size(); i++) {
                        list_cb.set(i, 0);
                    }
                    tv_del.setText("删除");
                    tv_del.setTextColor(0xaa444444);

                }
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
                break;
        }
    }

    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_sheet_details, parent, false);
            return new fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            fGoldViewHolder holder1 = (fGoldViewHolder) holder;
            ImagesUtils.disImg2(SheetDetailsAty.this, list.get(position).get("source_img"),
                    holder1.imgv, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);
            holder1.tvName.setText(list.get(position).get("source_name"));
            holder1.tvNum.setText(list.get(position).get("lead_role"));

            if (tvRight.getText().toString().equals("编辑")) {
                holder1.cb.setVisibility(View.GONE);
            } else {
                holder1.cb.setVisibility(View.VISIBLE);
                if (list_cb.get(position) == 1) {
                    holder1.cb.setImageResource(R.drawable.radio_sel);
                } else {
                    holder1.cb.setImageResource(R.drawable.radio_nor);
                }
            }

            holder1.itemView.setOnClickListener(v -> {
                if (tvRight.getText().toString().equals("编辑")) {
                    Bundle bundle = new Bundle();
                    bundle.putString("id", list.get(position).get("id"));
//                    bundle.putString("played_time", list.get(position).getPlayed_time());
                    startActivity(MovieDetailActivity.class, bundle);
                    return;
                }
                if (list_cb.get(position) == 1) {
                    list_cb.set(position, 0);
                } else {
                    list_cb.set(position, 1);
                }

                int k = 0;
                for (int i = 0; i < list_cb.size(); i++) {
                    if (list_cb.get(i) == 1) {
                        k++;
                    }
                }
                if (k == 0) {
                    tv_del.setText("删除");
                    tv_del.setTextColor(0xaa444444);

                } else {
                    tv_del.setText("删除(" + k + ")");
                    tv_del.setTextColor(0xaaCE5E52);
                }
                if (k == list.size()) {
                    tv_all.setText("取消全选");
                } else {
                    tv_all.setText("全选");
                }
                notifyDataSetChanged();
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.imgv)
            ImageView imgv;
            @BindView(R.id.tv_name)
            TextView tvName;
            @BindView(R.id.tv_num)
            TextView tvNum;
            @BindView(R.id.cb)
            ImageView cb;

            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }


    private void initLayout(ArrayList<String> arr) {
        flowlayout.removeAllViewsInLayout();
        final RelativeLayout[] layouts = new RelativeLayout[arr.size()];
        for (int i = 0; i < arr.size(); i++) {
            View view = LayoutInflater.from(this).inflate(R.layout.item_sheet_01, flowlayout, false);
            TextView text = view.findViewById(R.id.tv_content);
            RelativeLayout relay = view.findViewById(R.id.relay);
            text.setText(arr.get(i));
            layouts[i] = relay;
            flowlayout.addView(view);
            int finalI = i;
            relay.setOnClickListener(v -> {
                Bundle bundle = new Bundle();
                bundle.putString("sheet_id", sheet_id);
                bundle.putString("search_name", arr.get(finalI));
                startActivityForResult(SheetFindSearchAty.class, bundle, 520);

            });


        }
    }

    PopupWindow popupWindow;

    public void showPopFormBottom() {
        View view = LayoutInflater.from(this).inflate(R.layout.pop_01, null);
        LinearLayout linlay_edit = (LinearLayout) view.findViewById(R.id.linlay_edit);
        LinearLayout linlay_delete = (LinearLayout) view.findViewById(R.id.linlay_delete);
        LinearLayout linlay_add = (LinearLayout) view.findViewById(R.id.linlay_add);


        RelativeLayout relay_01 = (RelativeLayout) view.findViewById(R.id.relay_01);
        popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int popupHeight = view.getMeasuredHeight();
        int popupWidth = view.getMeasuredWidth();
        int[] location = new int[2];
        popupWindow.setBackgroundDrawable(new BitmapDrawable());//注意这里如果不设置，下面的setOutsideTouchable(true);允许点击外部消失会失效
        popupWindow.setOutsideTouchable(true);   //设置外部点击关闭ppw窗口
        popupWindow.setFocusable(false);
        popupWindow.setOnDismissListener(() -> {
        });

        linlay_edit.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putString("sheet_id", sheet_id);
            bundle.putString("sheet_name", sheet_name);
            startActivityForResult(RepaceNSheetAty.class, bundle, 11);
            popupWindow.dismiss();
        });
        linlay_add.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putString("sheet_id", sheet_id);
            startActivityForResult(SheetFindAty.class, bundle, 520);
            popupWindow.dismiss();
        });
        linlay_delete.setOnClickListener(v -> {
            tvRight.setText("取消");
            linlay_bottom.setVisibility(View.VISIBLE);
            popupWindow.dismiss();
            list_cb.clear();
            list_id.clear();
            for (int i = 0; i < list.size(); i++) {
                list_cb.add(0);
            }
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
        });
        popupWindow.showAtLocation(tvRight, Gravity.NO_GRAVITY, screenWidth - popupWidth, AutoUtils.getPercentHeightSize(180));
    }

    public int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
}
