package com.movie58.newdemand.ui.sheet;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.newdemand.base.BaseFrg;
import com.movie58.newdemand.interfaces.Sheet;
import com.movie58.newdemand.utils.ImagesUtils;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.newdemand.view.MyRefreshAndLoadListen;
import com.movie58.newdemand.view.MySmoothRefreshLayout;
import com.zhy.autolayout.utils.AutoUtils;

import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SheetFindFrg extends BaseFrg {


    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    @BindView(R.id.refreshLayout)
    MySmoothRefreshLayout refreshLayout;
    private String cat_id;
    private String sheet_id;
    private int page = 1;

    private Sheet sheet;
    private GoldRecyclerAdapter adapter;
    private ArrayList<Map<String, String>> list;

    private ArrayList<String> list_check;

    public static SheetFindFrg newInstance(String cat_id, String sheet_id) {
        SheetFindFrg fragment = new SheetFindFrg();
        Bundle b = new Bundle();
        b.putString("cat_id", cat_id);
        b.putString("sheet_id", sheet_id);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    public void requestDatas() {
        super.requestDatas();
        sheet.ds(cat_id, sheet_id, page, this);
    }


    @Override
    protected int getLayoutResource() {
        return R.layout.frg_sheet_find;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    protected void initView() {
        list = new ArrayList<>();
        list_check = new ArrayList<>();
        sheet = new Sheet();
        cat_id = getArguments().getString("cat_id");
        sheet_id = getArguments().getString("sheet_id");
    }

    @Override
    public void onExceptionType(Throwable var1, RequestParams params, String type) {
        super.onExceptionType(var1, params, type);
        refreshLayout.finishLoadmore();
        refreshLayout.finishRefreshing();
    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        stopProgressDialog();
        refreshLayout.finishLoadmore();
        refreshLayout.finishRefreshing();
        if (type.equals("search")) {
            if (adapter == null) {
                list = JSONUtils.parseDataToMapList(var2);
                if (list != null) {
                    for (int i = 0; i < list.size(); i++) {
                        list_check.add("0");
                    }
                }
                adapter = new GoldRecyclerAdapter(getActivity());
                recyclerview.setAdapter(adapter);
            } else {
                if (page == 1) {
                    list = JSONUtils.parseDataToMapList(var2);
                } else {
                    list.addAll(JSONUtils.parseDataToMapList(var2));
                }
                if (list != null) {
                    for (int i = 0; i < list.size(); i++) {
                        list_check.add("0");
                    }
                }
                adapter.notifyDataSetChanged();
            }
        }
    }

    
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        adapter = new GoldRecyclerAdapter(getActivity());
        recyclerview.setAdapter(adapter);
        refreshLayout.setEnableRefresh(true);
        refreshLayout.setEnableLoadmore(true);
//        refreshLayout.loadMoreReturn();

        refreshLayout.setMyRefreshAndLoadListen(new MyRefreshAndLoadListen() {
            @Override
            public void refreshStart() {
                page = 1;
                sheet.ds(cat_id, sheet_id, page, SheetFindFrg.this);
            }

            @Override
            public void loadMoreStart() {
                page++;
                sheet.ds(cat_id, sheet_id, page, SheetFindFrg.this);
            }
        });
    }


    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_sheet_find_frg, parent, false);
            return new GoldRecyclerAdapter.fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            GoldRecyclerAdapter.fGoldViewHolder holder1 = (GoldRecyclerAdapter.fGoldViewHolder) holder;
//            ImagesUtils.disImg(getActivity(), list.get(position).get("source_img"), holder1.iv_player);
            ImagesUtils.disImg2(getActivity(), list.get(position).get("source_img"),
                    holder1.iv_player, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);

            holder1.tv_time.setText(list.get(position).get("up_right_text"));
            holder1.tv_name.setText(list.get(position).get("source_name"));
            holder1.tv_details.setText(list.get(position).get("description"));
            String is_sheet_vod = list.get(position).get("is_sheet_vod");
            if (is_sheet_vod.equals("1")) {
                holder1.tv_isadd.setText("已在片单");
                holder1.tv_isadd.setTextColor(0xaa000000);
            } else {

                if (list_check.get(position).equals("1")) {
                    holder1.tv_isadd.setText("√ 片单");
                    holder1.tv_isadd.setTextColor(0xaa000000);
                } else {
                    holder1.tv_isadd.setText("+片单");
                    holder1.tv_isadd.setTextColor(0xff673AB7);
                }
            }
            holder1.itemView.setOnClickListener(v -> {
                if (is_sheet_vod.equals("1")) {
                    return;
                }
                SheetFindAty findAty = (SheetFindAty) getActivity();
                findAty.addData(list.get(position).get("id"), list_check.get(position));

                if (list_check.get(position).equals("1")) {
                    list_check.set(position, "0");
                } else {
                    list_check.set(position, "1");
                }
                notifyDataSetChanged();
            });
            if (position==list.size()-1){
                holder1.v_01.setVisibility(View.VISIBLE);
            }else{
                holder1.v_01.setVisibility(View.GONE);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.iv_player)
            ImageView iv_player;
            @BindView(R.id.tv_time)
            TextView tv_time;
            @BindView(R.id.tv_name)
            TextView tv_name;
            @BindView(R.id.tv_details)
            TextView tv_details;
            @BindView(R.id.tv_isadd)
            TextView tv_isadd;
            @BindView(R.id.v_01)
            View v_01;
            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }


}
