package com.movie58.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.blankj.utilcode.util.SPUtils;
import com.flyco.tablayout.CommonTabLayout;
import com.flyco.tablayout.listener.CustomTabEntity;
import com.movie58.R;
import com.movie58.newdemand.base.AppConfig;
import com.movie58.newdemand.base.AppManager;
import com.movie58.newdemand.utils.ToastUitl;
import com.movie58.account.Account;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.TabEntity;
import com.movie58.bean.UpdateInfo;
import com.movie58.bean.UserInfo;
import com.movie58.event.Event;
import com.movie58.find.FindFragment;
import com.movie58.home.HomeFragment;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.my.MyFragment;
import com.movie58.share.ShareFragment;
import com.movie58.task.TaskFragment;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.umeng.socialize.UMShareAPI;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;

import butterknife.BindView;


public class MainActivity extends BaseUseActivity {

    @BindView(R.id.layou_tab)
    CommonTabLayout layouTab;
    UpdateInfo updateInfo;

    private ArrayList<Fragment> mFragments = new ArrayList<>();
    private ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();

    private String[] mTitles = {"首页", "发现", "分享", "任务", "我的"};
    private int[] iconNor = {R.drawable.tab_home_nor, R.drawable.tab_find_nor,
            R.drawable.tab_share_nor, R.drawable.tab_task_nor, R.drawable.tab_my_nor};
    private int[] iconSel = {R.drawable.tab_home_sel, R.drawable.tab_find_sel,
            R.drawable.tab_share_sel, R.drawable.tab_task_sel, R.drawable.tab_my_sel};

    private HomeFragment homeFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setFitsSystem(false);
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        setBackTwo(true);
    }

    @Override
    protected void initView() {
        if (Account.getInstance().isLogined()) {
            getUser();
            if (!ToolUtil.getCurrentDate().equals(SPUtils.getInstance().getString(SPContant.LOGIN_SUC))) {
                addExp();
            }
        } else {
            showDialog();
        }

        //更新
        if (!AppConfig.Debug){
            Update();
        }

        homeFragment = HomeFragment.newInstance();
        mFragments.add(homeFragment);
        mFragments.add(FindFragment.newInstance());
        mFragments.add(ShareFragment.newInstance(false));
        mFragments.add(TaskFragment.newInstance());
        mFragments.add(MyFragment.newInstance());

        for (int i = 0; i < mTitles.length; i++) {
            mTabEntities.add(new TabEntity(mTitles[i], iconSel[i], iconNor[i]));
        }
        layouTab.setTabData(mTabEntities, this, R.id.layout_fragment, mFragments);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_01_TAB_HOME:
                layouTab.setCurrentTab(0);
                break;
            case Event.CODE_14_AVATAR:
//                layouTab.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        layouTab.setCurrentTab(3);
//                    }
//                }, 100);
                layouTab.setCurrentTab(3);
                break;
            case Event.CODE_16_MIAN_APPLICATION:
//                layouTab.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        layouTab.setCurrentTab(1);
//                    }
//                }, 100);
                layouTab.setCurrentTab(1);
                break;
        }
    }

    //获取用户信息
    void getUser() {
        Kalle.get(HttpUrl.USER_INFO)
                .tag(tag)
                .param("user_id", Account.getInstance().getUserId())
                .perform(new NormalCallback<UserInfo>() {
                    @Override
                    public void onFinaly(SimpleResponse<UserInfo, String> response) {
                        if (response.isSucceed()) {
                            UserInfo info = response.succeed();
                            Account.getInstance().setUserTel(info.getMobile())
                                    .setUserId(info.getId())
                                    .setUserName(info.getUser_nickname())
                                    .setAvatar(info.getAvatar())
                                    .setSex(info.getSex())
                                    .setInviteCode(info.getUser_login())
                                    .setLevel(info.getLevel_name());
                        } else {
                            Account.getInstance().loginOut();
                            showDialog();
                        }
                    }
                });
    }

    //更新版本
    private void Update() {
        Kalle.get(HttpUrl.UPDATE)
                .tag(tag)
                .perform(new NormalCallback<UpdateInfo>() {
                    @Override
                    public void onFinaly(SimpleResponse<UpdateInfo, String> response) {
                        if (response.isSucceed()) {
                            updateInfo = response.succeed();
                            if (updateInfo != null && !ToolUtil.getVersion().equals(updateInfo.getVersion()) && "1".equals(updateInfo.getIs_open())) {
                                update();
                            }
                        } else {

                        }
                    }
                });
    }

    private void addExp() {
        Kalle.get(HttpUrl.ADD_EXP)
                .tag(tag)
                .param("rule_code", "login_in")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            SPUtils.getInstance().put(SPContant.LOGIN_SUC, ToolUtil.getCurrentDate());
                            String bi = FastJsonUtil.toString(response.succeed(), "experience_num");
//                            ToastUtils.show("登录成功,+" + bi + " 经验值");
                        } else {

                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1314) {
                homeFragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }


    private void showDialog() {
        new RegisterDialog(getMActivity()).show();
    }

    private void update() {
        new UpdateDialog(getMActivity(), updateInfo).show();
    }

    private long firstTime;
    @Override
    public void onBackPressedSupport() {
        if (System.currentTimeMillis() - firstTime < 3000) {
            AppManager.getInstance().AppExit(this);
            System.exit(0);
        } else {
            firstTime = System.currentTimeMillis();
            ToastUitl.showShort(this, "再按一次返回桌面");
        }
    }
}
