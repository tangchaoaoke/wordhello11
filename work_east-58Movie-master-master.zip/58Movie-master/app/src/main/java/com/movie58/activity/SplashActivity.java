package com.movie58.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.widget.ImageView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.SPUtils;
import com.movie58.R;
import com.movie58.newdemand.base.AppStatusManager;
import com.movie58.newdemand.utils.PreferencesUtils;
import com.movie58.base.BaseUseActivity;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.SPContant;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * @author 启动页
 */
public class SplashActivity extends BaseUseActivity {
    @BindView(R.id.iv_splash)
    ImageView ivSplash;

    @Override
    protected int getLayout() {
        return R.layout.activity_splash;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppStatusManager.getInstance().setAppStatus(1);
        super.onCreate(savedInstanceState);
        initPermisson();
    }


    protected void initData() {
        super.initData();
    }

    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private boolean isEndbleOpen = true;
    private List<String> mPermissionList = new ArrayList<>();
    private void initPermisson() {
        mPermissionList.clear();
        for (int i = 0; i < PERMISSIONS_STORAGE.length; i++) {
            if (ContextCompat.checkSelfPermission(this, PERMISSIONS_STORAGE[i]) != PackageManager.PERMISSION_GRANTED) {
                mPermissionList.add(PERMISSIONS_STORAGE[i]);
            }
        }
        if (mPermissionList.isEmpty() || mPermissionList.size() == 0 || Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
            start();
        } else {
            String[] permissions = mPermissionList.toArray(new String[mPermissionList.size()]);//将List转为数组
            ActivityCompat.requestPermissions(this, permissions, 101);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 101) {
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    isEndbleOpen = false;
                    boolean showRequestPermission = ActivityCompat.shouldShowRequestPermissionRationale(SplashActivity.this, permissions[i]);
                    if (showRequestPermission) {
                        isEndbleOpen = true;
                        initPermisson();
                        return;
                    } else {
                        start();
                        return;
                    }
                }
            }
            if (isEndbleOpen) {
                PreferencesUtils.putString(SplashActivity.this, "isRefuse", "");
                start();
            } else {
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public  void start(){
        ivSplash.postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityUtils.startActivity(new Intent(SplashActivity.this, WelcomeActivity.class));
                ActivityUtils.finishActivity(SplashActivity.this);
            }
        }, 2000);
        Kalle.get(HttpUrl.GET_AD)
                .tag(tag)
                .param("position_code", "init")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String adImg = FastJsonUtil.toString(response.succeed(), "advert_img");
                            PicassoUtils.downLoadImg(SplashActivity.this, adImg, new PicassoUtils.DownLoadListener() {
                                @Override
                                public void DownLoadSuc(Bitmap bitmap) {
                                }

                                @Override
                                public void DownLoadFail() {
                                }
                            });
                            SPUtils.getInstance().put(SPContant.WELCOME_IMAGE, adImg);
                        }
                    }
                });
    }
}
