package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.MovieListInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/5/18 0018.
 */
public class MovieTypeAdapter extends BaseQuickAdapter<MovieListInfo, BaseViewHolder> {


    public MovieTypeAdapter(@Nullable List<MovieListInfo> data) {
        super(R.layout.item_movie_type, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, MovieListInfo item) {
        switch (item.getUp_right_text()) {
            case "火爆":
                helper.setGone(R.id.iv_top, true);
                helper.setImageResource(R.id.iv_top, R.drawable.hot_huobao);
                break;
            case "热播":
                helper.setImageResource(R.id.iv_top, R.drawable.hot_rebo);
                helper.setGone(R.id.iv_top, true);
                break;
            case "1080P":
                helper.setImageResource(R.id.iv_top, R.drawable.hot_1080);
                helper.setGone(R.id.iv_top, true);
                break;
            default:
                helper.setGone(R.id.iv_top, false);
                break;
        }
        helper.setText(R.id.tv_time, item.getDown_right_text())
                .setText(R.id.tv_name, item.getSource_name())
                .setText(R.id.tv_fen, item.getPingfen());
        ImageView ivImg = helper.getView(R.id.iv_player);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
    }
}
