package com.movie58.my;

import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.blankj.utilcode.util.SPUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hss01248.dialog.StyleDialog;
import com.hss01248.dialog.interfaces.DialogListener;
import com.liulishuo.filedownloader.util.FileDownloadUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.adapter.CacheAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.DownloadInfo;
import com.movie58.util.FastJsonUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/8/14 0014.
 */
public class CacheFragment1 extends BaseFragment {

    @BindView(R.id.rv_list)
    RecyclerView rvList;

    CacheAdapter mAdapter;

    public static CacheFragment1 newInstance() {
        CacheFragment1 fragment = new CacheFragment1();
        return fragment;
    }


    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        //end 存已完成列表  end1 存正在缓存列表刚刚缓存完成的数据切换到已完成就清空将数据添加到end
        String json = SPUtils.getInstance().getString(Account.getInstance().getUserId() + "end");
        String json1 = SPUtils.getInstance().getString(Account.getInstance().getUserId() + "end1");
        List<DownloadInfo> list = FastJsonUtil.toList(json, DownloadInfo.class);
        if (list == null) {
            list = new ArrayList<>();
        }
        List<DownloadInfo> list1 = FastJsonUtil.toList(json1, DownloadInfo.class);
        if (list1 == null) {
            list1 = new ArrayList<>();
        }
        for(DownloadInfo info : list1){
            if (!list.contains(info)) {
                list.add(info);
            }
        }
        SPUtils.getInstance().put(Account.getInstance().getUserId() + "end", FastJsonUtil.toJson(list));
        SPUtils.getInstance().put(Account.getInstance().getUserId() + "end1", "");

        mAdapter.setNewData(list);
    }

    @Override
    protected void initView() {
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        mAdapter = new CacheAdapter(new ArrayList<>());
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvList);

        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                ArrayMap<String, Object> map = new ArrayMap();
                map.put("path", mAdapter.getItem(position).getPath());
                map.put("title", mAdapter.getItem(position).getTitle());
                startActivity(CachePlayerActivity.class, map);
            }
        });

        mAdapter.setOnItemLongClickListener(new BaseQuickAdapter.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
                StyleDialog.buildIosAlert(getMActivity(), "提示", "确定删除吗？")
                        .setBtnText("取消", "确定")
                        .setBtnColor(R.color.color_base)
                        .setListener(new DialogListener() {
                            @Override
                            public void onFirst() {

                            }

                            @Override
                            public void onSecond() {
                                DownloadInfo item = mAdapter.getItem(position);
                                new File(item.getPath()).delete();
                                new File(FileDownloadUtils.getTempPath(item.getPath())).delete();
                                mAdapter.getData().remove(position);
                                mAdapter.notifyDataSetChanged();

                                String json = FastJsonUtil.toJson(mAdapter.getData());
                                SPUtils.getInstance().put(Account.getInstance().getUserId() + "end", json);

                            }
                        }).show();


                return false;
            }
        });

    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_cache;
    }
}
