package com.movie58.newdemand.flow;

import android.widget.TextView;

/**
 * com.ac.flowlayout_danxuan
 * @Email zhaoq_hero@163.com
 * @author zhaoQiang : 2016-2-23
 */
public class TagItem {
	public String tagText;  //标签上的文本信息：
	public boolean tagCustomEdit;
	public int idx;
	public TextView mView;
}
