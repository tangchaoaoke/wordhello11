package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class RankItemInfo {


    /**
     * source_name : 德云社岳云鹏相声专场南京站2018
     * source_img : https://tupian.tupianzy.com/pic/upload/vod/2019-04-08/201904081554690869.jpg
     * description : null
     * pingfen : 0.0
     * lead_role : 岳云鹏
     * director :
     * up_right_text :
     * down_right_text :
     * id : 161
     * trend : 0
     */

    private String source_name;
    private String source_img;
    private Object description;
    private String pingfen;
    private String lead_role;
    private String director;
    private String up_right_text;
    private String down_right_text;
    private String id;
    private int trend;
    private String tag_name;
    private String type_name;

    public String getType_name() {
        return type_name;
    }

    public void setType_name(String type_name) {
        this.type_name = type_name;
    }

    public String getTag_name() {
        return tag_name;
    }

    public void setTag_name(String tag_name) {
        this.tag_name = tag_name;
    }

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public String getSource_img() {
        return source_img;
    }

    public void setSource_img(String source_img) {
        this.source_img = source_img;
    }

    public Object getDescription() {
        return description;
    }

    public void setDescription(Object description) {
        this.description = description;
    }

    public String getPingfen() {
        return pingfen;
    }

    public void setPingfen(String pingfen) {
        this.pingfen = pingfen;
    }

    public String getLead_role() {
        return lead_role;
    }

    public void setLead_role(String lead_role) {
        this.lead_role = lead_role;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getUp_right_text() {
        return up_right_text;
    }

    public void setUp_right_text(String up_right_text) {
        this.up_right_text = up_right_text;
    }

    public String getDown_right_text() {
        return down_right_text;
    }

    public void setDown_right_text(String down_right_text) {
        this.down_right_text = down_right_text;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getTrend() {
        return trend;
    }

    public void setTrend(int trend) {
        this.trend = trend;
    }
}
