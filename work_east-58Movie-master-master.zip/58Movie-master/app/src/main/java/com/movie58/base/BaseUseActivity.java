package com.movie58.base;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;

import com.lxj.xpopup.core.BasePopupView;
import com.movie58.event.Event;
import com.yanzhenjie.kalle.Kalle;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.Serializable;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by yangxing on 2019/3/30 0030.
 */
public abstract class BaseUseActivity extends BaseActivity {

    Unbinder binder;
    protected final String tag = getClass().getSimpleName();
    Activity mActivity;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayout());
        mActivity = this;
        binder = ButterKnife.bind(this);
        EventBus.getDefault().register(this);
        getIntentExtra();
        initView();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Kalle.cancel(tag);
            }
        });
        binder.unbind();
        EventBus.getDefault().unregister(this);
    }

    protected void getIntentExtra() {}

    protected void initView(){}

    protected void initData(){}

    protected abstract int getLayout();

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event e){

    }


    protected Activity getMActivity(){
        return mActivity;
    }

    public void startActivity(Class<?> to){
        startActivity(to, null);
    }

    public void startActivity(Class<?> to, ArrayMap<String, Object> map){
        /**
         * 跳转Activity之前需要判断当前Fragment的Activity是否在最上层
         * 界面快速来回切换可能出现白屏返回崩溃
         */
        if(getMActivity().getClass().getName().equals(getCurrentActivityName())){
            Intent intent = new Intent(getMActivity(), to);
            if(null != map && !map.isEmpty()){
                for(int i = 0, len = map.size(); i < len; i++){
                    String key = map.keyAt(i);
                    Object value = map.valueAt(i);
                    if(value instanceof Integer){
                        intent.putExtra(key, Integer.parseInt(value.toString()));
                    }else if(value instanceof String){
                        intent.putExtra(key, value.toString());
                    }else if(value instanceof Serializable){
                        intent.putExtra(key, (Serializable)value);
                    }else if(value instanceof Boolean){
                        intent.putExtra(key, Boolean.valueOf(value.toString()));
                    }
                }
                map.clear();
            }
            startActivity(intent);
        }
    }

    //获取最上层的activity
    private String getCurrentActivityName() {
        ActivityManager am = (ActivityManager) getMActivity().getSystemService(Activity.ACTIVITY_SERVICE);
        @SuppressWarnings("deprecation")
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
        ComponentName componentInfo = taskInfo.get(0).topActivity;
        return componentInfo.getClassName();
    }
}
