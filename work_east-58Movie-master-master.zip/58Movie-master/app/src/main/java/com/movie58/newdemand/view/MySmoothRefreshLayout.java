package com.movie58.newdemand.view;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

import com.zhy.autolayout.utils.AutoUtils;

import me.dkzwm.widget.srl.RefreshingListenerAdapter;
import me.dkzwm.widget.srl.SmoothRefreshLayout;
import me.dkzwm.widget.srl.extra.footer.MaterialFooter;
import me.dkzwm.widget.srl.extra.header.MaterialHeader;
import me.dkzwm.widget.srl.indicator.IIndicator;
import me.dkzwm.widget.srl.utils.PixelUtl;

//com.movie58.a.view.MySmoothRefreshLayout
public class MySmoothRefreshLayout extends SmoothRefreshLayout {


    private MyRefreshAndLoadListen refreshAndLoadListen;

    public void setMyRefreshAndLoadListen(MyRefreshAndLoadListen refreshAndLoadListen) {
        this.refreshAndLoadListen = refreshAndLoadListen;
    }

    public MySmoothRefreshLayout(Context context) {
        super(context);
        init(context);
    }

    public MySmoothRefreshLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MySmoothRefreshLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public void setEnableRefresh(boolean f) {
        setDisableRefresh(!f);
    }

    public void setEnableLoadmore(boolean f) {
        setDisableLoadMore(!f);
    }

    public void startRefresh() {
        autoRefresh(true);
    }

    private void init(Context context) {
        MaterialHeader header = new MaterialHeader(context);
//        header.setP
//        header.setColorSchemeColors();
        header.setPadding(0, PixelUtl.dp2px(context, 20), 0, PixelUtl.dp2px(context, 20));
        setHeaderView(header);
        setEnablePullToRefresh(false);
        setEnableNextPtrAtOnce(false);
        setDisableLoadMore(true);
        MaterialFooter footer = new MaterialFooter(context);
        int[] src = {Color.BLACK};
        footer.setProgressBarColors(src);
        footer.setProgressBarWidth(5);
        footer.setProgressBarRadius(AutoUtils.getPercentWidthSize(20));
        setFooterView(footer);
//        setDisableRefresh();
        setIndicatorOffsetCalculator(new IIndicator.IOffsetCalculator() {
            @Override
            public float calculate(int status, int currentPos, float offset) {
                if (status == IIndicator.DEFAULT_RATIO_TO_REFRESH) {
                    if (offset < 0) {

                        return offset;
                    }
                    return (float) Math.pow(Math.pow(currentPos / 2, 1.28d) + offset, 1 / 1.28d) * 2 - currentPos;
                } else if (status == IIndicator.DEFAULT_RATIO_TO_REFRESH) {
                    if (offset > 0) {

                        return offset;
                    }
                    return -((float) Math.pow(Math.pow(currentPos / 2, 1.28d) - offset, 1 / 1.28d) * 2 - currentPos);
                } else {
                    if (offset > 0) {
                        return (float) Math.pow(offset, 1 / 1.28d) * 2;
                    } else if (offset < 0) {
                        return -(float) Math.pow(-offset, 1 / 1.28d) * 2;
                    } else {
                        return offset;
                    }
                }
            }
        });

        setOnRefreshListener(new RefreshingListenerAdapter() {
            @Override
            public void onRefreshing() {
                if (refreshAndLoadListen != null) {
                    refreshAndLoadListen.refreshStart();
                }
            }

            @Override
            public void onLoadingMore() {
                if (refreshAndLoadListen != null) {
                    refreshAndLoadListen.loadMoreStart();
                }
            }
        });
    }


    public void loadMoreReturn() {
        setDisableLoadMore(false);
//        setDisablePerformRefresh(true);
        setDisablePerformLoadMore(true);
        getFooterView().getView().setVisibility(View.GONE);
    }

    public void loadMoreReturn2() {
        setDisableLoadMore(false);
        setDisablePerformRefresh(true);
        setDisablePerformLoadMore(true);
        setEnableKeepRefreshView(false);
        getHeaderView().getView().setVisibility(View.GONE);
        getFooterView().getView().setVisibility(View.GONE);
    }

    public void finishLoadmore() {
        refreshComplete();
    }

    public void finishRefreshing() {
        refreshComplete();
    }

}
