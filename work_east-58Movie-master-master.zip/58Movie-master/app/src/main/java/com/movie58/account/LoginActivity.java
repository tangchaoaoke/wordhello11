package com.movie58.account;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/24 0024.
 */
public class LoginActivity extends BaseUseActivity {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.layout_tab)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp)
    ViewPager vp;

    private final String[] mTitles = {"密码登录", "快速登录"};
    ArrayList<Fragment> list = new ArrayList<>();

    @Override
    protected void initView() {
        tvTitle.setText("欢迎登录");
        tvRight.setText("注册");
        list.add(LoginFragment.newInstance());
        list.add(LoginFastFragment.newInstance());
        layoutTab.setViewPager(vp, mTitles, this, list);
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv_right:
                startActivity(RegisterActivity.class);
                break;
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_login;
    }

}
