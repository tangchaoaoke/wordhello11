package com.movie58.bean;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * Created by yangxing on 2019/5/17 0017.
 */
public class MovieReviewInfo  implements MultiItemEntity {
    /**
     * vod_id : 108
     * send_user_name : 昵称
     * reply_name : null
     * top_num : 0
     * down_num : 0
     * create_time : 2019-05-17 17:14:16
     * update_time : 2019-05-17 17:14:16
     * is_reply : 0
     * comments : 呃呃
     * id : 5
     * avatar : http://47.105.218.54/upload/member/20190514/947b7c4a312144c5687403185c79ba86.jpeg
     * is_top : 0
     */

    private String vod_id;
    private String send_user_name;
    private Object reply_name;
    private int top_num;
    private int down_num;
    private String create_time;
    private String update_time;
    private int is_reply;
    private String comments;
    private int id;
    private String avatar;
    private int is_top;
    private int send_user_id;

    private String advert_name;
    private String advert_url;
    private String advert_img;
    private String advert_desc;
    private int is_advert;

    public String getAdvert_name() {
        return advert_name;
    }

    public void setAdvert_name(String advert_name) {
        this.advert_name = advert_name;
    }

    public String getAdvert_url() {
        return advert_url;
    }

    public void setAdvert_url(String advert_url) {
        this.advert_url = advert_url;
    }

    public String getAdvert_img() {
        return advert_img;
    }

    public void setAdvert_img(String advert_img) {
        this.advert_img = advert_img;
    }

    public String getAdvert_desc() {
        return advert_desc;
    }

    public void setAdvert_desc(String advert_desc) {
        this.advert_desc = advert_desc;
    }

    public int getIs_advert() {
        return is_advert;
    }

    public void setIs_advert(int is_advert) {
        this.is_advert = is_advert;
    }

    public int getSend_user_id() {
        return send_user_id;
    }

    public void setSend_user_id(int send_user_id) {
        this.send_user_id = send_user_id;
    }

    public String getVod_id() {
        return vod_id;
    }

    public void setVod_id(String vod_id) {
        this.vod_id = vod_id;
    }

    public String getSend_user_name() {
        return send_user_name;
    }

    public void setSend_user_name(String send_user_name) {
        this.send_user_name = send_user_name;
    }

    public Object getReply_name() {
        return reply_name;
    }

    public void setReply_name(Object reply_name) {
        this.reply_name = reply_name;
    }

    public int getTop_num() {
        return top_num;
    }

    public void setTop_num(int top_num) {
        this.top_num = top_num;
    }

    public int getDown_num() {
        return down_num;
    }

    public void setDown_num(int down_num) {
        this.down_num = down_num;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public int getIs_reply() {
        return is_reply;
    }

    public void setIs_reply(int is_reply) {
        this.is_reply = is_reply;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getIs_top() {
        return is_top;
    }

    public void setIs_top(int is_top) {
        this.is_top = is_top;
    }

    @Override
    public int getItemType() {
        return getIs_advert();
    }
}
