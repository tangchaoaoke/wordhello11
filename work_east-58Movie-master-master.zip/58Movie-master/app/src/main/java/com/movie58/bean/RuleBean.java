package com.movie58.bean;

import java.util.List;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class RuleBean {
    /**
     * invite_count : 0
     * gold_num : 2
     * continuous_count : 0
     * rule_list : [{"id":2,"rule_name":"每日签到","rule_desc":"每日点击签到奖励10个","gold_num":10,"top_limit":1,"rule_code":"sign_in","rule_img":"http://47.105.218.54/upload/member/20190524/4d7ec4abcd8ebf89f726fdec565144a6.png","grant_button_title":"签到","create_time":"2019-05-26 13:46:36","update_time":null,"sort":0,"complete_status":0},{"id":1,"rule_name":"邀请用户注册","rule_desc":"邀请1位好友注册奖励100个\r\n","gold_num":100,"top_limit":1,"rule_code":"invite","rule_img":"http://47.105.218.54/upload/member/20190524/f8724c7826e85d355814b7f655e4dc23.png","grant_button_title":"去完成","create_time":"2019-05-26 13:46:36","update_time":null,"sort":1,"complete_status":0},{"id":4,"rule_name":"点击广告","rule_desc":"每日点击广告奖励10个","gold_num":10,"top_limit":1,"rule_code":"play_advert","rule_img":"http://47.105.218.54/upload/member/20190524/121ba69e9d5ba66e260436eed3a228bd.png","grant_button_title":"去完成","create_time":"2019-05-26 13:46:36","update_time":null,"sort":2,"complete_status":0},{"id":5,"rule_name":"观影满30分钟","rule_desc":"每日观看视频满30分钟奖励10个","gold_num":10,"top_limit":1,"rule_code":"play_vod","rule_img":"http://47.105.218.54/upload/member/20190524/a44929b407e74cb26f77027a64b3d9ba.png","grant_button_title":"去完成","create_time":"2019-05-26 13:46:36","update_time":null,"sort":3,"complete_status":0},{"id":3,"rule_name":"保存官网地址","rule_desc":"缓存官网图片到本地","gold_num":20,"top_limit":1,"rule_code":"save_url","rule_img":"http://47.105.218.54/upload/member/20190524/9d9967d9a86bde284df63ebdad59d19b.png","grant_button_title":"保存","create_time":"2019-05-26 13:46:36","update_time":null,"sort":4,"complete_status":0},{"id":6,"rule_name":"分享专题","rule_desc":"每日首次分享专题页奖励5个","gold_num":5,"top_limit":1,"rule_code":"project_share","rule_img":"http://47.105.218.54/upload/member/20190524/210e038a0d1affd658aa73eff5c2221d.png","grant_button_title":"去分享","create_time":"2019-05-26 13:46:36","update_time":1558669539,"sort":5,"complete_status":0},{"id":7,"rule_name":"分享影片到微信","rule_desc":"每日首次分享影片到微信或朋友圈奖励5个","gold_num":5,"top_limit":1,"rule_code":"vod_share_wechat","rule_img":"http://47.105.218.54/upload/member/20190524/f2c56b35c8a8ce00318e49e3ded92629.png","grant_button_title":"去分享","create_time":"2019-05-26 13:46:36","update_time":1558669643,"sort":6,"complete_status":0},{"id":8,"rule_name":"分享影片到QQ","rule_desc":"每日首次分享影片到QQ或QQ空间奖励5个","gold_num":5,"top_limit":1,"rule_code":"vod_share_qq","rule_img":"http://47.105.218.54/upload/member/20190524/fc77af9b32b7a86a7422b17126fd8347.png","grant_button_title":"去分享","create_time":"2019-05-26 13:46:36","update_time":1558669684,"sort":7,"complete_status":0},{"id":9,"rule_name":"分享影片到微博","rule_desc":"每日首次分享影片到微博奖励5个","gold_num":5,"top_limit":1,"rule_code":"vod_share_wb","rule_img":"http://47.105.218.54/upload/member/20190524/0822390d290015eb9b788b5b1569c4d9.png","grant_button_title":"去分享","create_time":"2019-05-26 13:46:36","update_time":1558669709,"sort":8,"complete_status":0}]
     */

    private int invite_count;
    private int gold_num;
    private int continuous_count;
    private List<RuleListBean> rule_list;

    public int getInvite_count() {
        return invite_count;
    }

    public void setInvite_count(int invite_count) {
        this.invite_count = invite_count;
    }

    public int getGold_num() {
        return gold_num;
    }

    public void setGold_num(int gold_num) {
        this.gold_num = gold_num;
    }

    public int getContinuous_count() {
        return continuous_count;
    }

    public void setContinuous_count(int continuous_count) {
        this.continuous_count = continuous_count;
    }

    public List<RuleListBean> getRule_list() {
        return rule_list;
    }

    public void setRule_list(List<RuleListBean> rule_list) {
        this.rule_list = rule_list;
    }

    public static class RuleListBean {
        /**
         * id : 2
         * rule_name : 每日签到
         * rule_desc : 每日点击签到奖励10个
         * gold_num : 10
         * top_limit : 1
         * rule_code : sign_in
         * rule_img : http://47.105.218.54/upload/member/20190524/4d7ec4abcd8ebf89f726fdec565144a6.png
         * grant_button_title : 签到
         * create_time : 2019-05-26 13:46:36
         * update_time : null
         * sort : 0
         * complete_status : 0
         */

        private int id;
        private String rule_name;
        private String rule_desc;
        private int gold_num;
        private int gold_num_max;
        private int top_limit;
        private String rule_code;
        private String rule_img;
        private String grant_button_title;
        private String create_time;
        private Object update_time;
        private int sort;
        private int complete_status;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getRule_name() {
            return rule_name;
        }

        public int getGold_num_max() {
            return gold_num_max;
        }

        public void setGold_num_max(int gold_num_max) {
            this.gold_num_max = gold_num_max;
        }

        public void setRule_name(String rule_name) {
            this.rule_name = rule_name;
        }

        public String getRule_desc() {
            return rule_desc;
        }

        public void setRule_desc(String rule_desc) {
            this.rule_desc = rule_desc;
        }

        public int getGold_num() {
            return gold_num;
        }

        public void setGold_num(int gold_num) {
            this.gold_num = gold_num;
        }

        public int getTop_limit() {
            return top_limit;
        }

        public void setTop_limit(int top_limit) {
            this.top_limit = top_limit;
        }

        public String getRule_code() {
            return rule_code;
        }

        public void setRule_code(String rule_code) {
            this.rule_code = rule_code;
        }

        public String getRule_img() {
            return rule_img;
        }

        public void setRule_img(String rule_img) {
            this.rule_img = rule_img;
        }

        public String getGrant_button_title() {
            return grant_button_title;
        }

        public void setGrant_button_title(String grant_button_title) {
            this.grant_button_title = grant_button_title;
        }

        public String getCreate_time() {
            return create_time;
        }

        public void setCreate_time(String create_time) {
            this.create_time = create_time;
        }

        public Object getUpdate_time() {
            return update_time;
        }

        public void setUpdate_time(Object update_time) {
            this.update_time = update_time;
        }

        public int getSort() {
            return sort;
        }

        public void setSort(int sort) {
            this.sort = sort;
        }

        public int getComplete_status() {
            return complete_status;
        }

        public void setComplete_status(int complete_status) {
            this.complete_status = complete_status;
        }
    }
}
