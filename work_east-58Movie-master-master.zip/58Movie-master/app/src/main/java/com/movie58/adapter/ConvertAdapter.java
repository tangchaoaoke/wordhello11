package com.movie58.adapter;

import android.support.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.ConvertInfo;

import java.util.List;

/**
 * Created by yangxing on 2019/5/22 0022.
 */
public class ConvertAdapter extends BaseQuickAdapter<ConvertInfo, BaseViewHolder> {

    public ConvertAdapter(@Nullable List<ConvertInfo> data) {
        super(R.layout.item_convert, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, ConvertInfo item) {
        helper.setText(R.id.tv_time, item.getExchange_time())
                .setText(R.id.tv_count, "+" + item.getExchange_gold())
                .setText(R.id.tv_total, item.getAfter_exchange_gold());
    }
}
