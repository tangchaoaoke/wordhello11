package com.movie58.newdemand.ui.history;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.App;
import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.movie58.newdemand.database.Record;

import com.movie58.newdemand.utils.ImagesUtils;
import com.movie58.newdemand.view.MySmoothRefreshLayout;
import com.movie58.home.MovieDetailActivity;
import com.movie58.util.ToolUtil;
import com.zhy.autolayout.utils.AutoUtils;


import org.xutils.DbManager;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.util.ArrayList;


import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class PlayRecordNoLogin2Aty extends BaseAty {

    @BindView(R.id.tv_title)
    TextView tv_title;
    @BindView(R.id.tv_right)
    TextView tv_right;
    @BindView(R.id.relay)
    RelativeLayout relay;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    @BindView(R.id.refreshLayout)
    MySmoothRefreshLayout refreshLayout;
    @BindView(R.id.linlay_bottom)
    LinearLayout linlay_bottom;
    private DbManager db;

    private ArrayList<Record> list;
    private ArrayList<Integer> list_cb;
    private ArrayList<String> list_id;


    @Override
    public int getLayoutId() {
        return R.layout.aty_playrecord_nologin;
    }

    @Override
    public void initPresenter() {

    }

    @Override
    public void initView() {
        list_cb = new ArrayList<>();
        list_id = new ArrayList<>();
    }

    @Override
    public void requestData() {

    }

    private GoldRecyclerAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        db = x.getDb(((App) getApplicationContext()).getDaoConfig());
        initTopview(relay, relay_top);
        tv_title.setText("播放历史");
        list = new ArrayList<>();
        tv_right.setVisibility(View.VISIBLE);
        tv_right.setText("编辑");
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        adapter = new GoldRecyclerAdapter(this);
        recyclerview.setAdapter(adapter);
        refreshLayout.setEnableRefresh(false);
        refreshLayout.setEnableLoadmore(false);
        refreshLayout.loadMoreReturn();
        selectData();
    }

    public void selectData() {
        ArrayList<Record> list2 = new ArrayList<>();
        try {
            list2 = (ArrayList<Record>) db.selector(Record.class).orderBy("id", true).findAll();
        } catch (DbException e) {
            e.printStackTrace();
        }
        if (list2 == null) {
            return;
        }
        list_id.clear();
        list_cb.clear();
        list.clear();
        tv_right.setText("编辑");
        linlay_bottom.setVisibility(View.GONE);
        list.addAll(list2);
        for (int i = 0; i < list.size(); i++) {
            list_cb.add(0);
        }
        adapter.notifyDataSetChanged();
    }


    @OnClick({R.id.relay_back, R.id.tv_right, R.id.tv_del, R.id.tv_all})
    void click(View v) {
        switch (v.getId()) {
            case R.id.relay_back:
                finish();
                break;
            case R.id.tv_right:
                if (list == null || list.size() == 0) {
                    return;
                }
                if (tv_right.getText().toString().equals("编辑")) {
                    linlay_bottom.setVisibility(View.VISIBLE);
                    tv_right.setText("取消");

                    for (int i = 0; i < list_cb.size(); i++) {
                        list_cb.set(i, 0);
                    }
                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    linlay_bottom.setVisibility(View.GONE);
                    tv_right.setText("编辑");

                    for (int i = 0; i < list_cb.size(); i++) {
                        list_cb.set(i, 0);
                    }
                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }
                }
                break;
            case R.id.tv_del:
                for (int i = 0; i < list_cb.size(); i++) {
                    if (list_cb.get(i) == 1) {
                        list_id.add(list.get(i).getId() + "");
                    }
                }
                if (list_id == null || list_id.size() == 0) {
                    return;
                }
                for (int i = 0; i < list_id.size(); i++) {
                    try {
                        db.delete(Record.class, WhereBuilder.b("id", "=", list_id.get(i)));
                    } catch (DbException e) {
                        e.printStackTrace();
                    }
                }
                selectData();
                break;
            case R.id.tv_all:
                for (int i = 0; i < list_cb.size(); i++) {
                    list_cb.set(i, 1);
                }
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
                break;
        }
    }


    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_playrecord_onlogin, parent, false);
            return new GoldRecyclerAdapter.fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            fGoldViewHolder holder1 = (fGoldViewHolder) holder;
            ImagesUtils.disImg2(PlayRecordNoLogin2Aty.this, list.get(position).getSource_img(),
                    holder1.iv_player, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);
            holder1.tv_name.setText(list.get(position).getSource_name());
            String time = ToolUtil.stringForTime(Integer.parseInt(list.get(position).getTotal_time()));
            holder1.tv_time.setText(time);
            int time2 = Integer.parseInt(list.get(position).getTotal_time()) - Integer.parseInt(list.get(position).getPlayed_time());
            holder1.tv_progress.setText("剩余" + ToolUtil.stringForTime(time2));

            if (tv_right.getText().toString().equals("编辑")) {
                holder1.cb.setVisibility(View.GONE);
            } else {
                holder1.cb.setVisibility(View.VISIBLE);
            }
            if (list_cb.get(position) == 1) {
                holder1.cb.setImageResource(R.drawable.radio_sel);
            } else {
                holder1.cb.setImageResource(R.drawable.radio_nor);
            }

            holder1.cb.setOnClickListener(v -> {
                if (list_cb.get(position) == 1) {
                    list_cb.set(position, 0);
                } else {
                    list_cb.set(position, 1);
                }
                notifyDataSetChanged();
            });

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("id", list.get(position).getIds());
                    bundle.putString("played_time", list.get(position).getPlayed_time());
                    startActivity(MovieDetailActivity.class, bundle);
                }
            });

        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.iv_player)
            ImageView iv_player;
            @BindView(R.id.tv_name)
            TextView tv_name;
            @BindView(R.id.tv_time)
            TextView tv_time;
            @BindView(R.id.tv_progress)
            TextView tv_progress;
            @BindView(R.id.cb)
            ImageView cb;

            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }

}
