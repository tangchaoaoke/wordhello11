package com.movie58.view;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.carlt.networklibs.NetType;
import com.carlt.networklibs.utils.NetworkUtils;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.ui.tscreen.DeviceListAty;
import com.movie58.bean.DanmuInfo;
import com.movie58.event.Event;
import com.movie58.home.MovieDetailActivity;
import com.movie58.util.OnDoubleClickListener;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.jzvd.JzvdStd;
import master.flame.danmaku.controller.IDanmakuView;
import master.flame.danmaku.danmaku.model.BaseDanmaku;
import master.flame.danmaku.danmaku.model.DanmakuTimer;
import master.flame.danmaku.danmaku.model.IDanmakus;
import master.flame.danmaku.danmaku.model.IDisplayer;
import master.flame.danmaku.danmaku.model.android.DanmakuContext;
import master.flame.danmaku.danmaku.model.android.Danmakus;
import master.flame.danmaku.danmaku.parser.BaseDanmakuParser;
import master.flame.danmaku.ui.widget.DanmakuView;

/**
 * Created by yangxing on 2019/5/29 0029.
 */
public class VideoPlayer extends JzvdStd {


    private BaseDanmakuParser mParser;//解析器对象
    private IDanmakuView mDanmakuView;//弹幕view
    private DanmakuContext mDanmakuContext;

    private EditText etDanmu;
    private SuperButton btnDanmu;
    private ImageView ivDanmu, ivBack, ivAd;
    TextView tvSpeed, tvTime, tv_toup;
    RelativeLayout layoutSpeed, layoutAd;
    RadioGroup rgSpeed;
    RadioButton btn10, btn125, btn15, btn20;
    int speedIndex;
    private String adInfo;
    boolean danmuShow = true;
    boolean danmuAd = false;
    public boolean isComplete = false;
    public boolean isAd = false;

    Button btnCancel, btnGoon;
    RelativeLayout layoutMobile;

    List<DanmuInfo> listDanmu = new ArrayList<>();
    private long mDanmakuStartSeekPosition = -1;
    private Context context;

    public VideoPlayer(Context context) {
        super(context);
        this.context = context;
    }

    public VideoPlayer(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
    }

    private String url_play;

    public void setPlayUrl(String url_play) {
        this.url_play = url_play;
    }

    @Override
    public void setScreenNormal() {
        super.setScreenNormal();
        ivDanmu.setVisibility(GONE);
        tvSpeed.setVisibility(GONE);
        ivBack.setVisibility(VISIBLE);
        tv_toup.setVisibility(GONE);
    }

    @Override
    public void setScreenFullscreen() {
        super.setScreenFullscreen();
        ivBack.setVisibility(GONE);
        ivDanmu.setVisibility(VISIBLE);
        tv_toup.setVisibility(VISIBLE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M)
            tvSpeed.setVisibility(View.VISIBLE);

        if (jzDataSource.objects == null) {
            Object[] object = {2};
            jzDataSource.objects = object;
            speedIndex = 2;
        } else {
            speedIndex = (int) jzDataSource.objects[0];
        }
        if (speedIndex == 2) {
            tvSpeed.setText("倍速");
        } else {
            tvSpeed.setText(getSpeedFromIndex(speedIndex) + "x");
        }
    }

    private float getSpeedFromIndex(int index) {
        float ret = 0f;
        if (index == 0) {
            ret = 0.5f;
        } else if (index == 1) {
            ret = 0.75f;
        } else if (index == 2) {
            ret = 1.0f;
        } else if (index == 3) {
            ret = 1.25f;
        } else if (index == 4) {
            ret = 1.5f;
        } else if (index == 5) {
            ret = 1.75f;
        } else if (index == 6) {
            ret = 2.0f;
        }
        return ret;
    }


    @Override
    public void init(Context context) {
        super.init(context);
        SAVE_PROGRESS = false;
        ivBack = findViewById(R.id.back1);
        ivBack.setOnClickListener(this);
        etDanmu = findViewById(R.id.et_danmu);
        btnDanmu = findViewById(R.id.btn_danmu);

        mDanmakuView = (DanmakuView) findViewById(R.id.danmaku_view);

        ivDanmu = findViewById(R.id.iv_danmu);
        tv_toup = findViewById(R.id.tv_toup);
        ivDanmu.setOnClickListener(this);
        tvSpeed = findViewById(R.id.tv_speed);
        tvSpeed.setOnClickListener(this);
        layoutSpeed = findViewById(R.id.layout_speed);
        layoutSpeed.setOnClickListener(this);
        rgSpeed = findViewById(R.id.rg_speed);
        btn10 = findViewById(R.id.btn_10);
        btn125 = findViewById(R.id.btn_125);
        btn15 = findViewById(R.id.btn_15);
        btn20 = findViewById(R.id.btn_20);
        layoutAd = findViewById(R.id.layout_ad);
        tvTime = findViewById(R.id.ad_time);
        ivAd = findViewById(R.id.iv_ad);
        layoutMobile = findViewById(R.id.layout_mobile);
        btnCancel = findViewById(R.id.btn_cancel);
        btnGoon = findViewById(R.id.btn_goon);

        rgSpeed.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.btn_10:
                        speedIndex = 2;
                        tvSpeed.setText("倍数");
                        break;
                    case R.id.btn_125:
                        speedIndex = 3;
                        tvSpeed.setText("1.25x");
                        break;
                    case R.id.btn_15:
                        speedIndex = 4;
                        tvSpeed.setText("1.5x");
                        break;
                    case R.id.btn_20:
                        speedIndex = 6;
                        tvSpeed.setText("2.0x");
                        break;
                }
                mediaInterface.setSpeed(getSpeedFromIndex(speedIndex));
                jzDataSource.objects[0] = speedIndex;
                layoutSpeed.setVisibility(GONE);
            }
        });

        etDanmu.setOnClickListener(this);
        etDanmu.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    goOnPlayOnPause();
                } else {
                    goOnPlayOnResume();
                }
            }
        });

        tv_toup.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(url_play)) {
                    return;
                }
                if (context instanceof MovieDetailActivity) {
//                    Intent intent = new Intent(context, DevicePlayAty.class);
                    Intent intent = new Intent(context, DeviceListAty.class);
                    intent.putExtra("json_details", ((MovieDetailActivity) context).getJsonDetails());
                    intent.putExtra("play_anthology", ((MovieDetailActivity) context).getPlayAnthology());
                    context.startActivity(intent);
                }
            }
        });

        //初始化弹幕显示
        initDanmaku();
        btnDanmu.setOnClickListener(this);
        btnGoon.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_player;
    }

    public void setAd(String info) {
        adInfo = info;
        start();
//        if (adInfo == null || adInfo.getVod_advert() == null) {
//            start(); //开始播放
//            return;
//        }

//        PicassoUtils.LoadImageWithDetfult(getContext(), adInfo.getVod_advert().getAdvert_img(), ivAd, R.drawable.pic_emptypage_failure);
//        layoutAd.setVisibility(VISIBLE);
//        if (!TextUtils.isEmpty(adInfo.getVod_advert().getAdvert_url())) {
//            ivAd.setOnClickListener(new OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    EventBus.getDefault().post(new Event(Event.CODE_19_MODE).setObj1(adInfo));
//                }
//            });
//        }
//        isAd = true;
//        android.os.CountDownTimer timer = new android.os.CountDownTimer(5000, 1000) {
//
//            @SuppressLint("DefaultLocale")
//            @Override
//            public void onTick(long millisUntilFinished) {
//                tvTime.setText(millisUntilFinished / 1000 + "");
//            }
//
//            @Override
//            public void onFinish() {
//                tvTime.setText("0");
//                layoutAd.setVisibility(GONE);
//                VideoPlayer.this.start(); //开始播放
//                isAd = false;
//            }
//        };
//        timer.start();
    }

    public boolean isAd() {
        return isAd;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (OnDoubleClickListener.CanClick.NoClick()) return;
        switch (v.getId()) {
            case R.id.back1:
                EventBus.getDefault().post(new Event(Event.CODE_15_MESSAGE_UNREAD));
                break;
            case R.id.btn_danmu:
                String danmu = etDanmu.getText().toString().trim();
                if (TextUtils.isEmpty(danmu)) {
                    ToastUtils.show("写点东西在弹吧~");
                    return;
                }
                EventBus.getDefault().post(new Event(Event.CODE_11_SCHOOL_RESULT_CLICK).setObj1(danmu));
                etDanmu.setText("");
                etDanmu.clearFocus();
                addDanmaku(danmu);
                break;
            case R.id.iv_danmu:
                danmuShow = !danmuShow;
                resolveDanmakuShow(danmuShow);
                break;
            case R.id.tv_speed:
                if (layoutSpeed.getVisibility() == GONE) {
                    layoutSpeed.setVisibility(VISIBLE);
                }
                break;
            case R.id.layout_speed:
                layoutSpeed.setVisibility(GONE);
                break;
            case R.id.et_danmu:
                etDanmu.requestFocus();
                break;
            case R.id.btn_cancel:
                EventBus.getDefault().post(new Event(Event.CODE_17_IM_UNREAD));
                break;
            case R.id.btn_goon:
                layoutMobile.setVisibility(GONE);
                startVideo();
                break;
        }
    }


    public void initDanmaku() {
        // 设置最大显示行数

        HashMap<Integer, Integer> maxLinesPair = new HashMap<Integer, Integer>();
        maxLinesPair.put(BaseDanmaku.TYPE_SCROLL_RL, 6); // 滚动弹幕最大显示5行
        // 设置是否禁止重叠
        HashMap<Integer, Boolean> overlappingEnablePair = new HashMap<Integer, Boolean>();
        overlappingEnablePair.put(BaseDanmaku.TYPE_SCROLL_RL, false);
        overlappingEnablePair.put(BaseDanmaku.TYPE_FIX_TOP, false);

        mDanmakuContext = DanmakuContext.create();
        mDanmakuContext.setDanmakuStyle(IDisplayer.DANMAKU_STYLE_STROKEN, 3)
                .setDanmakuStyle(IDisplayer.DANMAKU_STYLE_STROKEN, 3)//设置描边样式
                .setDuplicateMergingEnabled(false) //设置不合并相同内容弹幕
                .setScrollSpeedFactor(1.2f) //设置弹幕滚动速度缩放比例，越大速度越慢
//                .setScaleTextSize(1.2f) //设置字体缩放比例
                .setMaximumLines(maxLinesPair)
                .preventOverlapping(overlappingEnablePair);
        if (mDanmakuView != null) {
            mParser = getParser();

            mDanmakuView.setCallback(new master.flame.danmaku.controller.DrawHandler.Callback() {
                @Override
                public void updateTimer(DanmakuTimer timer) {

                }

                @Override
                public void drawingFinished() {

                    if (danmuAd) {
                        danmuAd = false;
                        mDanmakuView.removeAllDanmakus(true);
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i < listDanmu.size(); i++) {
                                    addDanmaku(listDanmu.get(i), i);
                                }
                            }
                        }).start();
                    } else {
                        mDanmakuView.seekTo((long) 0); //循环弹幕
                    }
                }

                @Override
                public void danmakuShown(BaseDanmaku danmaku) {
                }

                @Override
                public void prepared() {
                    if (mDanmakuView != null) {
                        mDanmakuView.start();
                        if (getDanmakuStartSeekPosition() != -1) {
                            resolveDanmakuSeek(getDanmakuStartSeekPosition());
                            setDanmakuStartSeekPosition(-1);
                        }
                        resolveDanmakuShow(danmuShow);
                    }
                }
            });
            onPrepareDanmaku();
            mDanmakuView.enableDanmakuDrawingCache(true);
        }
    }

    public BaseDanmakuParser getParser() {
        if (mParser == null) {
            mParser = getDefaultDanmakuParser();
        }
        return mParser;
    }

    public static BaseDanmakuParser getDefaultDanmakuParser() {
        return new BaseDanmakuParser() {
            @Override
            protected IDanmakus parse() {
                return new Danmakus();
            }
        };
    }

    /**
     * 弹幕的显示与关闭
     */
    public void resolveDanmakuShow(boolean show) {
        post(new Runnable() {
            @Override
            public void run() {
                if (show) {
                    mDanmakuView.show();
                    if (ivDanmu != null) {
                        ivDanmu.setImageResource(R.drawable.danmu_on);
                    }
                    etDanmu.setVisibility(VISIBLE);
                    btnDanmu.setVisibility(VISIBLE);
                } else {
                    mDanmakuView.hide();
                    if (ivDanmu != null) {
                        ivDanmu.setImageResource(R.drawable.danmu_off);
                    }
                    etDanmu.setVisibility(INVISIBLE);
                    btnDanmu.setVisibility(INVISIBLE);
                }

            }
        });
    }

    /**
     * 开始播放弹幕
     */
    private void onPrepareDanmaku() {
        if (mDanmakuView != null && !mDanmakuView.isPrepared()) {
            mDanmakuView.prepare(getParser(), mDanmakuContext);
        }
    }

    /**
     * 弹幕偏移
     */
    private void resolveDanmakuSeek(long time) {
        if (mDanmakuView != null && mDanmakuView.isPrepared()) {
            mDanmakuView.seekTo(time);
        }
    }

    /**
     * 释放弹幕控件
     */
    public void releaseDanmaku() {
        if (mDanmakuView != null) {
            mDanmakuView.release();
        }
    }

    public void danmakuOnPause() {
        if (mDanmakuView != null && mDanmakuView.isPrepared()) {
            mDanmakuView.pause();
        }
    }

    public void danmakuOnResume() {
        if (mDanmakuView != null && mDanmakuView.isPrepared() && mDanmakuView.isPaused()) {
            mDanmakuView.resume();
        }
    }

    public void setDanmaKu(List<DanmuInfo> list) {
        listDanmu = list;
    }

    public long getDanmakuStartSeekPosition() {
        return mDanmakuStartSeekPosition;
    }

    public void setDanmakuStartSeekPosition(long danmakuStartSeekPosition) {
        this.mDanmakuStartSeekPosition = danmakuStartSeekPosition;
    }


    /**
     * 模拟添加弹幕数据
     */
    public void addDanmaku(String danmu) {
        BaseDanmaku danmaku = mDanmakuContext.mDanmakuFactory.createDanmaku(BaseDanmaku.TYPE_SCROLL_RL);
        if (danmaku == null || mDanmakuView == null) {
            return;
        }
        danmaku.text = danmu;
        danmaku.padding = 5;
        danmaku.priority = 1;  // 可能会被各种过滤器过滤并隐藏显示，所以提高等级
        danmaku.isLive = false;
        danmaku.setTime(mDanmakuView.getCurrentTime() + 1000);
        danmaku.textSize = 20f * (mParser.getDisplayer().getDensity() - 0.6f);
        danmaku.textColor = Color.WHITE;
        danmaku.textShadowColor = Color.WHITE;
        danmaku.borderColor = getResources().getColor(R.color.color_base);
        mDanmakuView.addDanmaku(danmaku);
    }

    public void addDanmaku(DanmuInfo info, int i) {
        BaseDanmaku danmaku = mDanmakuContext.mDanmakuFactory.createDanmaku(BaseDanmaku.TYPE_SCROLL_RL);
        if (danmaku == null || mDanmakuView == null) {
            return;
        }

        danmaku.text = info.getContent();
        danmaku.padding = 5;
        danmaku.priority = 1;  // 可能会被各种过滤器过滤并隐藏显示，所以提高等级
        danmaku.isLive = false;
        danmaku.setTime(mDanmakuView.getCurrentTime() + i * 1000);
        danmaku.textSize = 20f * (mParser.getDisplayer().getDensity() - 0.6f);
        danmaku.textColor = Color.WHITE;
        danmaku.textShadowColor = Color.WHITE;
        mDanmakuView.addDanmaku(danmaku);

    }

    public void addDanmaku(String info, int i) {
        BaseDanmaku danmaku = mDanmakuContext.mDanmakuFactory.createDanmaku(BaseDanmaku.TYPE_SCROLL_RL);
        if (danmaku == null || mDanmakuView == null) {
            return;
        }
        danmaku.text = info;
        danmaku.padding = 5;
        danmaku.priority = 1;  // 可能会被各种过滤器过滤并隐藏显示，所以提高等级
        danmaku.isLive = false;
        danmaku.setTime(mDanmakuView.getCurrentTime() + i * 1000);
        danmaku.textSize = 20f * (mParser.getDisplayer().getDensity() - 0.6f);
        danmaku.textColor = Color.WHITE;
        danmaku.textShadowColor = Color.WHITE;
        mDanmakuView.addDanmaku(danmaku);

    }


    @Override
    public void onStatePause() {
        super.onStatePause();
        danmakuOnPause();
    }

    @Override
    public void startVideo() {
        super.startVideo();
    }


    public void showMobile() {
        layoutMobile.setVisibility(VISIBLE);
        SAVE_PROGRESS = true;
        mediaInterface.pause();
        onStatePause();
    }

    public void closeMobile() {
        layoutMobile.setVisibility(GONE);
        long pos = getCurrentPositionWhenPlaying();
        if (pos > 0) {
            mediaInterface.start();
            onStatePlaying();
            SAVE_PROGRESS = false;
        } else {
            startVideo();
        }
    }

    public void start() {
        if (NetworkUtils.getNetType() == NetType.WIFI) {
            layoutMobile.setVisibility(GONE);
            startVideo();
        } else if (NetworkUtils.getNetType() == NetType.CMNET || NetworkUtils.getNetType() == NetType.CMWAP) {
            layoutMobile.setVisibility(VISIBLE);
        }
    }

    @Override
    public void showWifiDialog() {
    }

    @Override
    public void onStatePlaying() {
        super.onStatePlaying();
        long time = getCurrentPositionWhenPlaying() / 1000;
        if (time > 0) {
            danmakuOnResume();
        } else {
//            if (adInfo != null && adInfo.getBarrage_advert() != null && !TextUtils.isEmpty(adInfo.getBarrage_advert().getMessage())) {
////                danmuAd = true;
////                addDanmaku(adInfo.getBarrage_advert().getMessage());
////            } else {
////                new Thread(new Runnable() {
////                    @Override
////                    public void run() {
////                        for (int i = 0; i < listDanmu.size(); i++) {
////                            addDanmaku(listDanmu.get(i), i);
////                        }
////                    }
////                }).start();
////            }
//            if (listDanmu!=null&&listDanmu.size()>0){
//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        for (int i = 0; i < listDanmu.size(); i++) {
//                            addDanmaku(listDanmu.get(i), i);
//                        }
//                    }
//                }).start();
//            }

        }
    }

    public void addDanmaku(ArrayList<Map<String, String>> list) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < list.size(); i++) {
                    addDanmaku(list.get(i).get("advert"), i);
                }
            }
        }).start();
    }

    @Override
    public void onStateAutoComplete() {
        super.onStateAutoComplete();
        isComplete = true;
        releaseDanmaku();
        Log.e("kkkkkkkk", "播放完成");
        if (context instanceof MovieDetailActivity) {
            ((MovieDetailActivity) context).onStateAutoComplete();
        }
    }


    /**
     * @param progress 百分比
     * @param position 当前时间
     * @param duration 总时长
     */
    @Override
    public void onProgress(int progress, long position, long duration) {
        super.onProgress(progress, position, duration);
        long totalSeconds = position / 1000;


    }


}
