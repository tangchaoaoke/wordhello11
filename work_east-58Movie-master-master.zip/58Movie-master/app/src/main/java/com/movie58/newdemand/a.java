package com.movie58.newdemand;


import android.widget.EditText;


public class a {

    private EditText editText;

    public void a(){
        editText.setHint("0000");
    }

}
