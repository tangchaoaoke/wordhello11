package com.movie58.account;

import android.text.TextUtils;

import com.blankj.utilcode.util.SPUtils;
import com.movie58.util.SPContant;

/**
 * Created by BunnyBlue on 11/23/15.
 */
public class Account {

    private String userTel;
    private String userId;
    private String userName;
    private String avatar;
    private String token;
    private String sex;
    private String inviteCode; //用户邀请码
    private String level;
    private String gold;
    private String mobile;

    private static Account instance = null;

    private Account() {
    }

    public static Account getInstance() {
        if (null == instance) {
            synchronized (Account.class) {
                if (null == instance) {
                    instance = new Account();
                }
            }
        }
        return instance;
    }

    public String getUserTel() {
        if (TextUtils.isEmpty(userTel)) {
            userTel = SPUtils.getInstance().getString(SPContant.PHONE);
        }
        return userTel;
    }

    public Account setUserTel(String userTel) {
        this.userTel = userTel;
        SPUtils.getInstance().put(SPContant.PHONE, userTel);
        return this;
    }

    public String getUserId() {
        if (TextUtils.isEmpty(userId)) {
            userId = SPUtils.getInstance().getString(SPContant.USER_ID);
        }
        return userId;
    }

    public Account setUserId(String userId) {
        this.userId = userId;
        SPUtils.getInstance().put(SPContant.USER_ID, userId);
        return this;
    }

    public String getUserName() {
        if (TextUtils.isEmpty(userName)) {
            userName = SPUtils.getInstance().getString(SPContant.USER_NAME);
        }
        return userName;
    }


    public Account setMobile(String mobile) {
        this.mobile = mobile;
        SPUtils.getInstance().put(SPContant.MOBILE, mobile);
        return this;
    }

    public String getMobile() {
        if (TextUtils.isEmpty(mobile)) {
            mobile = SPUtils.getInstance().getString(SPContant.MOBILE);
        }
        return mobile;
    }

    public Account setUserName(String userName) {
        this.userName = userName;
        SPUtils.getInstance().put(SPContant.USER_NAME, userName);
        return this;
    }

    public String getAvatar() {
        if (TextUtils.isEmpty(avatar)) {
            avatar = SPUtils.getInstance().getString(SPContant.AVATAR);
        }
        return avatar;
    }

    public Account setAvatar(String avatar) {
        this.avatar = avatar;
        SPUtils.getInstance().put(SPContant.AVATAR, avatar);
        return this;
    }

    public String getToken() {
        if (TextUtils.isEmpty(token)) {
            token = SPUtils.getInstance().getString(SPContant.TOKEN);
        }
        return token;
    }

    public Account setToken(String token) {
        this.token = token;
        SPUtils.getInstance().put(SPContant.TOKEN, token);
        return this;
    }

    public String getSex() {
        if (TextUtils.isEmpty(sex)) {
            sex = SPUtils.getInstance().getString(SPContant.SEX);
        }
        return sex;
    }

    public Account setSex(String sex) {
        this.sex = sex;
        SPUtils.getInstance().put(SPContant.SEX, sex);
        return this;
    }

    public String getInviteCode() {
        if (TextUtils.isEmpty(inviteCode)) {
            inviteCode = SPUtils.getInstance().getString(SPContant.INVITE_CODE);
        }
        return inviteCode;
    }

    public Account setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
        SPUtils.getInstance().put(SPContant.INVITE_CODE, inviteCode);
        return this;
    }

    public String getLevel() {
        if (TextUtils.isEmpty(level)) {
            level = SPUtils.getInstance().getString(SPContant.LEVEL);
        }
        return level;
    }

    public Account setLevel(String level) {
        this.level = level;
        SPUtils.getInstance().put(SPContant.LEVEL, level);
        return this;
    }

    public String getGold() {
        if (TextUtils.isEmpty(gold)) {
            gold = SPUtils.getInstance().getString(SPContant.GOLD);
        }
        return gold;
    }

    public Account setGold(String gold) {
        this.gold = gold;
        SPUtils.getInstance().put(SPContant.GOLD, gold);
        return this;
    }

    public boolean isLogined() {
        return !TextUtils.isEmpty(getToken());
    }

    public void loginOut() {
        setUserId("")
                .setUserTel("")
                .setUserId("")
                .setUserName("")
                .setAvatar("")
                .setSex("")
                .setToken("")
                .setInviteCode("")
                .setGold("")
                .setToken("")
                .setLevel("");

    }
}
