package com.movie58.task;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.InviteInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.share.ShareActivity;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class InviteListActivity extends BaseUseActivity {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv1)
    TextView tv1;
    @BindView(R.id.tv_level)
    SuperButton tvLevel;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    int page = 1;
    int strCount;

    InviteAdapter mAdapter;


    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        strCount = b.getInt("count");
    }

    @Override
    protected void initView() {
        tv1.setText(strCount + "人");
        tvTitle.setText("我的邀请");


        mAdapter = new InviteAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).colorResId(R.color.line).build());
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.addHeaderView(LayoutInflater.from(getMActivity()).inflate(R.layout.header_invite, new RelativeLayout(getMActivity())));

        layoutRefresh.autoRefresh();
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    @OnClick({R.id.iv_back, R.id.tv_level})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv_level:
                startActivity(ShareActivity.class);
                break;
        }
    }

    private void getList(){
        Kalle.get(HttpUrl.INVITE_LIST)
                .param("page", page)
                .param("szie", 10)
                .perform(new LoadingCallback<List<InviteInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<InviteInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else {
                            ToastUtils.show(response.failed());
                            layoutRefresh.finishRefresh();
                            layoutRefresh.finishLoadMore();
                        }
                    }
                });
    }

    private void initList(List<InviteInfo> list){


        if (list == null) {
            list = new ArrayList<>();
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
            layoutRefresh.finishRefresh();
        }else{
            mAdapter.addData(list);
            layoutRefresh.finishLoadMore();
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }


    @Override
    protected int getLayout() {
        return R.layout.activity_invite_list;
    }

    class InviteAdapter extends BaseQuickAdapter<InviteInfo, BaseViewHolder>{

        public InviteAdapter(@Nullable List<InviteInfo> data) {
            super(R.layout.item_invite, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, InviteInfo item) {
            helper.setText(R.id.tv_name, item.getInvited_user_name())
                .setText(R.id.tv_time, item.getCreate_time());
        }
    }

}
