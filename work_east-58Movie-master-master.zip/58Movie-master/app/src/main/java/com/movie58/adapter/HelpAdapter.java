package com.movie58.adapter;

import android.support.annotation.Nullable;

import com.allen.library.SuperTextView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.HelpInfo;

import java.util.List;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class HelpAdapter extends BaseQuickAdapter<HelpInfo, BaseViewHolder> {

    public HelpAdapter(@Nullable List<HelpInfo> data) {
        super(R.layout.item_help, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, HelpInfo item) {
        helper.setText(R.id.tv_content, item.getContent());
        SuperTextView tv = helper.getView(R.id.tv_name);
        tv.setLeftString(item.getTitle());
    }
}
