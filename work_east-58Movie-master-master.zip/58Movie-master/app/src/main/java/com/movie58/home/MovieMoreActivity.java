package com.movie58.home;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.movie58.R;
import com.movie58.adapter.MovieAllAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.MovieListInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.FormBody;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/15 0015.
 */
public class MovieMoreActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.iv_right)
    ImageView ivRight;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.tv_null)
    TextView tvNull;

    String strTitle, sourceType, sourceTag;
    int catId;
    int page = 1;
    MovieAllAdapter mAdapter;


    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        strTitle = b.getString("title");
        sourceTag = b.getString("tag");
        sourceType = b.getString("type");
        catId = b.getInt("catid");
    }

    @Override
    protected void initView() {
        tvTitle.setText(strTitle);
        mAdapter = new MovieAllAdapter(new ArrayList<>());
        mAdapter.bindToRecyclerView(rvList);
        rvList.setLayoutManager(new GridLayoutManager(getMActivity(),3));

        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });


        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("id", mAdapter.getItem(position).getId());
                    startActivity(MovieDetailActivity.class, map);
//                }else{
//                    startActivity(LoginActivity.class);
//                }
            }
        });
    }

    @OnClick({R.id.iv_back})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
        }
    }

    @Override
    protected void initData() {
        layoutRefresh.autoRefresh();
    }

    private void getList(){
        FormBody.Builder builder = FormBody.newBuilder();
        builder.param("cat_id", catId)
                .param("page", page)
                .param("size", 10)
                .param("is_more", true);
        if (!TextUtils.isEmpty(sourceTag)) {
            builder.param("source_tag", sourceTag);
        }
        if (!TextUtils.isEmpty(sourceType)) {
            builder.param("source_type", sourceType);
        }

        Kalle.post(HttpUrl.CHANGE_MORE)
                .tag(tag)
                .body(builder.build())
                .perform(new NormalCallback<List<MovieListInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<MovieListInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else{
                            initList(null);
                        }
                    }
                });
    }

    private void initList(List<MovieListInfo> list){

        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                tvNull.setVisibility(View.VISIBLE);
            }else{
                mAdapter.setNewData(list);
                tvNull.setVisibility(View.GONE);
            }
        }else{
            mAdapter.addData(list);
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }
        layoutRefresh.finishLoadMore();
        layoutRefresh.finishRefresh();
    }


    @Override
    protected int getLayout() {
        return R.layout.activity_movie_more;
    }
}
