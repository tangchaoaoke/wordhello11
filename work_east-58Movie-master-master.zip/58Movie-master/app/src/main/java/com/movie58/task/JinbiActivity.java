package com.movie58.task;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.GoldInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.FastJsonUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class JinbiActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv1)
    TextView tv1;
    @BindView(R.id.tv_level)
    SuperButton tvLevel;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    GoldAdapter mAdapter;
    int page = 1;

    @Override
    protected void initView() {
        tvTitle.setText("金币记录");

        mAdapter = new GoldAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).colorResId(R.color.line).build());
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.addHeaderView(LayoutInflater.from(getMActivity()).inflate(R.layout.header_gold, new RelativeLayout(getMActivity())));

        layoutRefresh.autoRefresh();
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    private void getList(){
        Kalle.get(HttpUrl.GOLD_LIST)
                .param("page", page)
                .param("szie", 10)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String json = response.succeed();
                            String gold = FastJsonUtil.toString(json, "total_gold_num");
                            tv1.setText(gold);
                            List<GoldInfo> list = FastJsonUtil.toList(json, "gold_logs", GoldInfo.class);
                            initList(list);
                        }else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initList(List<GoldInfo> list){


        if (list == null) {
            list = new ArrayList<>();
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
            layoutRefresh.finishRefresh();
        }else{
            mAdapter.addData(list);
            layoutRefresh.finishLoadMore();
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }

    @OnClick({R.id.iv_back, R.id.tv_level})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv_level:
                EventBus.getDefault().post(new Event(Event.CODE_14_AVATAR));
                finish();
                break;
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_jinbi;
    }

    class GoldAdapter extends BaseQuickAdapter<GoldInfo, BaseViewHolder> {

        public GoldAdapter(@Nullable List<GoldInfo> data) {
            super(R.layout.item_gold, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, GoldInfo item) {
            helper.setText(R.id.tv_name, item.getRule_name())
                    .setText(R.id.tv_time, item.getCreate_time())
                    .setText(R.id.tv_up, "+" + item.getGold_num());
        }
    }

}
