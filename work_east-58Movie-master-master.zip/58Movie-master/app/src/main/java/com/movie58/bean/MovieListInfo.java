package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class MovieListInfo {
    /**
     * source_name : 流浪地球1111
     * source_img : https://pic.china-gif.com/pic/upload/vod/2019-02/15494025274.jpg
     * description : 流量地球大片抢先看
     * pingfen : 2.0
     * lead_role : 屈楚萧,吴京,李光洁,吴孟达
     * up_right_text : 66
     * down_right_text : 77
     * id : 107
     * img_link : /collect/collect/show/id/107.html
     */

    private String source_name;
    private String source_img;
    private String description;
    private String pingfen;
    private String lead_role;
    private String up_right_text;
    private String down_right_text;
    private String id;
    private String img_link;

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public String getSource_img() {
        return source_img;
    }

    public void setSource_img(String source_img) {
        this.source_img = source_img;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPingfen() {
        return pingfen;
    }

    public void setPingfen(String pingfen) {
        this.pingfen = pingfen;
    }

    public String getLead_role() {
        return lead_role;
    }

    public void setLead_role(String lead_role) {
        this.lead_role = lead_role;
    }

    public String getUp_right_text() {
        return up_right_text;
    }

    public void setUp_right_text(String up_right_text) {
        this.up_right_text = up_right_text;
    }

    public String getDown_right_text() {
        return down_right_text;
    }

    public void setDown_right_text(String down_right_text) {
        this.down_right_text = down_right_text;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImg_link() {
        return img_link;
    }

    public void setImg_link(String img_link) {
        this.img_link = img_link;
    }
}
