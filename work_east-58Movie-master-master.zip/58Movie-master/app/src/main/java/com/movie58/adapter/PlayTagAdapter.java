package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.PlayTagInfo;
import com.movie58.img.PicassoUtils;
import com.movie58.util.ToolUtil;

import java.util.List;

/**
 * Created by yangxing on 2019/5/25 0025.
 */
public class PlayTagAdapter extends BaseQuickAdapter<PlayTagInfo, BaseViewHolder> {

    public PlayTagAdapter(@Nullable List<PlayTagInfo> data) {
        super(R.layout.item_play_tag, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, PlayTagInfo item) {
        ImageView ivImg = helper.getView(R.id.iv_img);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
        helper.setText(R.id.tv_name, item.getSource_name()) ;
        if (item.getPlayed_time() > 0) {
            helper.setText(R.id.tv, ToolUtil.stringForTime(item.getPlayed_time()));
        }else{
            helper.setText(R.id.tv, "00:00");
        }
    }
}
