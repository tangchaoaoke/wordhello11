package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/22 0022.
 */
public class DanmuInfo {
    /**
     * vod_id : 108
     * send_user_name : 昵称
     * top_num : 0
     * down_num : 0
     * create_time : 1558513200
     * update_time : 1558513200
     * content : 弹幕弹幕弹幕弹幕弹幕弹幕
     * id : 4
     */

    private int vod_id;
    private String send_user_name;
    private int top_num;
    private int down_num;
    private int create_time;
    private int update_time;
    private String content;
    private int id;

    public int getVod_id() {
        return vod_id;
    }

    public void setVod_id(int vod_id) {
        this.vod_id = vod_id;
    }

    public String getSend_user_name() {
        return send_user_name;
    }

    public void setSend_user_name(String send_user_name) {
        this.send_user_name = send_user_name;
    }

    public int getTop_num() {
        return top_num;
    }

    public void setTop_num(int top_num) {
        this.top_num = top_num;
    }

    public int getDown_num() {
        return down_num;
    }

    public void setDown_num(int down_num) {
        this.down_num = down_num;
    }

    public int getCreate_time() {
        return create_time;
    }

    public void setCreate_time(int create_time) {
        this.create_time = create_time;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
