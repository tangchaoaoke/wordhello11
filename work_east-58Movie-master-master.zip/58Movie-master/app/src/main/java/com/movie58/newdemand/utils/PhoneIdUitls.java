package com.movie58.newdemand.utils;

import android.content.Context;
import android.text.TextUtils;

import java.util.UUID;

public class PhoneIdUitls {

    public static  String getID(Context context) {
        String uuid;
        if (!TextUtils.isEmpty(AppConfigs.UUID)) {
            return AppConfigs.UUID;
        }
        String obj = FileSaveUtils.readObjFromSDCard("five_eight_id.out");

        String obj2 = PreferencesUtils.getString(context, "uuid");
        if (TextUtils.isEmpty(obj)) {
            if (TextUtils.isEmpty(obj2)) {
                uuid = UUID.randomUUID().toString();
                PreferencesUtils.putString(context, "uuid", uuid);
                FileSaveUtils.fileBean1SDCard(uuid, "five_eight_id.out");
            } else {
                uuid = obj2;
                FileSaveUtils.fileBean1SDCard(uuid, "five_eight_id.out");
            }
        } else {
            uuid = obj;
        }
        AppConfigs.UUID = uuid;
        return AppConfigs.UUID;
    }
}
