package com.movie58.bean;

import java.util.List;

/**
 * Created by yangxing on 2019/6/19 0019.
 */
public class UpdateInfo {
    /**
     * title : 更新提示
     * content : 有更新版本啦，解决了视频播放时候的Bug，弹幕滚动时候卡顿问题，App异常闪退问题，请到应用市场体验最新版本。
     * is_open : 1
     * version : 1.0
     * redirect_url : http://www.baidu.com
     * open_clients : ["ios","android"]
     */

    private String title;
    private String content;
    private String is_open;
    private String version;
    private String redirect_url;
    private String android_redirect_url;
    private List<String> open_clients;

    public String getAndroid_redirect_url() {
        return android_redirect_url;
    }

    public void setAndroid_redirect_url(String android_redirect_url) {
        this.android_redirect_url = android_redirect_url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getIs_open() {
        return is_open;
    }

    public void setIs_open(String is_open) {
        this.is_open = is_open;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRedirect_url() {
        return redirect_url;
    }

    public void setRedirect_url(String redirect_url) {
        this.redirect_url = redirect_url;
    }

    public List<String> getOpen_clients() {
        return open_clients;
    }

    public void setOpen_clients(List<String> open_clients) {
        this.open_clients = open_clients;
    }

    @Override
    public String toString() {
        return "UpdateInfo{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", is_open='" + is_open + '\'' +
                ", version='" + version + '\'' +
                ", redirect_url='" + redirect_url + '\'' +
                ", android_redirect_url='" + android_redirect_url + '\'' +
                ", open_clients=" + open_clients +
                '}';
    }
}
