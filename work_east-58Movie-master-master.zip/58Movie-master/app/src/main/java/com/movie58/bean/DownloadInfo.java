package com.movie58.bean;

import java.io.Serializable;

/**
 * Created by yangxing on 2019/8/7 0007.
 */
public class DownloadInfo implements Serializable {

    int id;
    String title;
    String img;
    String url;
    String path;
    boolean check;

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null){
            return false;
        }
        if (obj instanceof DownloadInfo) {
            DownloadInfo info = (DownloadInfo) obj;
            return this.id == info.getId();
        }else{
            return super.equals(obj);
        }
    }
}
