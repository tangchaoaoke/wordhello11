package com.movie58.newdemand.ui.sheet;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.movie58.newdemand.interfaces.Sheet;

import org.xutils.http.RequestParams;

import butterknife.BindView;
import butterknife.OnClick;

public class RepaceNSheetAty extends BaseAty {
    private String sheet_id;
    private String sheet_name;
    @BindView(R.id.relay)
    RelativeLayout relay;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.tv_title)
    TextView tv_title;
    @BindView(R.id.tv_right)
    TextView tv_right;
    @BindView(R.id.edit_name)
    EditText edit_name;

    private Sheet sheet;

    @Override
    public int getLayoutId() {
        return R.layout.aty_sheet_replacen;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        sheet = new Sheet();
        sheet_id = getIntent().getStringExtra("sheet_id");
        sheet_name = getIntent().getStringExtra("sheet_name");
    }

    @Override
    public void requestData() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        initTopview(relay, relay_top);
        tv_title.setText("片单信息");
        tv_right.setVisibility(View.VISIBLE);
        tv_right.setText("保存");
        edit_name.setText(sheet_name);
    }


    @OnClick({R.id.relay_back, R.id.tv_right})
    void click(View v) {
        switch (v.getId()) {
            case R.id.relay_back:
                finish();
                break;
            case R.id.tv_right:
                if (TextUtils.isEmpty(edit_name.getText().toString())) {
                    return;
                }
                if (edit_name.getText().toString().equals(sheet_name)) {
                    finish();
                } else {
                    startProgressDialog();
                    sheet.e(sheet_id, edit_name.getText().toString(), this);
                }
                break;

        }
    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        stopProgressDialog();
        if (type.equals("replaceSheetName")) {
            Intent intent = new Intent();
            intent.putExtra("name", edit_name.getText().toString());
            setResult(RESULT_OK, intent);
            finish();
        }
    }

    @Override
    public void onExceptionType(Throwable var1, RequestParams params, String type) {
        super.onExceptionType(var1, params, type);
    }
}
