package com.movie58.newdemand.ui.tscreen;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.lxj.xpopup.XPopup;
import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.bean.DetailInfo;
import com.movie58.util.FastJsonUtil;
import com.yanbo.lib_screen.callback.ControlCallback;
import com.yanbo.lib_screen.entity.AVTransportInfo;
import com.yanbo.lib_screen.entity.RemoteItem;
import com.yanbo.lib_screen.entity.RenderingControlInfo;
import com.yanbo.lib_screen.event.ControlEvent;
import com.yanbo.lib_screen.manager.ClingManager;
import com.yanbo.lib_screen.manager.ControlManager;
import com.yanbo.lib_screen.utils.VMDate;

import org.fourthline.cling.support.model.item.Item;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;

public class DevicePlayAty extends BaseAty implements MovieMore2Dialog.IndexMovieMore2DialogInterface {

    @BindView(R.id.imgv_play)
    ImageView imgv_play;
    @BindView(R.id.text_play_max_time)
    TextView playMaxTimeView;
    @BindView(R.id.text_play_time)
    TextView playTimeView;
    @BindView(R.id.seek_bar_progress)
    SeekBar progressSeekbar;
    @BindView(R.id.linlay_xuanji)
    LinearLayout linlay_xuanji;
    @BindView(R.id.tv_title)
    TextView tv_title;

    private int defaultVolume = 10;
    private int currVolume = defaultVolume;
    private int currProgress = 0;
    private int maxProgress = 0;

    private String json_details;
    private int play_anthology;
    private DetailInfo detailInfo;

    @Override
    public int getLayoutId() {
        return R.layout.aty_device_play;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        json_details = getIntent().getStringExtra("json_details");
        play_anthology = getIntent().getIntExtra("play_anthology", 0);
    }

    @Override
    public void requestData() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatus("#000000");
        initData2();

        if (ControlManager.getInstance().getState() == ControlManager.CastState.PLAYING) {
            imgv_play.setImageResource(R.drawable.aic_13);
        } else {
            imgv_play.setImageResource(R.drawable.aic_17);
        }
        setProgressSeekListener();
    }

    Map<String, String> map_vod_info;
    ArrayList<Map<String, String>> list_source_content;
    String cat_name;

    MovieMore2Dialog movieMoreDialog;

    public void initData2() {
        map_vod_info = JSONUtils.parseKeyAndValueToMap(json_details);
        cat_name = map_vod_info.get("cat_name");
        list_source_content = JSONUtils.parseKeyAndValueToMapList(map_vod_info.get("source_content"));
        detailInfo = FastJsonUtil.toBean(json_details, DetailInfo.class);
        if (list_source_content.size() == 1) {
            linlay_xuanji.setVisibility(View.GONE);
        } else {
            linlay_xuanji.setVisibility(View.VISIBLE);
            movieMoreDialog = new MovieMore2Dialog(this, detailInfo);
            movieMoreDialog.setIndexMovieMore2DialogInterface(this);

        }
        updatePlayUrl();
    }


    public void updatePlayUrl() {
        setUrl(list_source_content.get(play_anthology).get("play_url"));
        showShortToast(list_source_content.get(play_anthology).get("play_url"));
        if (list_source_content.size() == 1) {
            tv_title.setText(map_vod_info.get("source_name"));
        } else {
            tv_title.setText(map_vod_info.get("source_name") + "第" + (play_anthology + 1) + "集");
        }
        play();
    }


    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @OnClick({R.id.ic_back, R.id.ic_close, R.id.relay_play, R.id.imgv_sy, R.id.imgv_sy2,
            R.id.imgv_r, R.id.imgv_l, R.id.linlay_xuanji})
    void click(View v) {
        switch (v.getId()) {
            case R.id.ic_back:
                finish();
            case R.id.ic_close:
                finish();
                break;
            case R.id.relay_play:
                play();
                break;
            case R.id.imgv_sy:  //调高
                if (currVolume == 100) {
                    return;
                }
                currVolume += 5;
                if (currVolume > 100) {
                    currVolume = 100;
                }
                setVolume(currVolume);
                break;
            case R.id.imgv_sy2:  //调低
                if (currVolume == 0) {
                    return;
                }
                int currVolume2 = currVolume - 5;
                if (currVolume2 < 0) {
                    currVolume = 0;
                } else {
                    currVolume = currVolume2;
                }
                setVolume(currVolume);
                if (currVolume <= 0) {
                    currVolume = defaultVolume;
                }
                break;
            case R.id.imgv_r: //快进
                if (maxProgress == 0) {
                    return;
                }
                int vo = maxProgress / 100;
                currProgress += currProgress + vo;
                if (currProgress > maxProgress) {
                    currProgress = maxProgress;
                }
                seekCast(currProgress);
                break;
            case R.id.imgv_l:  //快退
                if (maxProgress == 0) {
                    return;
                }
                int vos = maxProgress / 100;
                currProgress -= currProgress + vos;
                if (currProgress < 0) {
                    currProgress = 0;
                }
                seekCast(currProgress);
                break;
            case R.id.linlay_01:
                finish();
                break;
            case R.id.linlay_xuanji:

                new XPopup.Builder(this)
                        .moveUpToKeyboard(false)
                        .asCustom(movieMoreDialog)
                        .show();
                break;
        }
    }


    public void setUrl(String url) {
        RemoteItem itemurl1 = new RemoteItem("", System.currentTimeMillis() + "", "",
                107362668, "00:04:33", "1280x720", url);
        ClingManager.getInstance().setRemoteItem(itemurl1);
    }


    public Item localItem;
    public RemoteItem remoteItem;

    //开始投屏
    private void play() {
        localItem = ClingManager.getInstance().getLocalItem();
        remoteItem = ClingManager.getInstance().getRemoteItem();
        if (ControlManager.getInstance().getState() == ControlManager.CastState.STOPED) {
            if (localItem != null) {
                newPlayCastLocalContent();
            } else {
                newPlayCastRemoteContent();
            }
        } else if (ControlManager.getInstance().getState() == ControlManager.CastState.PAUSED) {
            playCast();
        } else if (ControlManager.getInstance().getState() == ControlManager.CastState.PLAYING) {
            pauseCast();
        } else {
            Toast.makeText(getBaseContext(), "正在连接设备，稍后操作", Toast.LENGTH_SHORT).show();
        }
    }

    //投屏本地
    private void newPlayCastLocalContent() {
        ControlManager.getInstance().setState(ControlManager.CastState.TRANSITIONING);
        ControlManager.getInstance().newPlayCast(localItem, new ControlCallback() {
            @Override
            public void onSuccess() {
                ControlManager.getInstance().setState(ControlManager.CastState.PLAYING);
                ControlManager.getInstance().initScreenCastCallback();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        playView.setText("暂停");
                        imgv_play.setImageResource(R.drawable.aic_13);
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
                ControlManager.getInstance().setState(ControlManager.CastState.STOPED);
                imgv_play.setImageResource(R.drawable.aic_17);
//                showToast(String.format("New play cast local content failed %s", msg));
            }
        });
    }

    //投屏远程
    private void newPlayCastRemoteContent() {
        ControlManager.getInstance().setState(ControlManager.CastState.TRANSITIONING);
        ControlManager.getInstance().newPlayCast(remoteItem, new ControlCallback() {
            @Override
            public void onSuccess() {
                ControlManager.getInstance().setState(ControlManager.CastState.PLAYING);
                ControlManager.getInstance().initScreenCastCallback();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imgv_play.setImageResource(R.drawable.aic_13);
//                        playView.setText("暂停");
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
                ControlManager.getInstance().setState(ControlManager.CastState.STOPED);
                imgv_play.setImageResource(R.drawable.aic_17);
//                showToast(String.format("New play cast remote content failed %s", msg));
            }
        });
    }

    private void playCast() {
        ControlManager.getInstance().playCast(new ControlCallback() {
            @Override
            public void onSuccess() {
                ControlManager.getInstance().setState(ControlManager.CastState.PLAYING);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imgv_play.setImageResource(R.drawable.aic_13);
//                        playView.setText("暂停");
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
                imgv_play.setImageResource(R.drawable.aic_17);
//                showToast(String.format("Play cast failed %s", msg));
            }
        });
    }

    private void pauseCast() {
        ControlManager.getInstance().pauseCast(new ControlCallback() {
            @Override
            public void onSuccess() {
                ControlManager.getInstance().setState(ControlManager.CastState.PAUSED);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imgv_play.setImageResource(R.drawable.aic_17);
//                        playView.setText("播放");
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
                imgv_play.setImageResource(R.drawable.aic_13);
//                showToast(String.format("Pause cast failed %s", msg));
            }
        });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventBus(ControlEvent event) {
        AVTransportInfo avtInfo = event.getAvtInfo();
        if (avtInfo != null) {
            if (!TextUtils.isEmpty(avtInfo.getState())) {
                if (avtInfo.getState().equals("TRANSITIONING")) {
                    ControlManager.getInstance().setState(ControlManager.CastState.TRANSITIONING);
                } else if (avtInfo.getState().equals("PLAYING")) {
                    ControlManager.getInstance().setState(ControlManager.CastState.PLAYING);
//                    playView.setText("暂停");
                    imgv_play.setImageResource(R.drawable.aic_13);
                } else if (avtInfo.getState().equals("PAUSED_PLAYBACK")) {
                    ControlManager.getInstance().setState(ControlManager.CastState.PAUSED);
//                    playView.setText("播放");
                    imgv_play.setImageResource(R.drawable.aic_17);
                } else if (avtInfo.getState().equals("STOPPED")) {
                    ControlManager.getInstance().setState(ControlManager.CastState.STOPED);
//                    playView.setText("播放");
                    imgv_play.setImageResource(R.drawable.aic_17);
//                    finish();
                } else {
                    ControlManager.getInstance().setState(ControlManager.CastState.STOPED);
//                    playView.setText("播放");
                    imgv_play.setImageResource(R.drawable.aic_17);
//                    finish();
                }
            }
            if (!TextUtils.isEmpty(avtInfo.getMediaDuration())) {
                playMaxTimeView.setText(avtInfo.getMediaDuration());
                maxProgress = (int) VMDate.fromTimeString(avtInfo.getMediaDuration());
                progressSeekbar.setMax(maxProgress);
            }
            if (!TextUtils.isEmpty(avtInfo.getTimePosition())) {
                long progress = VMDate.fromTimeString(avtInfo.getTimePosition());
                progressSeekbar.setProgress((int) progress);
                playTimeView.setText(avtInfo.getTimePosition());
            }
        }

        RenderingControlInfo rcInfo = event.getRcInfo();
        if (rcInfo != null && ControlManager.getInstance()
                .getState() != ControlManager.CastState.STOPED) {
            if (rcInfo.isMute() || rcInfo.getVolume() == 0) {
//                volumeView.setText("静音");
                ControlManager.getInstance().setMute(true);
            } else {
//                volumeView.setText("声音");
                ControlManager.getInstance().setMute(false);
            }
            currVolume=rcInfo.getVolume();
//            volumeSeekbar.setProgress(rcInfo.getVolume());
        }
    }


    private void stopCast() {
        ControlManager.getInstance().stopCast(new ControlCallback() {
            @Override
            public void onSuccess() {
                ControlManager.getInstance().setState(ControlManager.CastState.STOPED);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        playView.setText("播放");
//                        finish();
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
//                showToast(String.format("Stop cast failed %s", msg));
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopCast();
        ControlManager.getInstance().unInitScreenCastCallback();
    }


    /**
     * 设置音量大小
     */
    private void setVolume(int volume) {
        ControlManager.getInstance().setVolumeCast(volume, new ControlCallback() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onError(int code, String msg) {
            }
        });
    }

    /**
     * 改变投屏进度
     */
    private void seekCast(int progress) {
        String target = VMDate.toTimeString(progress);
        ControlManager.getInstance().seekCast(target, new ControlCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int code, String msg) {
//                showToast(String.format("Seek cast failed %s", msg));
            }
        });
    }

    /**
     * 设置播放进度拖动监听
     */


    private void setProgressSeekListener() {
        progressSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (maxProgress == 0) {
                    return;
                }
                currProgress = seekBar.getProgress();
                playTimeView.setText(VMDate.toTimeString(currProgress));
                seekCast(currProgress);
            }
        });
    }

    @Override
    public void select(int index) {
        if (play_anthology == index) {
            return;
        }
        play_anthology = index;
        updatePlayUrl();
    }
}
