package com.movie58.home;

import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.find.HotFrament;

/**
 * Created by yangxing on 2019/4/26 0026.
 */
public class RecommonFragment extends BaseFragment {

    public static RecommonFragment newInstance() {
        return new RecommonFragment();
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_hot;
    }
}
