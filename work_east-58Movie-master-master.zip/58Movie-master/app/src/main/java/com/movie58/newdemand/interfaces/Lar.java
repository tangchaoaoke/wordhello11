package com.movie58.newdemand.interfaces;

import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.net.ApiTool;
import com.movie58.account.Account;
import com.movie58.http.HttpUrl;

import org.xutils.http.RequestParams;

public class Lar {


    //设备编号关联
    public void d(String imei, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "collect/play/loginImei");
        if (Account.getInstance().isLogined()) {
            params.addHeader("XX-Token", Account.getInstance().getToken());
        }
        params.addHeader("XX-Device-Type", "android");

        params.addBodyParameter("imei", imei);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "imei");
    }
}
