
package com.movie58.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.lang.reflect.Type;
import java.util.List;


/**
 * FastJSON封装
 */
public class FastJsonUtil {

	/**json转JSONObject
	 * @param json
	 * @return
	 */
    public static JSONObject toJSONObject(String json) {
		int features = JSON.DEFAULT_PARSER_FEATURE;
		features |= Feature.OrderedField.mask;
		return toJSONObject(json, features);
	}

	/**json转JSONObject
	 * @param json
	 * @param features
	 * @return
	 */
    public static JSONObject toJSONObject(String json, int features) {
		try {
			return JSON.parseObject(getCorrectJson(json), JSONObject.class, features);
		} catch (Exception e) {
            LogUtil.d("parseObject  catch \n" + e.getMessage());
		}
		return null;
	}

	/**list转JSONArray
	 * @param list
	 * @return
	 */
    public static JSONArray toJSONArray(List<Object> list) {
		return new JSONArray(list);
	}

	/**obj转JSONArray
	 * @param obj
	 * @return
	 */
    public static JSONArray toJSONArray(Object obj) {
		if (obj instanceof JSONArray) {
			return (JSONArray) obj;
		}
		return toJSONArray(toJSONString(obj));
	}

	/**json转JSONArray
	 * @param json
	 * @return
	 */
    public static JSONArray toJSONArray(String json) {
		try {
			return JSON.parseArray(getCorrectJson(json));
		} catch (Exception e) {
            LogUtil.d("parseArray  catch \n" + e.getMessage());
		}
		return null;
	}

    /**实体类转json
     * @param obj
     * @return
     */
    public static String toJSONString(Object obj) {
        if (obj instanceof String) {
            return (String) obj;
        }
        try {
            return JSON.toJSONString(obj);
        } catch (Exception e) {
            LogUtil.d("toJSONString  catch \n" + e.getMessage());
        }
        return null;
    }

    /**实体类转json
     * @param obj
     * @param features
     * @return
     */
    public static String toJSONString(Object obj, SerializerFeature... features) {
        if (obj instanceof String) {
            return (String) obj;
        }
        try {
            return JSON.toJSONString(obj, features);
        } catch (Exception e) {
            LogUtil.d("parseArray  catch \n" + e.getMessage());
        }
        return null;
    }

    /**JSONObject转实体类
     * @param object
     * @param clazz
     * @return
     */
    public static <T> T toBean(JSONObject object, Type clazz) {
        return toBean(toJSONString(object), clazz);
    }

    /**json转实体类
     * @param json
     * @param clazz
     * @return
     */
    public static <T> T toBean(String json, Type clazz) {
        if (clazz == null) {
            LogUtil.d("parseObject  clazz == null >> return null;");
        } else {
            try {
                int features = JSON.DEFAULT_PARSER_FEATURE;
                features |= Feature.OrderedField.mask;
                return JSON.parseObject(getCorrectJson(json), clazz, features);
            } catch (Exception e) {
                LogUtil.d("parseObject  catch \n" + e.getMessage());
            }
        }
        return null;
    }

    /**
     * @param json
     * @param key
     * @param clazz
     * @return
     */
    public static <T> T toBean(String json, String key, Type clazz) {
        return toBean(toJSONObject(json), key, clazz);
    }

    /**
     * @param object
     * @param key
     * @param clazz
     * @return
     */
    public static <T> T toBean(JSONObject object, String key, Type clazz) {
        return toBean(object == null ? null : object.getJSONObject(key), clazz);
    }

	/**JSONArray转实体类列表
	 * @param array
	 * @param clazz
	 * @return
	 */
    public static <T> List<T> toList(JSONArray array, Class<T> clazz) {
		return JSON.parseArray(toJSONString(array), clazz);
	}

	/**json转实体类列表
	 * @param json
	 * @param clazz
	 * @return
	 */
    public static <T> List<T> toList(String json, Class<T> clazz) {
		if (clazz == null) {
            LogUtil.d("parseArray  clazz == null >> return null;");
		} else {
			try {
				return JSON.parseArray(getCorrectJson(json), clazz);
			} catch (Exception e) {
                LogUtil.d("parseArray  catch \n" + e.getMessage());
			}
		}
		return null;
	}

    /**
     * @param json
     * @param key
     * @param clazz
     * @return
     */
    public static <T> List<T> toList(String json, String key, Class<T> clazz) {
        return toList(toJSONObject(json), key, clazz);
    }

    /**
     * @param object
     * @param key
     * @param clazz
     * @return
     */
    public static <T> List<T> toList(JSONObject object, String key, Class<T> clazz) {
        return object == null ? null : toList(object.getString(key), clazz);
    }

    /**
     *
     * @param json
     * @param key
     * @return
     */
    public static Boolean toBoolean(String json, String key){
        return toBoolean(toJSONObject(json), key);
    }

    /**
     *
     * @param object
     * @param key
     * @return
     */
    public static Boolean toBoolean(JSONObject object, String key){
        return object == null ? false : object.getBooleanValue(key);
    }


    /**
     *
     * @param json
     * @param key
     * @return
     */
    public static int toInt(String json, String key){
        return toInt(toJSONObject(json), key);
    }

    /**
     *
     * @param object
     * @param key
     * @return
     */
    public static int toInt(JSONObject object, String key){
        return object == null ? 0 : object.getIntValue(key);
    }

    /**
     *
     * @param json
     * @param key
     * @return
     */
    public static String toString(String json, String key){
        return toString(toJSONObject(json), key);
    }

    /**
     *
     * @param object
     * @param key
     * @return
     */
    public static String toString(JSONObject object, String key){
        return object == null ? null : object.getString(key);
    }

    /**
     *
     * @param object
     * @return
     */
    public static String toJson(Object object){
        return JSON.toJSONString(object);
    }

    public static Object toJsonObj(Object object){
        return JSON.toJSON(object);
    }

	/**格式化，显示更好看
	 * @param json
	 * @return
	 */
    public static String format(String json) {
		return format(toJSONObject(json));
	}

	/**格式化，显示更好看
	 * @param object
	 * @return
	 */
    public static String format(JSONObject object) {
		return toJSONString(object, SerializerFeature.PrettyFormat);
	}

	/**判断是否为JSONObject
	 * @param obj instanceof String ? parseObject
	 * @return
	 */
    public static boolean isJSONObject(Object obj) {
		if (obj instanceof JSONObject) {
			return true;
		}
		if (obj instanceof String) {
			try {
				JSONObject json = toJSONObject((String) obj);
				return json != null && json.isEmpty() == false;
			} catch (Exception e) {
                LogUtil.d("isJSONObject  catch \n" + e.getMessage());
			}
		}

		return false;
	}

	/**判断是否为JSONArray
	 * @param obj instanceof String ? parseArray
	 * @return
	 */
    public static boolean isJSONArray(Object obj) {
		if (obj instanceof JSONArray) {
			return true;
		}
		if (obj instanceof String) {
			try {
				JSONArray json = JSON.parseArray((String) obj);
				return json != null && json.isEmpty() == false;
			} catch (Exception e) {
				LogUtil.d("isJSONArray  catch \n" + e.getMessage());
			}
		}

		return false;
	}

    /**获取有效的json
     * @param s
     * @return
     */
    public static String getCorrectJson(String s) {
        return getString(s).trim();
    }

    public static String getString(String s) {
        return s == null ? "" : s;
    }


    //fastJson解析动态key
//    listReason.clear();
//    JSONObject jsonObject = JSON.parseObject(response);
//    Set<String> keys = jsonObject.keySet();
//    Iterator iterator = keys.iterator();
//        while(iterator.hasNext()){
//        String key = (String) iterator.next();
//        BottomCheckInfo info = new BottomCheckInfo();
//        info.setText(jsonObject.getString(key));
//        info.setValue(key);
//        info.setCheck(key.equals(selReason));
//        listReason.add(info);
//    }

}
