package com.movie58.my;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.HelpAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.HelpInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/6 0006.
 */
public class HelpFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_feedback)
    TextView tvFeedback;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    HelpAdapter mAdapter;

    public static HelpFragment newInstance() {
        return new HelpFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("帮助与反馈");
        layoutRefresh.setEnableRefresh(false);
        layoutRefresh.setEnableLoadMore(false);

        mAdapter = new HelpAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).color(R.color.line).build());
        mAdapter.bindToRecyclerView(rvList);
    }

    @Override
    protected void initData() {
        getList();
    }

    @OnClick({R.id.iv_back, R.id.tv_feedback})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                getMActivity().finish();
                break;
            case R.id.tv_feedback:
                startActivity(FeedbackActivity.class);
                break;
        }
    }


    @Override
    public void onEvent(Event e) {
        switch (e.getEvent()) {
            case Event.CODE_10_SCHOOL_MY_CLICK:
                getMActivity().finish();
                break;
        }
    }

    private void getList(){
        Kalle.get(HttpUrl.HELP_LIST)
                .param("page", 1)
                .param("size", 50)
                .perform(new LoadingCallback<List<HelpInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<HelpInfo>, String> response) {
                        if (response.isSucceed()) {
                            if (response.succeed() == null || response.succeed().isEmpty()) {
                                return;
                            }
                            mAdapter.setNewData(response.succeed());
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    @Override
    protected int getLayout() {
        return R.layout.fragment_help;
    }

}
