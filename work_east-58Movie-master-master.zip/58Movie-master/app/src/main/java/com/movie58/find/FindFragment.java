package com.movie58.find;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.event.Event;
import com.zhy.autolayout.utils.AutoUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class FindFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.iv_right)
    ImageView ivRight;
    @BindView(R.id.layout_tab12)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp1)
    ViewPager vp;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.relay)
    RelativeLayout relay;

    private final String[] titles = {"热门专题", "观影排行"};
    ArrayList<Fragment> listFind = new ArrayList<>();

    public static FindFragment newInstance() {
        return new FindFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("发现");
//        ivRight.setImageResource(R.drawable.top_search);
        listFind.add(HotFrament.newInstance());
        listFind.add(RankFragment.newInstance());

        layoutTab.setViewPager(vp, titles, getMActivity(), listFind);

        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                vp.setCurrentItem(position);
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initTopview(relay, relay_top, AutoUtils.getPercentHeightSize(130));

    }

    @OnClick(R.id.iv_back)
    void back(){
        EventBus.getDefault().post(new Event(Event.CODE_01_TAB_HOME));
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_find;
    }
}
