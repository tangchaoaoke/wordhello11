package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.widget.CompoundButton;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.HistoryInfo;
import com.movie58.img.PicassoUtils;
import com.movie58.util.ToolUtil;

import java.util.List;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class HistoryAdapter extends BaseQuickAdapter<HistoryInfo, BaseViewHolder> {

    boolean isEdit = false;

    public HistoryAdapter(@Nullable List<HistoryInfo> data) {
        super(R.layout.item_play_history, data);
    }

    public void edit(boolean edit){
        isEdit = edit;
        if (!isEdit) {
            for(HistoryInfo info : getData()){
                info.setCheck(false);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, HistoryInfo item) {
        helper.setText(R.id.tv_name, item.getSource_name());
        if (item.getPlayed_time() > 0) {
            helper.setText(R.id.tv_time, ToolUtil.stringForTime(item.getPlayed_time()));
        }else{
            helper.setText(R.id.tv_time, "00:00");
        }
//        if (item.getPlayed_time() == 0) {
//            helper.setText(R.id.tv_progress, "观看至0%");
//        }else{
//            // 创建一个数值格式化对象
//            NumberFormat numberFormat = NumberFormat.getInstance();
//            // 设置精确到小数点后2位
//            numberFormat.setMaximumFractionDigits(2);
//            String result = numberFormat.format((float) item.getPlayed_time() / (float) item.get * 100);
//        }
        ImageView ivImg = helper.getView(R.id.iv_player);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
        helper.addOnClickListener(R.id.iv_share);
        if (isEdit) {
            helper.setGone(R.id.cb, true);
        }else{

            helper.setGone(R.id.cb, false);
        }
        helper.setChecked(R.id.cb, item.isCheck());
        helper.setOnCheckedChangeListener(R.id.cb, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                item.setCheck(isChecked);
            }
        });

        if (item.isShow()) {
            helper.setText(R.id.tv_date, item.getTimeshow())
                .setGone(R.id.tv_date, true);
        }else{
            helper.setGone(R.id.tv_date, false);
        }
    }
}
