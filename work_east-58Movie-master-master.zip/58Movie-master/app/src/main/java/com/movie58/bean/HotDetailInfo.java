package com.movie58.bean;

import java.util.List;

/**
 * Created by yangxing on 2019/5/20 0020.
 */
public class HotDetailInfo {

    /**
     * id : 3
     * project_name : 影史上的经典恐怖片究竟有多恐怖 不可不看的世界十大恐怖片推荐
     * project_desc : 恐怖片相信大家都看过很多，但是你知道哪些才是经典的吗？本文为你推上>>
     * project_banner : https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1350308544,2223607921&fm=26&gp=0.jpg
     * project_background :
     * project_color :
     * create_time : 1558332411
     * update_time : 1558332411
     * params : {"list":[{"vod_id":"117","vod_name":"疯狂的赛车","img_url":"https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3188152122,3016498141&fm=26&gp=0.jpg","description":null,"pingfen":"9.0","lead_role":"黄渤,戎祥,九孔,徐峥,王双宝,巴多,董立范,高捷,马少骅,王迅,刘刚,Worapoj Thuantanon,赵奔,李麒麟,姜志刚,王鹭,宁浩","cat_name":"电影","down_right_text":"9.0","up_right_text":"火爆"}]}
     * project_type :
     * project_tag :
     * project_cat : 1
     */

    private String id;
    private String project_name;
    private String project_desc;
    private String project_banner;
    private String project_background;
    private String project_color;
    private String create_time;
    private String update_time;
    private ParamsBean params;
    private String project_type;
    private String project_tag;
    private String project_cat;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProject_name() {
        return project_name;
    }

    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    public String getProject_desc() {
        return project_desc;
    }

    public void setProject_desc(String project_desc) {
        this.project_desc = project_desc;
    }

    public String getProject_banner() {
        return project_banner;
    }

    public void setProject_banner(String project_banner) {
        this.project_banner = project_banner;
    }

    public String getProject_background() {
        return project_background;
    }

    public void setProject_background(String project_background) {
        this.project_background = project_background;
    }

    public String getProject_color() {
        return project_color;
    }

    public void setProject_color(String project_color) {
        this.project_color = project_color;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public ParamsBean getParams() {
        return params;
    }

    public void setParams(ParamsBean params) {
        this.params = params;
    }

    public String getProject_type() {
        return project_type;
    }

    public void setProject_type(String project_type) {
        this.project_type = project_type;
    }

    public String getProject_tag() {
        return project_tag;
    }

    public void setProject_tag(String project_tag) {
        this.project_tag = project_tag;
    }

    public String getProject_cat() {
        return project_cat;
    }

    public void setProject_cat(String project_cat) {
        this.project_cat = project_cat;
    }

    public static class ParamsBean {
        private List<ListBean> list;

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            /**
             * vod_id : 117
             * vod_name : 疯狂的赛车
             * img_url : https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3188152122,3016498141&fm=26&gp=0.jpg
             * description : null
             * pingfen : 9.0
             * lead_role : 黄渤,戎祥,九孔,徐峥,王双宝,巴多,董立范,高捷,马少骅,王迅,刘刚,Worapoj Thuantanon,赵奔,李麒麟,姜志刚,王鹭,宁浩
             * cat_name : 电影
             * down_right_text : 9.0
             * up_right_text : 火爆
             */

            private String vod_id;
            private String vod_name;
            private String img_url;
            private String description;
            private String pingfen;
            private String lead_role;
            private String cat_name;
            private String down_right_text;
            private String up_right_text;
            private String director;

            public String getDirector() {
                return director;
            }

            public void setDirector(String director) {
                this.director = director;
            }

            public String getVod_id() {
                return vod_id;
            }

            public void setVod_id(String vod_id) {
                this.vod_id = vod_id;
            }

            public String getVod_name() {
                return vod_name;
            }

            public void setVod_name(String vod_name) {
                this.vod_name = vod_name;
            }

            public String getImg_url() {
                return img_url;
            }

            public void setImg_url(String img_url) {
                this.img_url = img_url;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public String getPingfen() {
                return pingfen;
            }

            public void setPingfen(String pingfen) {
                this.pingfen = pingfen;
            }

            public String getLead_role() {
                return lead_role;
            }

            public void setLead_role(String lead_role) {
                this.lead_role = lead_role;
            }

            public String getCat_name() {
                return cat_name;
            }

            public void setCat_name(String cat_name) {
                this.cat_name = cat_name;
            }

            public String getDown_right_text() {
                return down_right_text;
            }

            public void setDown_right_text(String down_right_text) {
                this.down_right_text = down_right_text;
            }

            public String getUp_right_text() {
                return up_right_text;
            }

            public void setUp_right_text(String up_right_text) {
                this.up_right_text = up_right_text;
            }
        }
    }
}
