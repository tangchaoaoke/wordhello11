package com.movie58.newdemand.ui.sheet;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.movie58.newdemand.interfaces.Sheet;
import com.movie58.newdemand.utils.ImagesUtils;
import com.movie58.newdemand.utils.JSONUtils;
import com.zhy.autolayout.utils.AutoUtils;

import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class EditSheetAty extends BaseAty {

    @BindView(R.id.tv_title)
    TextView tv_title;
    @BindView(R.id.tv_right)
    TextView tv_right;
    @BindView(R.id.relay)
    RelativeLayout relay;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    @BindView(R.id.linlay_bottom)
    LinearLayout linlay_bottom;
    @BindView(R.id.tv_del)
    TextView tv_del;
    @BindView(R.id.tv_all)
    TextView tv_all;
    private String data;
    private ArrayList<Map<String, String>> list;
    private GoldRecyclerAdapter adapter;
    private ArrayList<Integer> list_cb;
    private ArrayList<String> list_id;


    private Sheet sheet;

    @Override
    public int getLayoutId() {
        return R.layout.aty_edit_sheet;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        data = getIntent().getStringExtra("data");
        list_cb = new ArrayList<>();
        list_id = new ArrayList<>();
        sheet = new Sheet();
    }

    @Override
    public void requestData() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        tv_title.setText("我的片单");
        initTopview(relay, relay_top);
        tv_right.setVisibility(View.VISIBLE);
        tv_right.setText("取消");
        list = JSONUtils.parseDataToMapList(data);

        if (list == null) {
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            list_cb.add(0);
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        adapter = new GoldRecyclerAdapter(this);
        recyclerview.setAdapter(adapter);
        linlay_bottom.setVisibility(View.VISIBLE);
    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        if (type.equals("deleteSheet")) {
            setResult(RESULT_OK);
            finish();
        }
    }


    @OnClick({R.id.relay_back, R.id.tv_right, R.id.tv_del, R.id.tv_all})
    void click(View v) {
        switch (v.getId()) {
            case R.id.relay_back:
                finish();
                break;
            case R.id.tv_right:
                if (list == null || list.size() == 0) {
                    return;
                }
                finish();
                break;
            case R.id.tv_del:
                for (int i = 0; i < list_cb.size(); i++) {
                    if (list_cb.get(i) == 1) {
                        list_id.add(list.get(i).get("id"));
                    }
                }
                if (list_id == null || list_id.size() == 0) {
                    return;
                }

                StringBuffer stringBuffer = new StringBuffer();
                for (int i = 0; i < list_id.size(); i++) {
                    stringBuffer.append(list_id.get(i));
                    if (i != list_id.size() - 1) {
                        stringBuffer.append(",");
                    }
                }
                startProgressDialog();
                sheet.d4(stringBuffer.toString(), this);
                break;
            case R.id.tv_all:
                if (tv_all.getText().toString().equals("全选")) {
                    tv_all.setText("取消全选");
                    for (int i = 0; i < list_cb.size(); i++) {
                        list_cb.set(i, 1);
                    }
                    tv_del.setText("删除(" + list.size() + ")");
                    tv_del.setTextColor(0xaaCE5E52);
                } else {
                    tv_all.setText("全选");
                    for (int i = 0; i < list_cb.size(); i++) {
                        list_cb.set(i, 0);
                    }
                    tv_del.setText("删除");
                    tv_del.setTextColor(0xaa444444);
                }
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
                break;
        }
    }


    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_edit_sheet, parent, false);
            return new GoldRecyclerAdapter.fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            GoldRecyclerAdapter.fGoldViewHolder holder1 = (GoldRecyclerAdapter.fGoldViewHolder) holder;

            holder1.tvName.setText(list.get(position).get("sheet_name"));
            ArrayList<Map<String, String>> vod_list = JSONUtils.parseKeyAndValueToMapList(list.get(position).get("vod_list"));

            if (vod_list == null || vod_list.size() == 0) {
                holder1.tvNum.setText("0部");
            } else {
                holder1.tvNum.setText(vod_list.size() + "部");
                ImagesUtils.disImg2(EditSheetAty.this, vod_list.get(0).get("source_img"),
                        holder1.imgv, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);
            }

            if (list_cb.get(position) == 1) {
                holder1.cb.setImageResource(R.drawable.radio_sel);
            } else {
                holder1.cb.setImageResource(R.drawable.radio_nor);
            }

            holder1.itemView.setOnClickListener(v -> {
                if (list_cb.get(position) == 1) {
                    list_cb.set(position, 0);
                } else {
                    list_cb.set(position, 1);
                }

                int k = 0;
                for (int i = 0; i < list_cb.size(); i++) {
                    if (list_cb.get(i) == 1) {
                        k++;
                    }
                }
                if (k == 0) {
                    tv_del.setText("删除");
                    tv_del.setTextColor(0xaa444444);

                } else {
                    tv_del.setText("删除(" + k + ")");
                    tv_del.setTextColor(0xaaCE5E52);
                }

                if (k == list.size()) {
                    tv_all.setText("取消全选");
                } else {
                    tv_all.setText("全选");
                }
                notifyDataSetChanged();
            });

        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {
            @BindView(R.id.imgv)
            ImageView imgv;
            @BindView(R.id.tv_name)
            TextView tvName;
            @BindView(R.id.tv_num)
            TextView tvNum;
            @BindView(R.id.cb)
            ImageView cb;

            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }
}
