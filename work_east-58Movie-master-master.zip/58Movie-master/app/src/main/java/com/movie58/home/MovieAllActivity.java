package com.movie58.home;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.MovieAllAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.MovieIndexInfo;
import com.movie58.bean.MovieListInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.util.DensityUtil;
import com.movie58.util.OnDoubleClickListener;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.FormBody;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/5 0005.
 */
public class MovieAllActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.iv_right)
    ImageView ivRight;
    @BindView(R.id.rg_area)
    RadioGroup rgArea;
    @BindView(R.id.rg_type)
    RadioGroup rgType;
    @BindView(R.id.rg_year)
    RadioGroup rgYear;
    @BindView(R.id.rg_other)
    RadioGroup rgOther;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.sv_area)
    HorizontalScrollView svArea;
    @BindView(R.id.sv_type)
    HorizontalScrollView svType;
    @BindView(R.id.sv_year)
    HorizontalScrollView svYear;
    @BindView(R.id.rg_end)
    RadioGroup rgEnd;
    @BindView(R.id.sv_end)
    HorizontalScrollView svEnd;
    @BindView(R.id.sv_other)
    HorizontalScrollView svOther;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.tv_null)
    TextView tvNull;

    MovieIndexInfo indexInfo;
    String strName;
    int id;

    MovieAllAdapter mAdapter;

    int page = 1;

    String selArea, selType, selYear, selEnd, selOther;

    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        id = b.getInt("id");
        strName = b.getString("name");
    }

    @Override
    protected void initView() {
        tvTitle.setText(strName);
        ivRight.setImageResource(R.drawable.top_search);
        mAdapter = new MovieAllAdapter(new ArrayList<>());
        mAdapter.bindToRecyclerView(rvList);
        rvList.setLayoutManager(new GridLayoutManager(getMActivity(),3));

        layoutRefresh.setEnableRefresh(false);
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                search();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
            }
        });


        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("id", mAdapter.getItem(position).getId());
                    startActivity(MovieDetailActivity.class, map);
//                }else{
//                    startActivity(LoginActivity.class);
//                }
            }
        });




        getIndex();

    }

    @OnClick({R.id.iv_back, R.id.iv_right})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.iv_right:
                startActivity(SearchActivity.class);
                break;
        }
    }

    private void addType() {
        if (indexInfo == null) {
            return;
        }
        if (indexInfo.getScreen_conditions() == null) {
            return;
        }
        MovieIndexInfo.ScreenConditionsBean bean = indexInfo.getScreen_conditions();
        MovieIndexInfo.ScreenConditionsBean.SourceAreaBean area = new MovieIndexInfo.ScreenConditionsBean.SourceAreaBean();
        area.setId("");
        area.setArea_name("全部地区");
        bean.getSource_area().add(0, area);
        MovieIndexInfo.ScreenConditionsBean.SourceTypeBean type = new MovieIndexInfo.ScreenConditionsBean.SourceTypeBean();
        type.setId("");
        type.setType_name("全部类型");
        bean.getSource_type().add(0, type);
        MovieIndexInfo.ScreenConditionsBean.SourceYearBean year = new MovieIndexInfo.ScreenConditionsBean.SourceYearBean();
        year.setYear_code("");
        year.setYear_name("全部年份");
        bean.getSource_year().add(0, year);
        MovieIndexInfo.ScreenConditionsBean.UpdateScheduleBean end = new MovieIndexInfo.ScreenConditionsBean.UpdateScheduleBean();
        end.setSchedule_code("");
        end.setSchedule_name("是否完结");
        bean.getUpdate_schedule().add(0, end);
        MovieIndexInfo.ScreenConditionsBean.SourceHabitBean other = new MovieIndexInfo.ScreenConditionsBean.SourceHabitBean();
        other.setHabit_code("");
        other.setHabit_name("全部地区");
        bean.getSource_habit().add(0, other);

        rgArea.removeAllViews();
        for (int i = 0; i< bean.getSource_area().size(); i++) {
            RadioButton rb = new RadioButton(getMActivity());
            rb.setId(i);
            rb.setTag(bean.getSource_area().get(i).getId());
            rb.setButtonDrawable(null);
            rb.setText(bean.getSource_area().get(i).getArea_name());
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            rb.setGravity(Gravity.CENTER);
            rb.setBackground(getMActivity().getResources().getDrawable(R.drawable.selector_movie_tag));
            rb.setTextColor(getMActivity().getResources().getColorStateList(R.color.color_movie_tag));
            rb.setPadding(35, 0, 35, 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, DensityUtil.dp2px(25));
            rgArea.addView(rb, params);
        }
        rgArea.check(0);

        rgType.removeAllViews();
        for (int i = 0; i< bean.getSource_type().size(); i++) {
            RadioButton rb = new RadioButton(getMActivity());
            rb.setId(i);
            rb.setTag(bean.getSource_type().get(i).getId());
            rb.setButtonDrawable(null);
            rb.setText(bean.getSource_type().get(i).getType_name());
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            rb.setGravity(Gravity.CENTER);
            rb.setBackground(getMActivity().getResources().getDrawable(R.drawable.selector_movie_tag));
            rb.setTextColor(getMActivity().getResources().getColorStateList(R.color.color_movie_tag));
            rb.setPadding(35, 0, 35, 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, DensityUtil.dp2px(25));
            rgType.addView(rb, params);
        }
        rgType.check(0);

        rgYear.removeAllViews();
        for (int i = 0; i< bean.getSource_year().size(); i++) {
            RadioButton rb = new RadioButton(getMActivity());
            rb.setId(i);
            rb.setTag(bean.getSource_year().get(i).getYear_code());
            rb.setButtonDrawable(null);
            rb.setText(bean.getSource_year().get(i).getYear_name());
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            rb.setGravity(Gravity.CENTER);
            rb.setBackground(getMActivity().getResources().getDrawable(R.drawable.selector_movie_tag));
            rb.setTextColor(getMActivity().getResources().getColorStateList(R.color.color_movie_tag));
            rb.setPadding(35, 0, 35, 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, DensityUtil.dp2px(25));
            rgYear.addView(rb, params);
        }
        rgYear.check(0);


        if ("电影".equals(strName)) {
           svEnd.setVisibility(View.GONE);
        }else{
            svEnd.setVisibility(View.VISIBLE);
            rgEnd.removeAllViews();
            for (int i = 0; i< bean.getUpdate_schedule().size(); i++) {
                RadioButton rb = new RadioButton(getMActivity());
                rb.setId(i);
                rb.setTag(bean.getUpdate_schedule().get(i).getSchedule_code());
                rb.setButtonDrawable(null);
                rb.setText(bean.getUpdate_schedule().get(i).getSchedule_name());
                rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                rb.setGravity(Gravity.CENTER);
                rb.setBackground(getMActivity().getResources().getDrawable(R.drawable.selector_movie_tag));
                rb.setTextColor(getMActivity().getResources().getColorStateList(R.color.color_movie_tag));
                rb.setPadding(35, 0, 35, 0);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, DensityUtil.dp2px(25));
                rgEnd.addView(rb, params);
            }
            rgEnd.check(0);
        }

        rgOther.removeAllViews();
        for (int i = 0; i< bean.getSource_habit().size(); i++) {
            RadioButton rb = new RadioButton(getMActivity());
            rb.setId(i);
            rb.setTag(bean.getSource_habit().get(i).getHabit_code());
            rb.setButtonDrawable(null);
            rb.setText(bean.getSource_habit().get(i).getHabit_name());
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            rb.setGravity(Gravity.CENTER);
            rb.setBackground(getMActivity().getResources().getDrawable(R.drawable.selector_movie_tag));
            rb.setTextColor(getMActivity().getResources().getColorStateList(R.color.color_movie_tag));
            rb.setPadding(35, 0, 35, 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, DensityUtil.dp2px(25));
            rgOther.addView(rb, params);
        }
        rgOther.check(0);


        rgArea.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                View viewById = rgArea.findViewById(checkedId);

                selArea = viewById.getTag().toString();
                page = 1;
                search();
            }
        });

        rgType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                View viewById = rgType.findViewById(checkedId);
                selType = viewById.getTag().toString();
                page = 1;
                search();
            }
        });

        rgYear.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                View viewById = rgYear.findViewById(checkedId);

                selYear = viewById.getTag().toString();
                page = 1;
                search();
            }
        });

        rgEnd.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                View viewById = rgEnd.findViewById(checkedId);

                selEnd = viewById.getTag().toString();
                page = 1;
                search();
            }
        });

        rgOther.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                View viewById = rgOther.findViewById(checkedId);

                selOther = viewById.getTag().toString();
                page = 1;
                search();
            }
        });
    }

    private void initList(List<MovieListInfo> list){

        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                tvNull.setVisibility(View.VISIBLE);
            }else{
                mAdapter.setNewData(list);
                tvNull.setVisibility(View.GONE);
            }
        }else{
            mAdapter.addData(list);
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }
        layoutRefresh.finishLoadMore();
    }

    private void getIndex(){
        Kalle.post(HttpUrl.SCREEN_INDEX)
                .tag(tag)
                .param("cat_id", id)
                .perform(new LoadingCallback<MovieIndexInfo>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<MovieIndexInfo, String> response) {
                        if (response.isSucceed()) {
                            indexInfo = response.succeed();
                            addType();
                            initList(indexInfo.getDefault_list());
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void search(){
        FormBody.Builder builder = FormBody.newBuilder();
        builder.param("cat_id", id)
                .param("page", page);
        if (!TextUtils.isEmpty(selArea)) {
            builder.param("area_id", selArea);
        }
        if (!TextUtils.isEmpty(selType)) {
            builder.param("type_id", selType);
        }
        if (!TextUtils.isEmpty(selYear)) {
            builder.param("year", selYear);
        }
        if (!TextUtils.isEmpty(selEnd)) {
            builder.param("habit", selEnd);
        }
        if (!TextUtils.isEmpty(selOther)) {
            builder.param("update_schedule", selOther);
        }
        Kalle.post(HttpUrl.SEARCH)
                .tag(tag)
                .body(builder.build())
                .perform(new NormalCallback<List<MovieListInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<MovieListInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else{
                            initList(null);
                        }
                    }
                });


    }


    @Override
    protected int getLayout() {
        return R.layout.activity_movie_all;
    }

}
