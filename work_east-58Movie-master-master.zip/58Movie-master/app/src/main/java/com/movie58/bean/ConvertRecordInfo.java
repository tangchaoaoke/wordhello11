package com.movie58.bean;

/**
 * Created by yangxing on 2019/6/26 0026.
 */
public class ConvertRecordInfo {


    /**
     * id : 6
     * account_no : isjdjdjdkskjsjs
     * bank_name :
     * account_name :
     * cash_type : 1
     * create_time : 2019-06-27 14:46:00
     * update_time : 1561617960
     * user_id : 8
     * status : 0
     * gold_num : 100
     * scale : 0.010
     * rmb : 1.000
     * handle_time : 1970-01-01 08:00:00
     * bank_address :
     */

    private int id;
    private String account_no;
    private String bank_name;
    private String account_name;
    private int cash_type;
    private String create_time;
    private int update_time;
    private int user_id;
    private int status;
    private int gold_num;
    private float scale;
    private String rmb;
    private String handle_time;
    private String bank_address;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAccount_no() {
        return account_no;
    }

    public void setAccount_no(String account_no) {
        this.account_no = account_no;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public int getCash_type() {
        return cash_type;
    }

    public void setCash_type(int cash_type) {
        this.cash_type = cash_type;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getGold_num() {
        return gold_num;
    }

    public void setGold_num(int gold_num) {
        this.gold_num = gold_num;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public String getRmb() {
        return rmb;
    }

    public void setRmb(String rmb) {
        this.rmb = rmb;
    }

    public String getHandle_time() {
        return handle_time;
    }

    public void setHandle_time(String handle_time) {
        this.handle_time = handle_time;
    }

    public String getBank_address() {
        return bank_address;
    }

    public void setBank_address(String bank_address) {
        this.bank_address = bank_address;
    }
}
