package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.RuleBean;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class RuleAdapter extends BaseQuickAdapter<RuleBean.RuleListBean, BaseViewHolder> {

    public RuleAdapter(@Nullable List<RuleBean.RuleListBean> data) {
        super(R.layout.item_rule, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, RuleBean.RuleListBean item) {

        helper.setText(R.id.tv_title, item.getRule_name())
                .setText(R.id.tv_bi, "+" + item.getGold_num()+"~"+item.getGold_num_max() + " 金币/个")
                .setText(R.id.tv_des, item.getRule_desc());
        ImageView iv = helper.getView(R.id.iv_img);
        PicassoUtils.LoadImage(mContext, item.getRule_img(), iv);
        helper.addOnClickListener(R.id.btn);
        Button btn = helper.getView(R.id.btn);
        if (item.getComplete_status() == 1) {
            btn.setText("已完成");
            btn.setEnabled(false);
        }else{
            btn.setText(item.getGrant_button_title());
            btn.setEnabled(true);
        }
    }
}
