package com.movie58.base;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.gyf.immersionbar.ImmersionBar;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.movie58.R;
import com.movie58.newdemand.base.AppManager;
import com.movie58.newdemand.base.AppStatusManager;
import com.movie58.newdemand.base.BaseFragment;
import com.movie58.newdemand.base.FragmentParam;
import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.utils.DisplayUtil;
import com.movie58.lifecycle.ActivityLifecycleable;
import com.trello.rxlifecycle2.android.ActivityEvent;
import com.zhy.autolayout.utils.AutoUtils;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.Subject;
import me.yokeyword.fragmentation.SupportActivity;
import me.yokeyword.fragmentation.anim.DefaultHorizontalAnimator;
import me.yokeyword.fragmentation.anim.FragmentAnimator;

/**
 * Created by yangxing on 2017/6/28 0028.
 */

public class BaseActivity extends SupportActivity implements ActivityLifecycleable, ApiListener {

    private final BehaviorSubject<ActivityEvent> mLifecycleSubject = BehaviorSubject.create();
    protected final String tag = getClass().getSimpleName();

    private boolean isTwoBack;
    BasePopupView dialogReview_base;

    public boolean isFitsSystem = true;
    public void setBackTwo(boolean isTwoBack) {
        this.isTwoBack = isTwoBack;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppManager.getInstance().addActivity(this);
        if (AppStatusManager.getInstance().getAppStatus() != 1) {
            protectApp();
            return;
        }
//        setTheme(R.style.TranslucentTheme);
        //状态栏
        if (isFitsSystem) {
            ImmersionBar.with(this)
                    .statusBarColor(R.color.colorPrimaryDark)
                    .fitsSystemWindows(true)
                    .init();
        }
    }
    protected int getFragmentContainerId() {
        return 0;
    }

    protected void protectApp() {
        AppManager.getInstance().killActivity(this);
    }

    public void initTopview(RelativeLayout relay, RelativeLayout relay_top) {
        int StatusBarHeight = DisplayUtil.getStateBar(this);
        if (StatusBarHeight <= 0) {
            StatusBarHeight = (int) DisplayUtil.dip2px(this, 20);
        }
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) relay.getLayoutParams();
        lp.height = AutoUtils.getPercentHeightSize(150);
        lp.topMargin = StatusBarHeight;
        relay.setLayoutParams(lp);

        LinearLayout.LayoutParams lp2 = (LinearLayout.LayoutParams) relay_top.getLayoutParams();
        lp2.height = AutoUtils.getPercentHeightSize(150)+StatusBarHeight;
        relay_top.setLayoutParams(lp2);

    }
    public void setFitsSystem(boolean isFitsSystem) {
        this.isFitsSystem = isFitsSystem;
    }

    public void stopProgressDialog() {
        if (dialogReview_base != null && dialogReview_base.isShow()) {
            dialogReview_base.dismiss();
        }
    }

    public void startProgressDialog() {
        if (dialogReview_base == null) {
            dialogReview_base = new XPopup.Builder(this)
                    .asLoading("加载中...");
        }
        if (dialogReview_base != null && !dialogReview_base.isShow()) {
            dialogReview_base.show();
        }
    }

    @Override
    protected void onDestroy() {
        mLifecycleSubject.onNext(ActivityEvent.DESTROY);
        super.onDestroy();
        if (dialogReview_base != null) {
            dialogReview_base.dismiss();
            dialogReview_base = null;
        }
        AppManager.getInstance().removeActivity(this);
    }

    @Override
    public FragmentAnimator onCreateFragmentAnimator() {
        // 设置默认Fragment动画
        return new DefaultHorizontalAnimator();
    }

    public void onResume() {
        super.onResume();
        mLifecycleSubject.onNext(ActivityEvent.RESUME);
    }

    public void onPause() {
        mLifecycleSubject.onNext(ActivityEvent.PAUSE);
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mLifecycleSubject.onNext(ActivityEvent.START);
    }


    @Override
    protected void onStop() {
        mLifecycleSubject.onNext(ActivityEvent.STOP);
        super.onStop();
    }

    @NonNull
    @Override
    public Subject<ActivityEvent> provideLifecycleSubject() {
        return mLifecycleSubject;
    }

    @Override
    public void onCancelled(Callback.CancelledException var1) {

    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {

    }

    @Override
    public void onError(int var1, RequestParams var2) {

    }

    @Override
    public void onExceptionType(Throwable var1, RequestParams params, String type) {

    }

    public void SetTranslanteBar() {
        fullScreen(this);
    }

    private void fullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                //5.x开始需要把颜色设置透明，否则导航栏会呈现系统默认的浅灰色
                Window window = activity.getWindow();
                View decorView = window.getDecorView();
                //两个 flag 要结合使用，表示让应用的主体内容占用系统状态栏的空间
                int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                decorView.setSystemUiVisibility(option);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                //导航栏颜色也可以正常设置
//                window.setNavigationBarColor(Color.TRANSPARENT);

//                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//                window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
//                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//                window.setStatusBarColor(Color.TRANSPARENT);
            } else {
                Window window = activity.getWindow();
                WindowManager.LayoutParams attributes = window.getAttributes();
                int flagTranslucentStatus = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
                int flagTranslucentNavigation = WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION;
                attributes.flags |= flagTranslucentStatus;
//                attributes.flags |= flagTranslucentNavigation;
                window.setAttributes(attributes);
            }
        }
    }
    protected int getFragmentContainerId2() {
        return 0;
    }
    public void addFragment(Class<?> cls, Object data) {
        FragmentParam param = new FragmentParam();
        param.cls = cls;
        param.data = data;
        param.addToBackStack = false;
        processFragement(param);
    }
    protected String getFragmentTag(FragmentParam param) {
        StringBuilder sb = new StringBuilder(param.cls.toString() + param.tag);
        return sb.toString();
    }

    protected BaseFragment currentFragment;
    private List<BaseFragment> fragments;

    private void processFragement(FragmentParam param) {
        int containerId;
        if (!TextUtils.isEmpty(param.Id)) {
            containerId = getFragmentContainerId2();
        } else {
            containerId = getFragmentContainerId();
        }

        Class cls = param.cls;
        if (cls != null) {
            try {
                String e = getFragmentTag(param);
                com.movie58.newdemand.base.BaseFragment fragment = (com.movie58.newdemand.base.BaseFragment) getSupportFragmentManager().findFragmentByTag(e);
                if (fragment == null) {
                    fragment = (com.movie58.newdemand.base.BaseFragment) cls.newInstance();
                }
//              fragment.onComeIn(param.data);
                if (this.currentFragment != null) {
//                  this.currentFragment.onLeave();
                }

                if (this.fragments == null) {
                    this.fragments = new ArrayList();
                }
                addDistinctEntry(this.fragments, fragment);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                if (param.type != FragmentParam.TYPE.ADD) {
                    ft.replace(containerId, fragment, e);
                } else if (!fragment.isAdded()) {
                    ft.add(containerId, fragment, e);
                    if (param.data != null) {
                        fragment.initrefreshData(param.data);
                    }
                } else {
                    Iterator var7 = this.fragments.iterator();
                    while (var7.hasNext()) {
                        com.movie58.newdemand.base.BaseFragment lastFragment = (BaseFragment) var7.next();
                        ft.hide(lastFragment);
                    }
                    if (this.currentFragment != null) {
                        this.currentFragment.onPause();
                    }
                    ft.show(fragment);
                    fragment.onResume();
                    if (param.data != null) {
                        fragment.refreshData(param.data);
                    }
                }
                this.currentFragment = fragment;
                if (param.addToBackStack) {
                    ft.addToBackStack(e);
                }
                ft.commitAllowingStateLoss();

            } catch (InstantiationException var9) {
                var9.printStackTrace();
            } catch (IllegalAccessException var10) {
                var10.printStackTrace();
            }
        }
    }
    public static <V> boolean addDistinctEntry(List<V> sourceList, V entry) {
        return (sourceList != null && !sourceList.contains(entry)) && sourceList.add(entry);
    }


    public void setStatus(String color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(color));
//            if (map.get("status_text_color_type").equals("1")) {   //黑色
                window.getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//            }
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(color));
            //底部导航栏
            //window.setNavigationBarColor(activity.getResources().getColor(colorResId));
        }
    }

}
