package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/12 0012.
 */
public class LoginInfo {
    /**
     * token : cdebd4036bcd4d2d0964299c9e7db9c00ff0ffdd56e050516d44d82e8742f555
     * user : {"id":6,"user_type":2,"sex":0,"birthday":0,"last_login_time":0,"score":0,"coin":0,"balance":"0.00","create_time":1557664549,"user_status":1,"user_login":"Pnhl16","user_pass":"###cb81048ae53ff5bcf8b05204483916a8","user_nickname":"","user_email":"","user_url":"","avatar":"","signature":"","last_login_ip":"","user_activation_key":"","mobile":"15275257307","more":null}
     */

    private String token;
    private UserInfo user;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public UserInfo getUser() {
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }
}
