package com.movie58.util;

import com.hjq.toast.style.ToastBlackStyle;

/**
 *    github : https://github.com/getActivity/ToastUtils
 * Created by yangxing on 2018/12/11 0011.
 */
public class ToastStyle extends ToastBlackStyle {

    @Override
    public int getZ() {
        return 0;  //取消阴影
    }

    @Override
    public int getCornerRadius() {
        return 4;
    }

    @Override
    public float getTextSize() {
        return 14;
    }

    @Override
    public int getMaxLines() {
        return 3;
    }

    @Override
    public int getPaddingLeft() {
        return 18;
    }

    @Override
    public int getPaddingTop() {
        return 8;
    }
}
