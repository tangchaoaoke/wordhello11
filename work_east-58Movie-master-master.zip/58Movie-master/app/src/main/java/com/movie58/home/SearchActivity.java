package com.movie58.home;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.flyco.tablayout.SlidingTabLayout;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.flow.FlowLayout;
import com.movie58.newdemand.interfaces.History;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.account.Account;
import com.movie58.adapter.SearchAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.HomeTab;
import com.movie58.bean.MovieListInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.ToolUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.zhy.autolayout.utils.AutoUtils;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/29 0029.
 */
public class SearchActivity extends BaseUseActivity {

    @BindView(R.id.et_search)
    EditText etSearch;
    @BindView(R.id.iv_del)
    ImageView ivDel;
    @BindView(R.id.layout_tab)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp)
    ViewPager vp;
    @BindView(R.id.layout_search)
    LinearLayout layoutSearch;
    @BindView(R.id.rv_search)
    RecyclerView rvSearch;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.flowlayout)
    FlowLayout flowlayout;
    @BindView(R.id.scrollview)
    NestedScrollView scrollview;
    @BindView(R.id.top)
    RelativeLayout top;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.recyclerView_ii)
    RecyclerView recyclerView_ii;
    @BindView(R.id.tv_search_01)
    TextView tv_search_01;
    List<HomeTab> listTab = new ArrayList<>();
    String strSearch;
    int page = 1;
    SearchAdapter mAdapter;
    GoldRecyclerAdapter adapter;

    @Override
    protected void initView() {
        getTab();
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            /*判断是否是“搜索”键*/
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (TextUtils.isEmpty(etSearch.getText().toString())) {
                    ToastUtils.show("请输入您要搜索的内容");
                    return true;
                }
                etSearch.clearFocus();
                strSearch = etSearch.getText().toString().trim();
                scrollview.setVisibility(View.GONE);
                layoutRefresh.setVisibility(View.VISIBLE);
                recyclerView_ii.setVisibility(View.GONE);
                page = 1;
                search();
                addSearch(strSearch);
                ToolUtil.hideSoftInput(etSearch);
                return true;
            }
            return false;
        });
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(etSearch.getText().toString())) {
                    recyclerView_ii.setVisibility(View.GONE);
                    scrollview.setVisibility(View.VISIBLE);
                    layoutRefresh.setVisibility(View.GONE);
                    tv_search_01.setVisibility(View.GONE);
                    return;
                }
                tv_search_01.setVisibility(View.VISIBLE);
                if (etSearch.hasFocus()) {
                    history.d(etSearch.getText().toString(), SearchActivity.this);
                }
            }
        });
        layoutRefresh.setEnableRefresh(false);
        layoutRefresh.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page++;
                search();
            }
        });

        mAdapter = new SearchAdapter(new ArrayList<>());
        mAdapter.bindToRecyclerView(rvSearch);
        rvSearch.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                if (Account.getInstance().isLogined()) {
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("id", mAdapter.getItem(position).getId());
                startActivity(MovieDetailActivity.class, map);
//                }else{
//                    startActivity(LoginActivity.class);
//                }
            }
        });
    }

    @OnClick({R.id.iv_back, R.id.iv_del, R.id.imgv_del,R.id.tv_search_01})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.iv_del:
                etSearch.setText("");
                scrollview.setVisibility(View.VISIBLE);
                layoutRefresh.setVisibility(View.GONE);
                recyclerView_ii.setVisibility(View.GONE);
                break;
            case R.id.imgv_del:
                if (Account.getInstance().isLogined()) {
                    startProgressDialog();
                    history.cAll(Account.getInstance().getToken(), "", this);
                }
                break;
            case R.id.tv_search_01:
                if (TextUtils.isEmpty(etSearch.getText().toString())){
                    return;
                }
                etSearch.clearFocus();
                strSearch = etSearch.getText().toString().trim();
                scrollview.setVisibility(View.GONE);
                layoutRefresh.setVisibility(View.VISIBLE);
                recyclerView_ii.setVisibility(View.GONE);
                page = 1;
                search();
                addSearch(strSearch);
                ToolUtil.hideSoftInput(etSearch);
                break;
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setFitsSystem(false);
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        initTopview(top, relay_top);
        initHistory();

    }

    private class MyPagerAdapter extends FragmentPagerAdapter {
        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return listTab.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return listTab.get(position).getCat_name();
        }

        @Override
        public Fragment getItem(int position) {
            return SearchHotFragment.newInstance(listTab.get(position).getId());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_05_SCHOOL_TIME_VIDEO:
                strSearch = event.getObj1().toString();
                etSearch.setText(strSearch);
                scrollview.setVisibility(View.GONE);
                recyclerView_ii.setVisibility(View.GONE);
                layoutRefresh.setVisibility(View.VISIBLE);
                page = 1;
                search();
                break;
        }
    }

    private void getTab() {
        Kalle.post(HttpUrl.SEARCH_TAB)
                .tag(tag)
                .perform(new LoadingCallback<List<HomeTab>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<HomeTab>, String> response) {
                        if (response.isSucceed()) {
                            listTab = response.succeed();
                            if (listTab != null && !listTab.isEmpty()) {
                                vp.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));
                                layoutTab.setViewPager(vp);
                            }
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void search() {
        Kalle.post(HttpUrl.SEARCH)
                .tag(tag)
                .param("source_name", strSearch)
                .param("size", 10)
                .param("page", page)
                .perform(new LoadingCallback<List<MovieListInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<MovieListInfo>, String> response) {
                        if (response.isSucceed()) {
                            recyclerView_ii.setVisibility(View.GONE);
                            scrollview.setVisibility(View.GONE);
                            layoutRefresh.setVisibility(View.VISIBLE);
                            initList(response.succeed());
                        } else {
                            initList(null);
                        }
                    }
                });


    }

    private void initList(List<MovieListInfo> list) {

        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            } else {
                mAdapter.setNewData(list);

            }
        } else {
            mAdapter.addData(list);
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        } else {
            layoutRefresh.setEnableLoadMore(true);
        }
        layoutRefresh.finishLoadMore();
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_search;
    }


    private History history;

    public void initHistory() {
        history = new History();
        if (Account.getInstance().isLogined()) {
            history.a(Account.getInstance().getToken(), "android", this);
        }
    }

    public void addSearch(String content) {
        history.b(Account.getInstance().getToken(), content, this);
    }

    private ArrayList<Map<String, String>> list;

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        if (type.equals("searchLog")) {
            list = JSONUtils.parseDataToMapList(var2);
            if (list == null || list.size() == 0) {
                flowlayout.setVisibility(View.GONE);
                return;
            }
            flowlayout.setVisibility(View.VISIBLE);
            initLayout(list);
        }
        if (type.equals("searchDelete")) {
            stopProgressDialog();
            if (deleteIndex == -1 || deleteIndex >= list.size()) {
                return;
            }
            flowlayout.removeViewAt(deleteIndex);
            list.remove(deleteIndex);
            initLayout(list);
        }
        if (type.equals("searchDelete.all")) {
            stopProgressDialog();
            list.clear();
            for (int i = 0; i < flowlayout.getChildCount(); i++) {
                flowlayout.removeViewAt(i);
            }
            initLayout(list);
        }

        if (type.equals("searchName.ii")) {
            ArrayList<Map<String, String>> maps = JSONUtils.parseDataToMapList(var2);
            Log.e("ppppppppp", maps.size() + "");
            if (maps == null || maps.size() == 0) {
                return;
            } else {
                recyclerView_ii.setVisibility(View.VISIBLE);
                scrollview.setVisibility(View.GONE);
                layoutRefresh.setVisibility(View.GONE);
            }
            if (adapter == null) {
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
                linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
                recyclerView_ii.setLayoutManager(linearLayoutManager);
                adapter = new GoldRecyclerAdapter(this, maps);
                recyclerView_ii.setAdapter(adapter);
            } else {
                adapter.setData(maps);
            }
        }
    }


    private void initLayout(ArrayList<Map<String, String>> arr) {
        flowlayout.removeAllViewsInLayout();
        final RelativeLayout[] layouts = new RelativeLayout[arr.size()];
        for (int i = 0; i < arr.size(); i++) {
            View view = LayoutInflater.from(this).inflate(R.layout.item_history, flowlayout, false);
            TextView text = view.findViewById(R.id.tv_content);
            RelativeLayout relay = view.findViewById(R.id.relay);
            text.setText(arr.get(i).get("search_name"));
            layouts[i] = relay;
            flowlayout.addView(view);
            int finalI = i;
            relay.setOnClickListener(v -> {
                strSearch = list.get(finalI).get("search_name");
                etSearch.clearFocus();
                etSearch.setText(strSearch);

                search();
                addSearch(strSearch);
                ToolUtil.hideSoftInput(etSearch);
                scrollview.setVisibility(View.GONE);
                recyclerView_ii.setVisibility(View.GONE);
                layoutRefresh.setVisibility(View.VISIBLE);
            });

            relay.setOnLongClickListener(v -> {
//                for (int j = 0; j < layouts.length; j++) {
//                    if (relay.equals(layouts[j])) {
//                        flowlayout.removeViewAt(j);
//                        list.remove(j);
//                        initLayout(list);
//                    }
//                }
                showDeleteDialog(finalI);
                return false;
            });

        }
    }

    private int deleteIndex = 0;

    public void showDeleteDialog(int index) {
        Dialog dialog = new Dialog(this, R.style.dialog2);
        View inflate = LayoutInflater.from(this).inflate(R.layout.dialog_delete, null);
        TextView tv_ok = inflate.findViewById(R.id.tv_ok);
        TextView tv_cancel = inflate.findViewById(R.id.tv_cancel);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);

        tv_cancel.setOnClickListener(v -> dialog.dismiss());
        tv_ok.setOnClickListener(v -> {
            deleteIndex = index;
            dialog.dismiss();
            startProgressDialog();
            history.c(Account.getInstance().getToken(), list.get(index).get("id"), SearchActivity.this);
        });

        dialog.setContentView(inflate);
        Window dialogWindow = dialog.getWindow();
        dialogWindow.setGravity(Gravity.CENTER);
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay();
        lp.width = (int) (d.getWidth() * 0.85);
        dialogWindow.setAttributes(lp);
        dialog.show();
    }

    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private LayoutInflater inflater;
        private ArrayList<Map<String, String>> list;

        public GoldRecyclerAdapter(Context context, ArrayList<Map<String, String>> list) {
            inflater = LayoutInflater.from(context);
            this.list = list;
        }

        public void setData(ArrayList<Map<String, String>> list2) {
            if (list != null) {
                list.clear();
            } else {
                list = new ArrayList<>();
            }
            list.addAll(list2);
            notifyDataSetChanged();

        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_search_01, parent, false);
            return new GoldRecyclerAdapter.fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            GoldRecyclerAdapter.fGoldViewHolder holder1 = (GoldRecyclerAdapter.fGoldViewHolder) holder;
            holder1.tv_content.setText(list.get(position).get("source_name"));
            holder1.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(list.get(position).get("source_name"));
                    strSearch = list.get(position).get("source_name");
                    etSearch.clearFocus();
                    search();
                    addSearch(strSearch);
                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {
            @BindView(R.id.tv_content)
            TextView tv_content;


            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }


}
