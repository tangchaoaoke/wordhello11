package com.movie58.newdemand.base;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.newdemand.utils.ToastUitl;
import com.movie58.account.Account;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.Map;

import butterknife.ButterKnife;
import butterknife.Unbinder;


public abstract class BaseFragment extends Fragment implements ApiListener {
    protected View rootView;
    public LayoutInflater inflater;
    private Unbinder unbinder;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        x.view().inject(this, this.getView());
        unbinder = ButterKnife.bind(this, view);
    }


    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (getUserVisibleHint()) {
            onVisible();
        } else {
            onInvisible();
        }
    }

    public boolean isVisible;
    private boolean isLoaded;
    private boolean isCreateView;

    protected void onVisible() {
        isVisible = true;
        if (isLoaded) {
            refreshLoad();
        }
        if (!isLoaded && isCreateView && getUserVisibleHint()) {
            isLoaded = true;
            lazyLoad();
        }
    }

    BasePopupView dialogReview_base;

    public void stopProgressDialog() {
        if (dialogReview_base != null && dialogReview_base.isShow()) {
            dialogReview_base.dismiss();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (dialogReview_base != null) {
            dialogReview_base.dismiss();
            dialogReview_base = null;
        }
    }

    public void startProgressDialog() {
        if (dialogReview_base == null) {
            dialogReview_base = new XPopup.Builder(getActivity())
                    .asLoading("加载中...");
        }
        if (dialogReview_base != null && !dialogReview_base.isShow()) {
            dialogReview_base.show();
        }
    }

    protected void onInvisible() {
        isVisible = false;
    }

    /**
     * fragment第一次可见的时候回调此方法
     */
//    protected abstract void lazyLoad();
    public void lazyLoad() {

    }

    /**
     * 在Fragment第一次可见加载以后，每次Fragment滑动可见的时候会回调这个方法，
     * 子类可以重写这个方法做数据刷新操作
     */
    protected void refreshLoad() {
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        if (rootView == null) {
            rootView = inflater.inflate(getLayoutResource(), container, false);
            isCreateView = true;
            onVisible();
        }

        initPresenter();
        initView();
        return rootView;
    }

    //获取布局文件
    protected abstract int getLayoutResource();

    //获取布局文件
    public void requestDatas() {
    }

    public void refreshData(Object url) {

    }

    public void initrefreshData(Object url) {

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        requestDatas();
    }


    public abstract void initPresenter();


    protected abstract void initView();


    public void startActivity(Class<?> cls) {
        startActivity(cls, null);
    }


    public void startActivityForResult(Class<?> cls, int requestCode) {
        startActivityForResult(cls, null, requestCode);
    }


    public void startActivityForResult(Class<?> cls, Bundle bundle,
                                       int requestCode) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), cls);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivityForResult(intent, requestCode);
    }


    public void startActivity(Class<?> cls, Bundle bundle) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), cls);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);

    }


    public void showShortToast(String text) {
        ToastUitl.showShort(getActivity(), text);
    }


    public void showShortToast(int resId) {
        ToastUitl.showShort(getActivity(), resId);
    }

    public void showLongToast(int resId) {
        ToastUitl.showLong(getActivity(), resId);
    }

    public void showLongToast(String text) {
        ToastUitl.showLong(getActivity(), text);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }


    @Override
    public void onCancelled(Callback.CancelledException var1) {
    }

    @Override
    public void onError(int var1, RequestParams var2) {
        stopProgressDialog();
        showShortToast("服务器异常");
    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        Map<String, String> map = JSONUtils.parseKeyAndValueToMap(var2);
        if (map.get("code").equals("10001")) {
            Account.getInstance().loginOut();
        }
    }


    @Override
    public void onExceptionType(Throwable var1, RequestParams params, String type) {
        stopProgressDialog();
    }
}
