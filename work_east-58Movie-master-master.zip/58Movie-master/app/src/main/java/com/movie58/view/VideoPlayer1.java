package com.movie58.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.bean.DetailAdInfo;
import com.movie58.event.Event;
import com.movie58.img.PicassoUtils;
import com.movie58.util.OnDoubleClickListener;

import org.greenrobot.eventbus.EventBus;

import cn.jzvd.JZMediaInterface;
import cn.jzvd.JZUtils;
import cn.jzvd.JzvdStd;

/**
 * Created by yangxing on 2019/8/14 0014.
 */
public class VideoPlayer1 extends JzvdStd {


    private ImageView ivBack, ivAd;
    TextView tvSpeed, tvTime;
    RelativeLayout layoutSpeed, layoutAd;
    RadioGroup rgSpeed;
    RadioButton btn10, btn125, btn15, btn20;
    int speedIndex;
    private DetailAdInfo adInfo;
    public boolean isComplete = false;
    public boolean isAd = false;


    public VideoPlayer1(Context context) {
        super(context);
    }

    public VideoPlayer1(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void setScreenNormal() {
        super.setScreenNormal();
        tvSpeed.setVisibility(GONE);
        ivBack.setVisibility(VISIBLE);
    }

    @Override
    public void setScreenFullscreen() {
        super.setScreenFullscreen();
        ivBack.setVisibility(GONE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M)
            tvSpeed.setVisibility(View.VISIBLE);

        if (jzDataSource.objects == null) {
            Object[] object = {2};
            jzDataSource.objects = object;
            speedIndex = 2;
        } else {
            speedIndex = (int) jzDataSource.objects[0];
        }
        if (speedIndex == 2) {
            tvSpeed.setText("倍速");
        } else {
            tvSpeed.setText(getSpeedFromIndex(speedIndex) + "x");
        }
    }

    private float getSpeedFromIndex(int index) {
        float ret = 0f;
        if (index == 0) {
            ret = 0.5f;
        } else if (index == 1) {
            ret = 0.75f;
        } else if (index == 2) {
            ret = 1.0f;
        } else if (index == 3) {
            ret = 1.25f;
        } else if (index == 4) {
            ret = 1.5f;
        } else if (index == 5) {
            ret = 1.75f;
        } else if (index == 6) {
            ret = 2.0f;
        }
        return ret;
    }


    @Override
    public void init(Context context) {
        super.init(context);
        SAVE_PROGRESS = false;
        ivBack = findViewById(R.id.back1);
        ivBack.setOnClickListener(this);
        tvSpeed = findViewById(R.id.tv_speed);
        tvSpeed.setOnClickListener(this);
        layoutSpeed = findViewById(R.id.layout_speed);
        layoutSpeed.setOnClickListener(this);
        rgSpeed = findViewById(R.id.rg_speed);
        btn10 = findViewById(R.id.btn_10);
        btn125 = findViewById(R.id.btn_125);
        btn15 = findViewById(R.id.btn_15);
        btn20 = findViewById(R.id.btn_20);
        layoutAd = findViewById(R.id.layout_ad);
        tvTime = findViewById(R.id.ad_time);
        ivAd = findViewById(R.id.iv_ad);

        rgSpeed.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.btn_10:
                        speedIndex = 2;
                        tvSpeed.setText("倍数");
                        break;
                    case R.id.btn_125:
                        speedIndex = 3;
                        tvSpeed.setText("1.25x");
                        break;
                    case R.id.btn_15:
                        speedIndex = 4;
                        tvSpeed.setText("1.5x");
                        break;
                    case R.id.btn_20:
                        speedIndex = 6;
                        tvSpeed.setText("2.0x");
                        break;
                }
                mediaInterface.setSpeed(getSpeedFromIndex(speedIndex));
                jzDataSource.objects[0] = speedIndex;
                layoutSpeed.setVisibility(GONE);
            }
        });
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_player1;
    }

    public void setAd(DetailAdInfo info){
        adInfo = info;
        if (adInfo == null || adInfo.getVod_advert() == null) {
            startVideo(); //开始播放
            return;
        }
        PicassoUtils.LoadImageWithDetfult(getContext(), adInfo.getVod_advert().getAdvert_img(), ivAd, R.drawable.pic_emptypage_failure);
        layoutAd.setVisibility(VISIBLE);
        if (!TextUtils.isEmpty(adInfo.getVod_advert().getAdvert_url())) {
            ivAd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EventBus.getDefault().post(new Event(Event.CODE_19_MODE).setObj1(adInfo));
                }
            });
        }

        isAd = true;
        android.os.CountDownTimer timer = new android.os.CountDownTimer(5000, 1000) {

            @SuppressLint("DefaultLocale")
            @Override
            public void onTick(long millisUntilFinished) {
                tvTime.setText(millisUntilFinished / 1000 + "");
            }

            @Override
            public void onFinish() {
                tvTime.setText("0");
                layoutAd.setVisibility(GONE);
                startVideo(); //开始播放
                isAd = false;
            }
        };
        timer.start();
    }

    public boolean isAd(){
        return isAd;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (OnDoubleClickListener.CanClick.NoClick()) return;
        switch (v.getId()) {
            case R.id.back1:
                EventBus.getDefault().post(new Event(Event.CODE_15_MESSAGE_UNREAD));
                break;
            case R.id.tv_speed:
                if (layoutSpeed.getVisibility() == GONE) {
                    layoutSpeed.setVisibility(VISIBLE);
                }
                break;
            case R.id.layout_speed:
                layoutSpeed.setVisibility(GONE);
                break;
        }
    }


    @Override
    public void startVideo() {
        if (screen == SCREEN_FULLSCREEN) {
            Log.d(TAG, "startVideo [" + this.hashCode() + "] ");
            JZMediaInterface.SAVED_SURFACE = null;
            addTextureView();
            AudioManager mAudioManager = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            mAudioManager.requestAudioFocus(onAudioFocusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            JZUtils.scanForActivity(getContext()).getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
//            JZMediaPlayer.instance().positionInList = positionInList;
            onStatePreparing();
        } else {
            super.startVideo();
        }
    }

    @Override
    public void onAutoCompletion() {
        if (screen == SCREEN_FULLSCREEN) {
            onStateAutoComplete();
        } else {
            super.onAutoCompletion();
        }

    }

    @Override
    public void showWifiDialog() {

    }

    @Override
    public void onStatePlaying() {
        super.onStatePlaying();
        long time = getCurrentPositionWhenPlaying() / 1000;

    }

    @Override
    public void onStateAutoComplete() {
        super.onStateAutoComplete();
        isComplete = true;

    }

    /**
     * @param progress 百分比
     * @param position 当前时间
     * @param duration 总时长
     */
    @Override
    public void onProgress(int progress, long position, long duration) {
        super.onProgress(progress, position, duration);
        long totalSeconds = position / 1000;

        if (totalSeconds >= 30 * 60) { //观看30分钟

        }
    }
}
