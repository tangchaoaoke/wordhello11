package com.movie58.my;

import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/14 0014.
 */
public class SexFragment extends BaseFragment {


    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.rb_nan)
    RadioButton rbNan;
    @BindView(R.id.rb_nv)
    RadioButton rbNv;
    @BindView(R.id.rg_sex)
    RadioGroup rgSex;

    String strSex = "0";

    public static SexFragment newInstance() {
        return new SexFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("性别");
        tvRight.setText("确定");

        String sex = Account.getInstance().getSex();
        switch (sex){
            case "1":
                rbNan.setChecked(true);
                break;
            case "2":
                rbNv.setChecked(true);
                break;
        }

        rgSex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_nan) {
                    strSex = "1";
                }else{
                    strSex = "2";
                }
            }
        });
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void click(View v){
        hideSoftInput();
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.tv_right:
                if ("0".equals(strSex)) {
                    ToastUtils.show("请选择性别");
                    return;
                }
                changeName();
                break;
        }
    }

    private void changeName(){
        Kalle.get(HttpUrl.CHANGE_USER)
                .tag(tag)
                .param("user_sex", strSex)
                .param("user_id", Account.getInstance().getUserId())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("性别修改成功！");
                            Account.getInstance().setSex(strSex);
                            EventBus.getDefault().post(new Event(Event.CODE_07_SCHOOL_SORT));
                            pop();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_sex;
    }

}
