package com.movie58.my;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.gyf.immersionbar.BarHide;
import com.gyf.immersionbar.ImmersionBar;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.view.VideoPlayer1;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/8/14 0014.
 */
public class CachePlayerActivity extends BaseUseActivity {

    @BindView(R.id.detail_player)
    VideoPlayer1 videoPlayer;

    String path;
    String title;

    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        path = b.getString("path");
        title = b.getString("title");
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersionBar.with(getMActivity())
                .fitsSystemWindows(false)
                .transparentStatusBar()
                .hideBar(BarHide.FLAG_HIDE_STATUS_BAR)
                .init();
        ImmersionBar.hideStatusBar(getWindow());
    }

    @Override
    protected void initView() {
//        path = path + ".mp4";

        videoPlayer.setUp(path, title);
        videoPlayer.startVideo();

//        VideoPlayer1.startFullscreenDirectly(getMActivity(), VideoPlayer1.class, path, title);

    }

    @OnClick({R.id.back, R.id.back1})
    void back(){
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        //home back
        videoPlayer.goOnPlayOnResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            videoPlayer.goOnPlayOnPause();
        }catch (NullPointerException e){

        }

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_cache_player;
    }
}
