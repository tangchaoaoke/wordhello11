package com.movie58.my;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 邀请码
 * Created by yangxing on 2019/5/7 0007.
 */
public class CodeFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvRight;
    @BindView(R.id.et)
    EditText et;
    @BindView(R.id.btn_submit)
    SuperButton btnSubmit;


    public static CodeFragment newInstance() {
        return new CodeFragment();
    }

    @Override
    protected void initView() {
        tvRight.setText("邀请码");

    }

    @OnClick({R.id.iv_back, R.id.btn_submit})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.btn_submit:
                String code = et.getText().toString().trim();
                if (TextUtils.isEmpty(code)) {
                    ToastUtils.show("请输入邀请码");
                    return;
                }
                submit(code);
                break;
        }
    }

    private void submit(String code){
        Kalle.post(HttpUrl.INVIDE_CODE)
                .tag(tag)
                .param("invite_code", code)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("邀请码验证成功");
                            pop();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_code;
    }

}
