package com.movie58.adapter;

import android.support.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.SearchHotInfo;

import java.util.List;

/**
 * Created by yangxing on 2019/5/8 0008.
 */
public class SearchHotAdapter extends BaseQuickAdapter<SearchHotInfo, BaseViewHolder> {



    public SearchHotAdapter(@Nullable List<SearchHotInfo> data) {
        super(R.layout.item_search_hot, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, SearchHotInfo item) {
        helper.setText(R.id.tv_no, (helper.getLayoutPosition() + 1) + ".")
                .setText(R.id.tv_name, item.getSource_name());

        switch (helper.getLayoutPosition()){
            case 0:
                helper.setTextColor(R.id.tv_no, mContext.getResources().getColor(R.color.hot_1));
                break;
            case 1:
                helper.setTextColor(R.id.tv_no, mContext.getResources().getColor(R.color.hot_2));
                break;
            case 2:
                helper.setTextColor(R.id.tv_no, mContext.getResources().getColor(R.color.hot_3));
                break;
                default:
                    helper.setTextColor(R.id.tv_no, mContext.getResources().getColor(R.color.hot_4));
                    break;
        }

        switch (item.getTrend()){
            case 0:
                helper.setImageResource(R.id.iv_level, R.drawable.hot_ping);
                break;
            case 1:
                helper.setImageResource(R.id.iv_level, R.drawable.hot_shang);
                break;
            case -1:
                helper.setImageResource(R.id.iv_level, R.drawable.hot_xia);
                break;
        }

        switch (item.getUp_right_text()){
            case "火爆":
                helper.setGone(R.id.iv_type, true);
                helper.setImageResource(R.id.iv_type, R.drawable.hot_huobao);
                break;
            case "热播":
                helper.setImageResource(R.id.iv_type, R.drawable.hot_rebo);
                helper.setGone(R.id.iv_type, true);
                break;
            case "1080P":
                helper.setImageResource(R.id.iv_type, R.drawable.hot_1080);
                helper.setGone(R.id.iv_type, true);
                break;
                default:
                    helper.setGone(R.id.iv_type, false);
                    break;
        }
    }
}
