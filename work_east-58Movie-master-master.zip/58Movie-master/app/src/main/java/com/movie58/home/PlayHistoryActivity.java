package com.movie58.home;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.blankj.utilcode.util.SPUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.ui.sheet.SheetAllFrg;
import com.movie58.newdemand.utils.PhoneIdUitls;
import com.movie58.adapter.HistoryAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.CollectInfo;
import com.movie58.bean.HistoryInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.util.ResourceUtils;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;
import com.zhy.autolayout.utils.AutoUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/28 0028.
 */
public class PlayHistoryActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_history)
    TextView tv_history;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.btn_del)
    SuperButton btnDel;
    @BindView(R.id.layout_bottom)
    RelativeLayout layoutBottom;
    @BindView(R.id.btn_all)
    Button btnAll;
    @BindView(R.id.frameLayout)
    FrameLayout frameLayout;

    HistoryAdapter mAdapter;
    int page = 1;
    boolean isEdit;
    private String showTime = "";


    @Override
    protected int getFragmentContainerId() {
        return R.id.frameLayout;
    }

    @Override
    protected void initView() {
//        tvTitle.setText("播放历史");
        tvRight.setText("编辑");

        mAdapter = new HistoryAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_10);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                HistoryInfo item = mAdapter.getItem(position);
                String strId = item.getVod_id();
                String playAnthology = item.getPlay_anthology();
                int playedTime = item.getPlayed_time();
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("id", strId);
                map.put("played_time", playedTime);
                if (ResourceUtils.isNumeric(playAnthology)) {
                    map.put("play_anthology", Integer.valueOf(playAnthology));
                }
                startActivity(MovieDetailActivity.class, map);
            }
        });

        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });

        layoutRefresh.autoRefresh();

    }

    private void getList() {
        Kalle.get(HttpUrl.PLAY_LOG)
                .param("page", page)
                .param("size", 10)
                .param("imei", PhoneIdUitls.getID(this))
                .perform(new NormalCallback<List<HistoryInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<HistoryInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        } else {
                            layoutRefresh.finishRefresh();
                            ToastUtils.show(response.failed());
                        }

                    }
                });
    }

    void initList(List<HistoryInfo> list) {
        if (list == null) {
            list = new ArrayList<>();
        }
        for (HistoryInfo info : list) {
            String time = ToolUtil.format(ToolUtil.date2TimeStamp(info.getUpdate_time()));
            if (TextUtils.isEmpty(showTime) || !showTime.equals(time)) {
                showTime = time;
                info.setTimeshow(showTime);
                info.setShow(true);
            } else {
                info.setShow(false);
            }

        }

        if (page == 1) {
            if (list.isEmpty()) {
                isEdit = false;
                tvRight.setText("编辑");
                mAdapter.edit(false);
                layoutBottom.setVisibility(View.GONE);
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            } else {
                mAdapter.setNewData(list);
            }
        } else {
            mAdapter.addData(list);
        }
        layoutRefresh.finishRefresh();
        layoutRefresh.finishLoadMore();
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        } else {
            layoutRefresh.setEnableLoadMore(true);
        }

    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tv_history.setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSize(50));
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSize(45));
        addFragment(SheetAllFrg.class, null);
    }

    @OnClick({R.id.iv_back, R.id.tv_right, R.id.btn_all, R.id.btn_del, R.id.tv_title, R.id.tv_history})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv_right:
                if ("编辑".equals(tvRight.getText().toString())) {
                    if (mAdapter != null && !mAdapter.getData().isEmpty()) {
                        tvRight.setText("取消");
                        isEdit = true;
                        mAdapter.edit(true);
                        layoutBottom.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (mAdapter != null && !mAdapter.getData().isEmpty()) {
                        tvRight.setText("编辑");
                        isEdit = false;
                        mAdapter.edit(false);
                        layoutBottom.setVisibility(View.GONE);
                    }

                }
                break;
            case R.id.btn_del:
                String ids = "";
                for (HistoryInfo info : mAdapter.getData()) {
                    if (info.isCheck()) {
                        ids = ids + "," + info.getId();
                    }
                }
                if (TextUtils.isEmpty(ids)) {
                    return;
                }
                cancel(ids.substring(1));
                break;
            case R.id.btn_all:
                for (HistoryInfo info : mAdapter.getData()) {
                    info.setCheck(true);
                }
                mAdapter.notifyDataSetChanged();
                break;
            case R.id.tv_history:
                frameLayout.setVisibility(View.GONE);
                tv_history.setTextColor(0xffffffff);
                tvTitle.setTextColor(0xaaffffff);
                tv_history.setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSize(50));
                tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSize(45));
                tvRight.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_title:
                frameLayout.setVisibility(View.VISIBLE);
                tvRight.setVisibility(View.GONE);
                tvTitle.setTextColor(0xffffffff);
                tv_history.setTextColor(0xaaffffff);
                tv_history.setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSize(45));
                tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSize(55));
                break;
        }
    }

    private void cancel(String ids) {
        Kalle.post(HttpUrl.PLAY_HISTORY_CANCEL)
                .tag(tag)
                .param("delete_ids", ids)
                .perform(new LoadingCallback<List<CollectInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<CollectInfo>, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("删除成功");
                            page = 1;
                            getList();
                            SPUtils.getInstance().put(SPContant.PLAY_HISTORY, true);
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_history;
    }

}
