package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.DownloadInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/8/7 0007.
 */
public class CacheAdapter extends BaseQuickAdapter<DownloadInfo, BaseViewHolder> {

    public CacheAdapter(@Nullable List<DownloadInfo> data) {
        super(R.layout.item_cache, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, DownloadInfo item) {
        helper.setText(R.id.tv_name, item.getTitle()).setGone(R.id.tv_state, false).setGone(R.id.pb, false);
        ImageView ivImg = helper.getView(R.id.iv_player);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getImg(), ivImg, R.drawable.pic_emptypage_failure);
    }

}
