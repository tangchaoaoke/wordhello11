package com.movie58.util;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;

import com.hss01248.dialog.StyleDialog;
import com.hss01248.dialog.interfaces.DialogListener;
import com.movie58.R;
import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.Rationale;
import com.yanzhenjie.permission.RequestExecutor;
import com.yanzhenjie.permission.runtime.Permission;

import java.util.List;

/**
 * 权限控制
 */

public class PermissionUtil {

    Context ctx;
    CallBack mCallBack = null;

    public static final String[] PHONE_STATE = new String[]{Permission.READ_PHONE_STATE};

    public PermissionUtil(Context ctx) {
        this.ctx = ctx;
    }


    public void showPermission(String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AndPermission.with(ctx)
                    .runtime()
                    .permission(permissions)
                    .rationale(new Rationale<List<String>>() {
                        @Override
                        public void showRationale(Context context, List<String> data, RequestExecutor executor) {
                            showRation(context, data, executor);
                        }
                    })
                    .onDenied(new Action<List<String>>() {
                        @Override
                        public void onAction(List<String> data) {
                            showSetting(ctx, data);
                        }
                    })
                    .onGranted(new Action<List<String>>() {//同意
                        @Override
                        public void onAction(List<String> permissions) {
                            if (mCallBack != null) {
                                mCallBack.onGranted();
                            }
                        }
                    }).start();
        } else {
            if (mCallBack != null) {
                mCallBack.onGranted();
            }
        }
    }

    public void showPermission(String[]... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AndPermission.with(ctx)
                    .runtime()
                    .permission(permissions)
                    .rationale(new Rationale<List<String>>() {
                        @Override
                        public void showRationale(Context context, List<String> data, RequestExecutor executor) {
                            showRation(context, data, executor);
                        }
                    })
                    .onDenied(new Action<List<String>>() {
                        @Override
                        public void onAction(List<String> data) {
                            showSetting(ctx, data);
                        }
                    })
                    .onGranted(new Action<List<String>>() {//同意
                        @Override
                        public void onAction(List<String> permissions) {
                            if (mCallBack != null) {
                                mCallBack.onGranted();
                            }
                        }
                    }).start();
        } else {
            if (mCallBack != null) {
                mCallBack.onGranted();
            }
        }
    }


    public void showRation(Context ctx, List<String> permissions, final RequestExecutor executor) {
        List<String> permissionNames = Permission.transformText(ctx, permissions);
        String message = TextUtils.join(",", permissionNames);
        String str = "为保证您正常使用应用，需获取您的" + message + "使用权限，请允许。";
        StyleDialog.buildIosAlert("请开启应用权限", str)
                .setCancelable(false, false)
                .setBtnText("去开启")
                .setBtnColor(R.color.color_base)
                .setListener(new DialogListener() {
                    @Override
                    public void onFirst() {
                        executor.execute();
                    }
                }).show();


    }

    /***
     * 用户勾选拒绝后在应用中开启设置；
     * @param ctx
     * @param permissions
     */
    public void showSetting(Context ctx, final List<String> permissions) {
        if (AndPermission.hasAlwaysDeniedPermission(ctx, permissions)) {
            List<String> permissionNames = Permission.transformText(ctx, permissions);
            String message = TextUtils.join(",", permissionNames);
            String str = "未取得您的" + message + "使用权限，应用无法正常使用。请前往应用权限设置打开权限。";
            StyleDialog.buildIosAlert(ctx, "请开启应用权限", str)
                    .setBtnText("去开启")
                    .setBtnColor(R.color.color_base)
                    .setListener(new DialogListener() {
                        @Override
                        public void onFirst() {
                            AndPermission.with(ctx)
                                    .runtime()
                                    .setting()
                                    .start(0);
                        }
                    }).show();
        }
    }

    public PermissionUtil setCallBack(CallBack callback) {
        mCallBack = callback;
        return this;
    }

    public interface CallBack {
        //权限获取成功了；
        void onGranted();

    }

}
