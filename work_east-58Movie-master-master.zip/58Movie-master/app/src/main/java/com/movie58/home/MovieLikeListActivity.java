package com.movie58.home;

import android.os.Bundle;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.movie58.R;
import com.movie58.adapter.MovieLikeAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.DetailLikeInfo;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/18 0018.
 */
public class MovieLikeListActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.tv_null)
    TextView tvNull;

    MovieLikeAdapter mAdapter;
    List<DetailLikeInfo> list = new ArrayList<>();

    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        list = (List<DetailLikeInfo>) b.getSerializable("list");
    }

    @Override
    protected void initView() {
        tvTitle.setText("猜你喜欢");

        mAdapter = new MovieLikeAdapter(list);
        mAdapter.bindToRecyclerView(rvList);
        rvList.setLayoutManager(new GridLayoutManager(getMActivity(),3));

        layoutRefresh.setEnableRefresh(false);
        layoutRefresh.setEnableLoadMore(false);



        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("id", mAdapter.getItem(position).getId());
                    startActivity(MovieDetailActivity.class, map);
//                }else{
//                    startActivity(LoginActivity.class);
//                }
            }
        });
    }

    @OnClick({R.id.iv_back})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_movie_like;
    }
}
