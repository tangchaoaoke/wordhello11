package com.movie58.task;

import android.widget.EditText;

import com.allen.library.SuperButton;
import com.movie58.R;
import com.movie58.base.BaseFragment;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/6/26 0026.
 */
public class ConvertAlipayFragment extends BaseFragment {

    @BindView(R.id.et_alipay)
    EditText etAlipay;
    @BindView(R.id.et_name)
    EditText etName;
    @BindView(R.id.btn_alipay)
    SuperButton btnAlipay;


    public static ConvertAlipayFragment newInstance() {
        return new ConvertAlipayFragment();
    }

    @Override
    protected void initView() {
        super.initView();
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_convert_alipay;
    }

}
