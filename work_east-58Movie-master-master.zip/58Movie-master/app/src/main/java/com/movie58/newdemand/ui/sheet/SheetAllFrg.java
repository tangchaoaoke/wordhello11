package com.movie58.newdemand.ui.sheet;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.newdemand.base.BaseFrg;
import com.movie58.newdemand.interfaces.Sheet;
import com.movie58.newdemand.utils.ImagesUtils;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.account.Account;
import com.zhy.autolayout.utils.AutoUtils;

import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

import static android.app.Activity.RESULT_OK;

public class SheetAllFrg extends BaseFrg implements SheetAddDialog.SheetAddDialogInterface {


    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.imgv_01)
    ImageView imgv01;
    @BindView(R.id.tv_add)
    TextView tvAdd;
    @BindView(R.id.linlay)
    LinearLayout linlay;
    Unbinder unbinder;
    @BindView(R.id.tv_my)
    TextView tvMy;
    @BindView(R.id.imgv_02)
    ImageView imgv_02;
    private GoldRecyclerAdapter adapter;
    private Sheet sheet;
    private ArrayList<Map<String, String>> list;

    @Override
    protected int getLayoutResource() {
        return R.layout.frg_sheet_all;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    protected void initView() {
        sheet = new Sheet();
        list = new ArrayList<>();
    }


    @Override
    public void requestDatas() {
        super.requestDatas();
    }

    public void request() {
        startProgressDialog();
        sheet.d3(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        startProgressDialog();
        sheet.d3(this);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new GoldRecyclerAdapter(getActivity());
        recyclerView.setAdapter(adapter);

        imgv_02.setImageResource(R.drawable.aic_more03);
        recyclerView.setVisibility(View.VISIBLE);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1314) {
                requestDatas();
//                homeFragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    private SheetAddDialog sheetAddDialog;

    @OnClick({R.id.tv_my, R.id.relay_02, R.id.tv_add, R.id.linlay, R.id.relay_01})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_my:
            case R.id.relay_01:
                if (recyclerView.getVisibility() == View.VISIBLE) {
                    recyclerView.setVisibility(View.GONE);
                    imgv_02.setImageResource(R.drawable.aic_more02);
                } else {
                    imgv_02.setImageResource(R.drawable.aic_more03);
                    recyclerView.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.relay_02:
                Bundle bundle = new Bundle();
                bundle.putString("data", data);
                startActivityForResult(EditSheetAty.class, bundle, 1314);
                break;
            case R.id.tv_add:
                if (!Account.getInstance().isLogined()) {
                    showShortToast("请先登录");
                    return;
                }
                if (sheetAddDialog == null) {
                    sheetAddDialog = new SheetAddDialog(getActivity());
                    Window window = sheetAddDialog.getWindow();
                    sheetAddDialog.setSheetAddDialogInterface(this);
                    window.setGravity(Gravity.BOTTOM);
                    sheetAddDialog.show();
                } else {
                    if (!sheetAddDialog.isShowing()) {
                        sheetAddDialog.show();
                    }
                }
                if (sheetAddDialog != null) {
                    sheetAddDialog.showSoftInput();
                }

                break;
            case R.id.linlay:
                break;
        }
    }

    @Override
    public void addSheet(String name) {
        if (TextUtils.isEmpty(name)) {
            return;
        }
        startProgressDialog();
        sheet.d2(name, this);
    }

    private String data;

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        stopProgressDialog();
        if (type.equals("createSheet")) {
            showShortToast("创建片单成功");
            request();
        }
        if (type.equals("sheetVodList")) {
            data = var2;
            list = JSONUtils.parseDataToMapList(var2);
            if (list == null) {
                list = new ArrayList<>();
            }
            if (list != null) {
                tvMy.setText("我创建的片单 ( " + list.size() + " )");
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
            }
        }
    }

    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_sheetall_frg, parent, false);
            return new fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {

            fGoldViewHolder holder1 = (fGoldViewHolder) holder;
            holder1.tvName.setText(list.get(position).get("sheet_name"));
            ArrayList<Map<String, String>> vod_list = JSONUtils.parseKeyAndValueToMapList(list.get(position).get("vod_list"));

            if (vod_list == null || vod_list.size() == 0) {
                holder1.tvNum.setText("0部");
            } else {
                holder1.tvNum.setText(vod_list.size() + "部");
                ImagesUtils.disImg2(getActivity(), vod_list.get(0).get("source_img"),
                        holder1.imgv, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);
            }
            holder.itemView.setOnClickListener(v -> {
                Bundle bundle = new Bundle();
                bundle.putString("sheet_name", list.get(position).get("sheet_name"));
                bundle.putString("vod_list", list.get(position).get("vod_list"));
                bundle.putString("sheet_id", list.get(position).get("id"));
                startActivity(SheetDetailsAty.class, bundle);
            });

        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {
            @BindView(R.id.imgv)
            ImageView imgv;
            @BindView(R.id.tv_name)
            TextView tvName;
            @BindView(R.id.tv_num)
            TextView tvNum;

            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }

}
