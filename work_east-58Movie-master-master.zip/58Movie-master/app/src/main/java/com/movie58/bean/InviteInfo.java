package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class InviteInfo {
    /**
     * invite_user_name : hTRIT4
     * invited_user_name : UYL021
     * create_time : 2019-05-25 23:11:58
     */

    private String invite_user_name;
    private String invited_user_name;
    private String create_time;

    public String getInvite_user_name() {
        return invite_user_name;
    }

    public void setInvite_user_name(String invite_user_name) {
        this.invite_user_name = invite_user_name;
    }

    public String getInvited_user_name() {
        return invited_user_name;
    }

    public void setInvited_user_name(String invited_user_name) {
        this.invited_user_name = invited_user_name;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }
}
