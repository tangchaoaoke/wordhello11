package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class FindHotInfo {


    /**
     * id : 1
     * project_name : 影史上的经典恐怖片究竟有多恐怖 不可不看的世界十大恐怖片推荐
     * project_desc : 恐怖片相信大家都看过很多，但是你知道哪些才是
     * project_banner : https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1350308544,2223607921&fm=26&gp=0.jpg
     * project_background : http://47.105.218.54/upload/d>
     * project_color : d>
     * create_time : 2019-05-18 22:16:52
     * update_time : 1558189012
     * params : a:1:{s:4:"list";a:1:{s:4:"$key";s:9:"暗黑者";}}
     * project_type :
     * project_tag :
     * project_cat : 1
     */

    private String id;
    private String project_name;
    private String project_desc;
    private String project_banner;
    private String project_background;
    private String project_color;
    private String create_time;
    private int update_time;
    private String params;
    private String project_type;
    private String project_tag;
    private int project_cat;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProject_name() {
        return project_name;
    }

    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    public String getProject_desc() {
        return project_desc;
    }

    public void setProject_desc(String project_desc) {
        this.project_desc = project_desc;
    }

    public String getProject_banner() {
        return project_banner;
    }

    public void setProject_banner(String project_banner) {
        this.project_banner = project_banner;
    }

    public String getProject_background() {
        return project_background;
    }

    public void setProject_background(String project_background) {
        this.project_background = project_background;
    }

    public String getProject_color() {
        return project_color;
    }

    public void setProject_color(String project_color) {
        this.project_color = project_color;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getProject_type() {
        return project_type;
    }

    public void setProject_type(String project_type) {
        this.project_type = project_type;
    }

    public String getProject_tag() {
        return project_tag;
    }

    public void setProject_tag(String project_tag) {
        this.project_tag = project_tag;
    }

    public int getProject_cat() {
        return project_cat;
    }

    public void setProject_cat(int project_cat) {
        this.project_cat = project_cat;
    }
}
