package com.movie58.newdemand.ui.sheet;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.movie58.newdemand.interfaces.Sheet;
import com.movie58.newdemand.utils.ImagesUtils;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.newdemand.view.MySmoothRefreshLayout;
import com.zhy.autolayout.utils.AutoUtils;

import org.xutils.http.RequestParams;

import java.util.ArrayList;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SheetFindAty extends BaseAty {


    @BindView(R.id.layout_tab)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp)
    ViewPager vp;
    @BindView(R.id.top)
    RelativeLayout top;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.tv_num)
    TextView tv_num;
    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    @BindView(R.id.refreshLayout)
    MySmoothRefreshLayout refreshLayout;
    @BindView(R.id.et_search)
    EditText et_search;
    @BindView(R.id.relay_tab)
    RelativeLayout relay_tab;

    private String sheet_id;
    private Sheet sheet;
    private ArrayList<Map<String, String>> list;
    private ArrayList<SheetFindFrg> list_frg;
    private ArrayList<String> list_cb;
    private GoldRecyclerAdapter adapter;

    @Override
    public int getLayoutId() {
        return R.layout.aty_sheet_find;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        list_frg = new ArrayList<>();
        list_search = new ArrayList<>();
        list_cb = new ArrayList<>();
        list_check = new ArrayList<>();
        sheet_id = getIntent().getStringExtra("sheet_id");
        sheet = new Sheet();


    }

    @Override
    public void requestData() {
        startProgressDialog();
        sheet.d(this);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        initTopview(top, relay_top);
        tv_num.setText(list_cb.size() + "");
        mInputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        et_search.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                //关闭软键盘
                if (TextUtils.isEmpty(et_search.getText().toString())) {
                    return true;
                }
                hideSoftInput();

                startProgressDialog();
                sheet.e3(sheet_id, et_search.getText().toString(), this);
                return true;
            }
            return false;
        });

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (TextUtils.isEmpty(et_search.getText().toString())) {
                    vp.setVisibility(View.VISIBLE);
                    relay_tab.setVisibility(View.VISIBLE);
                    refreshLayout.setVisibility(View.GONE);
                    list_check.clear();
                }
            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        adapter = new GoldRecyclerAdapter(this);
        recyclerview.setAdapter(adapter);
        refreshLayout.setEnableRefresh(false);
        refreshLayout.setEnableLoadmore(false);
        refreshLayout.loadMoreReturn();


    }

    private InputMethodManager mInputManager;//软键盘管理类


    /**
     * 隐藏软件盘
     */
    private void hideSoftInput() {
        mInputManager.hideSoftInputFromWindow(et_search.getWindowToken(), 0);
    }

    public void addData(String id, String type) {
        if (TextUtils.isEmpty(id)) {
            return;
        }
        if (type.equals("0")) {
            if (list_cb.contains(id)) {
                return;
            }
            list_cb.add(id);
        } else {
            if (!list_cb.contains(id)) {
                return;
            }
            list_cb.remove(id);
        }
        tv_num.setText(list_cb.size() + "");
    }

    private ArrayList<Map<String, String>> list_search;

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        stopProgressDialog();
        if (type.equals("navSheet")) {
            list = JSONUtils.parseDataToMapList(var2);
            for (int i = 0; i < list.size(); i++) {
                list_frg.add(SheetFindFrg.newInstance(list.get(i).get("id"), sheet_id));
            }
            vp.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));
            layoutTab.setViewPager(vp);
            vp.setOffscreenPageLimit(list_frg.size());
        }

        if (type.equals("addVodSheet")) {
            setResult(RESULT_OK);
            finish();
        }

        if (type.equals("search")) {
            ArrayList<Map<String, String>> list_s = JSONUtils.parseDataToMapList(var2);
            if (list_s == null || list_s.size() == 0) {
                return;
            }
            list_search.clear();
            list_search.addAll(list_s);

            refreshLayout.setVisibility(View.VISIBLE);
            vp.setVisibility(View.GONE);
            relay_tab.setVisibility(View.GONE);

            list_check.clear();
            for (int i = 0; i < list_search.size(); i++) {
                list_check.add("0");
            }
            if (adapter == null) {
                adapter = new GoldRecyclerAdapter(this);
                recyclerview.setAdapter(adapter);
            } else {
                adapter.notifyDataSetChanged();
            }
        }
    }

    @OnClick({R.id.iv_back, R.id.imgv_01, R.id.et_search, R.id.iv_del, R.id.top, R.id.relay_top,
            R.id.layout_tab, R.id.tv_ok})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.imgv_01:
                break;
            case R.id.et_search:
                break;
            case R.id.iv_del:
                break;
            case R.id.top:
                break;
            case R.id.relay_top:
                break;
            case R.id.layout_tab:
                break;
            case R.id.tv_ok:
                if (list_cb.size() == 0) {
                    return;
                }

                StringBuffer buffer = new StringBuffer();
                for (int i = 0; i < list_cb.size(); i++) {
                    buffer.append(list_cb.get(i));
                    if (i != list_cb.size() - 1) {
                        buffer.append(",");
                    }
                }
                startProgressDialog();
                sheet.d5(sheet_id, buffer.toString(), this);
                break;
        }
    }

    private class MyPagerAdapter extends FragmentPagerAdapter {
        FragmentManager mFragmentManager;

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
            mFragmentManager = fm;
        }

        @Override
        public int getCount() {
            return list_frg.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return list.get(position).get("cat_name");
        }

        @Override
        public Fragment getItem(int position) {
            return list_frg.get(position);
        }

    }


    private ArrayList<String> list_check;

    public class GoldRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        private LayoutInflater inflater;

        public GoldRecyclerAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            view = inflater.inflate(R.layout.item_sheet_find_frg, parent, false);
            return new GoldRecyclerAdapter.fGoldViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
            GoldRecyclerAdapter.fGoldViewHolder holder1 = (GoldRecyclerAdapter.fGoldViewHolder) holder;
//            ImagesUtils.disImg(getActivity(), list.get(position).get("source_img"), holder1.iv_player);
            ImagesUtils.disImg2(SheetFindAty.this, list_search.get(position).get("source_img"),
                    holder1.iv_player, R.drawable.pic_emptypage_failure, R.drawable.pic_emptypage_failure);

            holder1.tv_time.setText(list_search.get(position).get("up_right_text"));
            holder1.tv_name.setText(list_search.get(position).get("source_name"));
            holder1.tv_details.setText(list_search.get(position).get("description"));
            String is_sheet_vod = list_search.get(position).get("is_sheet_vod");
            if (is_sheet_vod.equals("1")) {
                holder1.tv_isadd.setText("已在片单");
                holder1.tv_isadd.setTextColor(0xaa000000);
            } else {

                if (list_check.get(position).equals("1")) {
                    holder1.tv_isadd.setText("√ 片单");
                    holder1.tv_isadd.setTextColor(0xaa000000);
                } else {
                    holder1.tv_isadd.setText("+片单");
                    holder1.tv_isadd.setTextColor(0xff673AB7);
                }
            }
            holder1.tv_isadd.setOnClickListener(v -> {
                if (is_sheet_vod.equals("1")) {
                    return;
                }
                addData(list_search.get(position).get("id"), list_check.get(position));
                if (list_check.get(position).equals("1")) {
                    list_check.set(position, "0");
                } else {
                    list_check.set(position, "1");
                }
                notifyDataSetChanged();
            });
            if (position == list_search.size() - 1) {
                holder1.v_01.setVisibility(View.VISIBLE);
            } else {
                holder1.v_01.setVisibility(View.GONE);
            }

        }

        @Override
        public int getItemCount() {
            return list_search.size();
        }

        class fGoldViewHolder extends RecyclerView.ViewHolder {

            @BindView(R.id.iv_player)
            ImageView iv_player;
            @BindView(R.id.tv_time)
            TextView tv_time;
            @BindView(R.id.tv_name)
            TextView tv_name;
            @BindView(R.id.tv_details)
            TextView tv_details;
            @BindView(R.id.tv_isadd)
            TextView tv_isadd;
            @BindView(R.id.v_01)
            View v_01;

            public fGoldViewHolder(View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);
                AutoUtils.autoSize(itemView);
            }
        }
    }
}
