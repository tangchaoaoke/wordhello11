package com.movie58.home;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.lxj.xpopup.core.BottomPopupView;
import com.lxj.xpopup.util.XPopupUtils;
import com.movie58.R;
import com.movie58.bean.DetailInfo;

/**
 * Created by yangxing on 2019/5/20 0020.
 */
public class MovieIntroDialog extends BottomPopupView {

    TextView tvName;
    ImageView ivClose;
    TextView tvCount;
    TextView tvFen;
    TextView tvType;
    TextView tvDaoyan;
    TextView tvYanyuan;
    TextView tvJianjie;

    DetailInfo detailInfo;
    String strType;

    public MovieIntroDialog(@NonNull Context context, DetailInfo detailInfo, String type) {
        super(context);
        this.detailInfo = detailInfo;
        strType = type;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_detail;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tvName = findViewById(R.id.tv_name);
        ivClose = findViewById(R.id.iv_close);
        tvCount = findViewById(R.id.tv_count);
        tvFen = findViewById(R.id.tv_fen);
        tvType = findViewById(R.id.tv_type);
        tvDaoyan = findViewById(R.id.tv_daoyan);
        tvYanyuan =findViewById(R.id.tv_yanyuan);
        tvJianjie = findViewById(R.id.tv_jianjie);

        tvCount.setText("播放："+ detailInfo.getPlay_num());
        tvName.setText(detailInfo.getSource_name());
        tvFen.setText(detailInfo.getPingfen());
        tvYanyuan.setText(detailInfo.getLead_role());
        tvDaoyan.setText("导演："+detailInfo.getDirector());
        tvType.setText(strType);
        tvJianjie.setText(detailInfo.getDetail_desc());

        ivClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }


    @Override
    protected int getMaxHeight() {
        return (int) (XPopupUtils.getWindowHeight(getContext())*.60f);
    }
}
