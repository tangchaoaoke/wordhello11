package com.movie58.my;

import android.support.annotation.Nullable;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.cbman.roundimageview.RoundImageView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.LevelBean;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.view.GridSpacingItemDecoration;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class LevelActivity extends BaseUseActivity {

    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.top)
    LinearLayout top;
    @BindView(R.id.iv_head)
    RoundImageView ivHead;
    @BindView(R.id.tv_level)
    SuperButton tvLevel;
    @BindView(R.id.tv_name)
    TextView tvName;
    @BindView(R.id.tv_now)
    TextView tvNow;
    @BindView(R.id.tv_next)
    TextView tvNext;
    @BindView(R.id.tv_middle)
    TextView tvMiddle;
    @BindView(R.id.pb)
    ContentLoadingProgressBar pb;
    @BindView(R.id.rv)
    RecyclerView rvFrom;
    @BindView(R.id.rv1)
    RecyclerView rvLevel;

    LevelBean levelBean;

    @Override
    protected void initView() {
        tvTitle.setText("我的等级");
        tvRight.setText("成长记录");
    }

    @Override
    protected void initData() {
        getDetail();
    }

    private void getDetail() {
        Kalle.get(HttpUrl.LEVEL_DETAIL)
                .perform(new LoadingCallback<LevelBean>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<LevelBean, String> response) {
                        if (response.isSucceed()) {
                            levelBean = response.succeed();
                            initDetail();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initDetail(){
        if (levelBean == null) {
            return;
        }
        if (levelBean.getUser_info() == null) {
            return;
        }
        if (TextUtils.isEmpty(levelBean.getUser_info().getAvatar())) {
            ivHead.setImageResource(R.drawable.avatar);
        }else{
            PicassoUtils.LoadImageWithDetfult(getMActivity(), levelBean.getUser_info().getAvatar(), ivHead, R.drawable.avatar);
        }
        tvName.setText(Account.getInstance().getUserName());
        tvLevel.setText(levelBean.getUser_info().getLevel_name());
        tvNow.setText(levelBean.getUser_info().getLevel_name());
        tvNext.setText(levelBean.getUser_info().getNext_level_name());
        tvMiddle.setText("距离下一等级还差" + levelBean.getUser_info().getUpgrade_exp() +"经验");
        pb.setMax(levelBean.getUser_info().getMax_experience() - levelBean.getUser_info().getMin_experience());
//        pb.setMin(levelBean.getUser_info().getMin_experience());
        pb.setProgress(levelBean.getUser_info().getExperience() - levelBean.getUser_info().getMin_experience());

        FromAdapter mAdapter = new FromAdapter(levelBean.getGrant_rule());
        rvFrom.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvFrom.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.line)
                .margin(getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_15), 0)
                .build());
        mAdapter.bindToRecyclerView(rvFrom);

        LevelAdapter adapter = new LevelAdapter(levelBean.getLevel_list());
        rvLevel.setLayoutManager(new GridLayoutManager(getMActivity(),5));
        rvLevel.addItemDecoration(new GridSpacingItemDecoration(5, getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_2), getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_2)));
        adapter.bindToRecyclerView(rvLevel);
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void Click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv_right:
                startActivity(LevelUpActivity.class);
                break;
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_level;
    }

    private class FromAdapter extends BaseQuickAdapter<LevelBean.GrantRuleBean, BaseViewHolder>{

        public FromAdapter(@Nullable List<LevelBean.GrantRuleBean> data) {
            super(R.layout.item_level_from, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, LevelBean.GrantRuleBean item) {
            helper.setText(R.id.tv, item.getRule_name() + ": 获得" + item.getExperience_num() + "经验");
        }
    }

    private class LevelAdapter extends BaseQuickAdapter<LevelBean.LevelListBean, BaseViewHolder>{

        public LevelAdapter(@Nullable List<LevelBean.LevelListBean> data) {
            super(R.layout.item_level, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, LevelBean.LevelListBean item) {
            helper.setText(R.id.tv_1, item.getLevel_name())
                    .setText(R.id.tv_2, item.getMin_experience() + "");
        }
    }
}
