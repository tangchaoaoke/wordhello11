package com.movie58.my;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/7 0007.
 */
public class NickFragment extends BaseFragment {

    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.et)
    EditText et;


    public static NickFragment newInstance() {
        return new NickFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("昵称");
        tvRight.setText("确定");
        et.setText(Account.getInstance().getUserName());
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void click(View v){
        hideSoftInput();
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.tv_right:
                String text = et.getText().toString().trim();
                if (TextUtils.isEmpty(text)) {
                    ToastUtils.show("昵称不能为空");
                    return;
                }
                if (!ToolUtil.isNickName(text)) {
                    ToastUtils.show("昵称最多8个汉字字母数字");
                    return;
                }
                changeName(text);

                break;
        }
    }

    private void changeName(String name){
        Kalle.get(HttpUrl.CHANGE_USER)
                .tag(tag)
                .param("user_nickname", name)
                .param("user_id", Account.getInstance().getUserId())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("昵称修改成功！");
                            Account.getInstance().setUserName(name);
                            EventBus.getDefault().post(new Event(Event.CODE_04_SCHOOL_TIME_FILE));
                            pop();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_nick;
    }

}
