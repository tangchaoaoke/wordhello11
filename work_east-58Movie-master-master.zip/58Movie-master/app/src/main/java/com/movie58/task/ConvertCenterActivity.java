package com.movie58.task;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.flyco.tablayout.SegmentTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.interfaces.Other;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.LimitInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.yanzhenjie.kalle.FormBody;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;
import org.xutils.http.RequestParams;

import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/6/26 0026.
 */
public class ConvertCenterActivity extends BaseUseActivity {

    @BindView(R.id.layout_tab2)
    SegmentTabLayout layoutTab;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.layout_0)
    RelativeLayout layout0;
    @BindView(R.id.layout_1)
    RelativeLayout layout1;
    @BindView(R.id.layout_2)
    RelativeLayout layout2;
    @BindView(R.id.layout_3)
    RelativeLayout layout3;
    @BindView(R.id.layout_4)
    RelativeLayout layout4;
    @BindView(R.id.layout_5)
    RelativeLayout layout5;
    @BindView(R.id.layout_6)
    RelativeLayout layout6;
    @BindView(R.id.tv_gold)
    TextView tvGold;
    @BindView(R.id.et_gold)
    EditText etGold;
    @BindView(R.id.et_bank)
    EditText etBank;
    @BindView(R.id.et_no)
    EditText etNo;
    @BindView(R.id.et_name)
    EditText etName;
    @BindView(R.id.et_address)
    EditText etAddress;
    @BindView(R.id.et_alipay)
    EditText etAlipay;
    @BindView(R.id.et_name1)
    EditText etName1;
    @BindView(R.id.btn_bank)
    SuperButton btnBank;
    @BindView(R.id.tv_01)
    TextView tv_01;

    private String[] mTitles = new String[]{"银行卡", "支付宝"};

    boolean isBank = true;
    LimitInfo limitInfo;
    private Other other;

    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        limitInfo = (LimitInfo) b.getSerializable("limit");
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        other = new Other();
        other.d(this);
    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        if (type.equals("getAppInfo")) {
            Map<String, String> map = JSONUtils.parseDataToMap(var2);
            String special_text = map.get("special_text");
            if (!TextUtils.isEmpty(special_text)) {
                tv_01.setText(special_text);
                tv_01.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void initView() {
        tvTitle.setText("兑换中心");
        tvRight.setText("兑换记录");
        int f = (int) (1 / limitInfo.getScale());
        tvGold.setText("当前兑换比例1：" + f + "（" + f + "金币可兑换1RMB）");
        layoutTab.setTabData(mTitles);
        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                if (position == 0) {
                    isBank = true;
                    layout1.setVisibility(View.VISIBLE);
                    layout2.setVisibility(View.VISIBLE);
                    layout3.setVisibility(View.VISIBLE);
                    layout4.setVisibility(View.VISIBLE);
                    layout5.setVisibility(View.GONE);
                    layout6.setVisibility(View.GONE);
                } else {
                    isBank = false;
                    layout1.setVisibility(View.GONE);
                    layout2.setVisibility(View.GONE);
                    layout3.setVisibility(View.GONE);
                    layout4.setVisibility(View.GONE);
                    layout5.setVisibility(View.VISIBLE);
                    layout6.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onTabReselect(int position) {
            }
        });

    }

    @OnClick({R.id.iv_back, R.id.tv_right, R.id.btn_bank})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv_right:
                startActivity(ConvertRecordActivity.class);
                break;
            case R.id.btn_bank:
                submit();
                break;
        }
    }

    private void submit() {
        String bankName = "", strNo = "", strName = "", address = "";
        String gold = etGold.getText().toString().trim();
        if (TextUtils.isEmpty(gold)) {
            ToastUtils.show("请输入需要兑换的金币数量");
            return;
        }
        int i = Integer.parseInt(gold);
        if (limitInfo.getMin_gold() > i) {
            ToastUtils.show("兑换的金币数量不能少于" + limitInfo.getMin_gold());
            return;
        }
        if (isBank) {
            bankName = etBank.getText().toString().trim();
            if (TextUtils.isEmpty(bankName)) {
                ToastUtils.show("开户银行不能为空");
                return;
            }
            strNo = etNo.getText().toString().trim();
            if (TextUtils.isEmpty(strNo)) {
                ToastUtils.show("银行卡号不能为空");
                return;
            }
            strName = etName.getText().toString().trim();
            if (TextUtils.isEmpty(strName)) {
                ToastUtils.show("持卡人姓名不能为空");
                return;
            }
            address = etAddress.getText().toString().trim();
            if (TextUtils.isEmpty(address)) {
                ToastUtils.show("开户行地址不能为空");
                return;
            }
        } else {
            strNo = etAlipay.getText().toString().trim();
            if (TextUtils.isEmpty(strNo)) {
                ToastUtils.show("支付宝账号不能为空");
                return;
            }
            strName = etName1.getText().toString().trim();
            if (TextUtils.isEmpty(strName)) {
                ToastUtils.show("真实姓名不能为空");
                return;
            }
        }

        FormBody.Builder builder = FormBody.newBuilder();
        if (isBank) {
            builder.param("cash_type", 0);
            builder.param("bank_name", bankName);
            builder.param("account_no", strNo);
            builder.param("account_name", strName);
            builder.param("bank_address", address);
        } else {
            builder.param("cash_type", 1);
            builder.param("account_no", strNo);
            builder.param("account_name", strName);
        }
        builder.param("gold_num", gold);

        Kalle.post(HttpUrl.GOLD_DUIHUAN)
                .tag(tag)
                .body(builder.build())

                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("兑换成功");
                            finish();
                            EventBus.getDefault().post(new Event(Event.CODE_18_WORDLIST_REFRESH));
                        } else {
                            ToastUtils.show(response.succeed());
                        }
                    }
                });
    }


    @Override
    protected int getLayout() {
        return R.layout.activity_convert_center;
    }

}
