package com.movie58.account;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.movie58.R;
import com.movie58.my.ChangePwdFragment;
import com.movie58.newdemand.interfaces.Lar;
import com.movie58.newdemand.utils.PhoneIdUitls;
import com.movie58.base.BaseFragment;
import com.movie58.bean.LoginInfo;
import com.movie58.bean.UserInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.MD5Util;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/24 0024.
 */
public class LoginFragment extends BaseFragment {

    @BindView(R.id.et_phone)
    EditText etPhone;
    @BindView(R.id.iv_phone)
    ImageView ivPhone;
    @BindView(R.id.tv_error)
    TextView tvError;
    @BindView(R.id.et_pwd)
    EditText etPwd;
    @BindView(R.id.iv_pwd)
    ImageView ivPwd;
    @BindView(R.id.tv_error1)
    TextView tvError1;
    @BindView(R.id.iv_yan)
    ImageView iv_yan;

    String strPhone, strPwd;


    public static LoginFragment newInstance() {
        return new LoginFragment();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private boolean isOpenEye = false;

    @Override
    protected void initView() {
        strPhone = SPUtils.getInstance().getString(SPContant.PHONE);
        if (!TextUtils.isEmpty(strPhone)) {
            etPhone.setText(strPhone);
            etPhone.setSelection(strPhone.length());
        }
        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s.toString().trim())) {
                    ivPhone.setVisibility(View.GONE);
                } else {
                    ivPhone.setVisibility(View.VISIBLE);
                    tvError.setVisibility(View.INVISIBLE);
                }
            }
        });

        etPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s.toString().trim())) {
                    ivPwd.setVisibility(View.GONE);
                    iv_yan.setVisibility(View.GONE);
                } else {
                    ivPwd.setVisibility(View.VISIBLE);
                    iv_yan.setVisibility(View.VISIBLE);
                    tvError1.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    @OnClick({R.id.iv_phone, R.id.iv_pwd, R.id.btn_login, R.id.iv_yan, R.id.tv_forget})
    void click(View v) {
        switch (v.getId()) {
            case R.id.tv_forget:
                startActivity(ForgetPassAty.class);
                break;
            case R.id.iv_yan:
                if (!isOpenEye) {
                    iv_yan.setImageResource(R.drawable.aic_18);
//                    etPwd.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    //可见
                    etPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    etPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
//                    etPwd.setInputType(InputType.TYPE_CLASS_TEXT);
                    iv_yan.setImageResource(R.drawable.aic_19);
                }
                isOpenEye = !isOpenEye;
                etPwd.setSelection(etPwd.getText().length());
                break;
            case R.id.iv_phone:
                etPhone.setText("");
                break;
            case R.id.iv_pwd:
                etPwd.setText("");
                break;
            case R.id.btn_login:
                strPhone = etPhone.getText().toString().trim();
                if (!ToolUtil.isMobileNum(strPhone)) {
                    tvError.setText("请输入正确的手机号");
                    tvError.setVisibility(View.VISIBLE);
                    return;
                }

                strPwd = etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(strPwd)) {
                    tvError1.setText("请输入密码");
                    tvError1.setVisibility(View.VISIBLE);
                    return;
                }
                if (strPwd.length() < 6 || strPwd.length() > 12) {
                    tvError1.setText("请输入6～12位数字和字母密码");
                    tvError1.setVisibility(View.VISIBLE);
                    return;
                }
                login();
                break;
        }
    }

    private void login() {
        Kalle.post(HttpUrl.LOGIN)
                .tag(tag)
                .param("user_name", strPhone)
                .param("device_type", "android")
                .param("is_verify", 0)
                .param("password", MD5Util.GetMD5Code(strPwd))
                .perform(new LoadingCallback<LoginInfo>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<LoginInfo, String> response) {
                        if (response.isSucceed()) {
                            com.hjq.toast.ToastUtils.show("登录成功!");
                            UserInfo info = response.succeed().getUser();
                            Account.getInstance().setUserTel(strPhone)
                                    .setToken(response.succeed().getToken())
                                    .setUserId(info.getId())
                                    .setUserName(info.getUser_nickname())
                                    .setSex(info.getSex())
                                    .setInviteCode(info.getUser_login())
                                    .setLevel(info.getLevel_name())
                                    .setAvatar(info.getAvatar())
                                    .setGold(info.getCoin())
                                    .setMobile(info.getMobile());

                            Kalle.getConfig().getHeaders().set("XX-Token", Account.getInstance().getToken());
//                            EventBus.getDefault().post(new Event(Event.CODE_48_LOGIN_IN));
                            getMActivity().finish();
                            relationId();
                        } else {
                            ToastUtils.showShort(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_login;
    }

    private Lar lar;

    private void relationId() {
        if (lar == null) {
            lar = new Lar();
        }
//        String im = PhoneUtils.getIMEI();
//        if (TextUtils.isEmpty(im)) {
//            im = PhoneIdUitls.getID(getActivity());
//            ToastUitl.showShort(getActivity(), "pp");
//        }else{
//            ToastUitl.showShort(getActivity(), im);
//        }
        lar.d(PhoneIdUitls.getID(getActivity()), this);
    }

}
