package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class ConvertListInfo {
    /**
     * id : 3
     * rule_name : 蓝光画质
     * rule_desc : 获得蓝光画质一个月
     * gold_num : 100
     * top_limit : 1
     * rule_code : blue_ray
     * rule_img : http://47.105.218.54/upload/
     * valid_day : 30
     * create_time : 2019-05-27 15:33:07
     * update_time : 1558673674
     * surplus_num : -1
     * sort : 0
     */

    private int id;
    private String rule_name;
    private String rule_desc;
    private int gold_num;
    private int top_limit;
    private String rule_code;
    private String rule_img;
    private int valid_day;
    private String create_time;
    private int update_time;
    private int surplus_num;
    private int sort;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRule_name() {
        return rule_name;
    }

    public void setRule_name(String rule_name) {
        this.rule_name = rule_name;
    }

    public String getRule_desc() {
        return rule_desc;
    }

    public void setRule_desc(String rule_desc) {
        this.rule_desc = rule_desc;
    }

    public int getGold_num() {
        return gold_num;
    }

    public void setGold_num(int gold_num) {
        this.gold_num = gold_num;
    }

    public int getTop_limit() {
        return top_limit;
    }

    public void setTop_limit(int top_limit) {
        this.top_limit = top_limit;
    }

    public String getRule_code() {
        return rule_code;
    }

    public void setRule_code(String rule_code) {
        this.rule_code = rule_code;
    }

    public String getRule_img() {
        return rule_img;
    }

    public void setRule_img(String rule_img) {
        this.rule_img = rule_img;
    }

    public int getValid_day() {
        return valid_day;
    }

    public void setValid_day(int valid_day) {
        this.valid_day = valid_day;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public int getSurplus_num() {
        return surplus_num;
    }

    public void setSurplus_num(int surplus_num) {
        this.surplus_num = surplus_num;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }
}
