package com.movie58.my;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.blankj.utilcode.util.SPUtils;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/14 0014.
 */
public class ChangePhoneFragment2 extends BaseFragment {
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_phone)
    TextView tvPhone;
    @BindView(R.id.et_code)
    EditText etCode;
    @BindView(R.id.btn_verify)
    SuperButton btnVerify;
    @BindView(R.id.btn_reset)
    SuperButton btnReset;

    String strPhone, strCode;

    public static ChangePhoneFragment2 newInstance(String phone) {
        ChangePhoneFragment2 fragment = new ChangePhoneFragment2();
        Bundle b = new Bundle();
        b.putString("phone", phone);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        strPhone = b.getString("phone");
    }

    @Override
    protected void initView() {
        tvTitle.setText("更换手机号");
        tvPhone.setText(ToolUtil.getPhone(strPhone));
    }

    @OnClick({R.id.iv_back, R.id.btn_verify, R.id.btn_reset})
    void click(View v){
        hideSoftInput();
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.btn_verify:
                getCode(SPUtils.getInstance().getString(SPContant.PHONE));
                break;
            case R.id.btn_reset:
                strCode  = etCode.getText().toString().trim();
                if (TextUtils.isEmpty(strCode)) {
                    ToastUtils.show("请输入验证码");
                    return;
                }
               changePhone();
                break;
        }
    }

    private void getCode(String phone){
        Kalle.get(HttpUrl.VERIFY_CODE)
                .tag(tag)
                .param("user_mobile", phone)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToolUtil.countDown(btnVerify, 60000, 1000, "获取验证码");
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void changePhone(){
        Kalle.get(HttpUrl.CHANGE_USER)
                .tag(tag)
                .param("user_new_mobile", strPhone)
                .param("user_id", Account.getInstance().getUserId())
                .param("verification_code", strCode)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("手机号码修改成功！");
                            popTo(SafeCenterFragment.class, false);
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_change_phone1;
    }


}
