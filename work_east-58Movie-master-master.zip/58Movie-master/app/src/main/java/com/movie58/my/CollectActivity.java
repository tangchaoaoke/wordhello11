package com.movie58.my;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.HomeTab;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/6 0006.
 */
public class CollectActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvEdit;
    @BindView(R.id.layout_tab)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp)
    ViewPager vp;

    private String[] mTitles ;
    List<HomeTab> listTab = new ArrayList<>();


    private int selPos;

    @Override
    protected void initView() {
        tvTitle.setText("我的收藏");
        tvEdit.setText("编辑");

        getTab();

        vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                selPos = i;
                tvEdit.setText("编辑");
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                selPos = position;
                tvEdit.setText("编辑");
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void click(View v){
        switch (v.getId()){
            case  R.id.iv_back:
                finish();
                break;
            case R.id.tv_right:
                if (listTab == null || listTab.isEmpty()) {
                    return;
                }
                if ("编辑".equals(tvEdit.getText())) {
                    EventBus.getDefault().post(new Event(Event.CODE_02_SCHOOL_REVIEW).setObj1(listTab.get(selPos).getId()).setObj2(true));
                }else{
                    tvEdit.setText("编辑");
                    EventBus.getDefault().post(new Event(Event.CODE_02_SCHOOL_REVIEW).setObj1(listTab.get(selPos).getId()).setObj2(false));
                }
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_03_SCHOOL_REVIEW_BTN:
                tvEdit.setText("取消");
                break;
        }
    }

    private void getTab(){
        Kalle.post(HttpUrl.HOME_TAB)
                .tag(tag)
                .perform(new NormalCallback<List<HomeTab>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<HomeTab>, String> response) {
                        if (response.isSucceed()) {
                            List<HomeTab> list = response.succeed();
                            if (list != null && !list.isEmpty()) {
                                listTab.clear();
                                for (HomeTab tab : list){
                                    if (!"推荐".equals(tab.getCat_name())) {
                                        listTab.add(tab);
                                    }
                                }
                                mTitles = new String[listTab.size()];
                                ArrayList<Fragment> fragments = new ArrayList<>();
                                for(int i = 0; i< listTab.size(); i++){
                                    mTitles[i] = listTab.get(i).getCat_name();
                                    fragments.add(CollectFragment.newInstance(listTab.get(i).getId()));
                                }
                                layoutTab.setViewPager(vp, mTitles, CollectActivity.this, fragments);
                            }
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_collect;
    }

}
