package com.movie58.base;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.util.ArrayMap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.utils.DisplayUtil;
import com.movie58.event.Event;
import com.movie58.lifecycle.FragmentLifecycleable;
import com.movie58.util.ToolUtil;
import com.trello.rxlifecycle2.android.FragmentEvent;
import com.yanzhenjie.kalle.Kalle;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;

import java.io.Serializable;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.Unbinder;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.Subject;
import me.yokeyword.fragmentation.SupportFragment;

/**
 * Created by yangxing on 2017/6/16 0016.
 */

public abstract class BaseFragment extends SupportFragment implements FragmentLifecycleable , ApiListener {

    private final BehaviorSubject<FragmentEvent> mLifecycleSubject = BehaviorSubject.create();
    Unbinder unbinder;
    protected final String tag = getClass().getSimpleName();

    @Override
    public void onAttach(android.app.Activity activity) {
        super.onAttach(activity);
        mLifecycleSubject.onNext(FragmentEvent.ATTACH);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLifecycleSubject.onNext(FragmentEvent.CREATE);
        EventBus.getDefault().register(this);
        getIntentExtra();
    }


    public void initTopview(RelativeLayout relay, RelativeLayout relay_top,int h) {
        int StatusBarHeight = DisplayUtil.getStateBar(getActivity());
        if (StatusBarHeight <= 0) {
            StatusBarHeight = (int) DisplayUtil.dip2px(getActivity(), 20);
        }
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) relay.getLayoutParams();
        lp.height =  h;
        lp.topMargin = StatusBarHeight;
        relay.setLayoutParams(lp);

        LinearLayout.LayoutParams lp2 = (LinearLayout.LayoutParams) relay_top.getLayoutParams();
        lp2.height =  h+StatusBarHeight;
        relay_top.setLayoutParams(lp2);

    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(getLayout(), container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onCancelled(Callback.CancelledException var1) {


    }

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {

    }

    @Override
    public void onError(int var1, RequestParams var2) {


    }

    @Override
    public void onExceptionType(Throwable var1, RequestParams params, String type) {

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initView();
    }

    @Override
    public void onEnterAnimationEnd(Bundle savedInstanceState) {
        super.onEnterAnimationEnd(savedInstanceState);
        initData();
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mLifecycleSubject.onNext(FragmentEvent.CREATE_VIEW);
    }

    @Override
    public void onStart() {
        super.onStart();
        mLifecycleSubject.onNext(FragmentEvent.START);
    }

    @Override
    public void onResume() {
        super.onResume();
        mLifecycleSubject.onNext(FragmentEvent.RESUME);
    }

    @Override
    public void onPause() {
        mLifecycleSubject.onNext(FragmentEvent.PAUSE);
        super.onPause();
    }

    @Override
    public void onStop() {
        mLifecycleSubject.onNext(FragmentEvent.STOP);
        super.onStop();
    }


    @Override
    public void onDestroyView() {
        mLifecycleSubject.onNext(FragmentEvent.DESTROY_VIEW);
        super.onDestroyView();
        getMActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Kalle.cancel(tag);
            }
        });
        unbinder.unbind();
    }

    @Override
    public void onDestroy() {
        mLifecycleSubject.onNext(FragmentEvent.DESTROY);
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onDetach() {
        mLifecycleSubject.onNext(FragmentEvent.DETACH);
        super.onDetach();
    }

    protected void getIntentExtra() {}

    protected void initView(){}

    protected void initData(){}

    protected abstract int getLayout();

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event e){

    }


    /**
     * @return 是否连接网络
     */
    public final boolean isConnected() {
        return ToolUtil.isNetworkConnected(getMActivity());
    }

    public FragmentActivity getMActivity(){
        return _mActivity;
    }

    @NonNull
    @Override
    public final Subject<FragmentEvent> provideLifecycleSubject() {
        return mLifecycleSubject;
    }


    public void startActivity(Class<?> to){
        startActivity(to, null);
    }

    public void startActivity(Class<?> to, ArrayMap<String, Object> map){
        /**
         * 跳转Activity之前需要判断当前Fragment的Activity是否在最上层
         * 界面快速来回切换可能出现白屏返回崩溃
         */
        if(getMActivity().getClass().getName().equals(getCurrentActivityName())){
            Intent intent = new Intent(getMActivity(), to);
            if(null != map && !map.isEmpty()){
                for(int i = 0, len = map.size(); i < len; i++){
                    String key = map.keyAt(i);
                    Object value = map.valueAt(i);
                    if(value instanceof Integer){
                        intent.putExtra(key, Integer.parseInt(value.toString()));
                    }else if(value instanceof String){
                        intent.putExtra(key, value.toString());
                    }else if(value instanceof Serializable){
                        intent.putExtra(key, (Serializable)value);
                    }else if(value instanceof Boolean){
                        intent.putExtra(key, Boolean.valueOf(value.toString()));
                    }
                }
                map.clear();
            }
            startActivity(intent);
        }
    }


    //获取最上层的activity
    private String getCurrentActivityName() {
        ActivityManager am = (ActivityManager) getMActivity().getSystemService(Activity.ACTIVITY_SERVICE);
        @SuppressWarnings("deprecation")
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
        ComponentName componentInfo = taskInfo.get(0).topActivity;
        return componentInfo.getClassName();
    }
}
