package com.movie58.lifecycle;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;

import com.trello.rxlifecycle2.LifecycleTransformer;
import com.trello.rxlifecycle2.RxLifecycle;
import com.trello.rxlifecycle2.android.ActivityEvent;
import com.trello.rxlifecycle2.android.FragmentEvent;
import com.trello.rxlifecycle2.android.RxLifecycleAndroid;
import com.trello.rxlifecycle2.internal.Preconditions;

/**
 * Created by yangxing on 2018/12/14 0014.
 */
public class RxLifecycleUtils {

    private RxLifecycleUtils() {
        throw new IllegalStateException("you can't instantiate me!");
    }

    /**
     * 绑定 Activity 的指定生命周期
     *
     * @param activity
     * @param event
     * @param <T>
     * @return
     */
    public static <T> LifecycleTransformer<T> bindUntilEvent(@NonNull final Activity activity,
                                                             final ActivityEvent event) {
        Preconditions.checkNotNull(activity, "activity == null");
        if (activity instanceof ActivityLifecycleable) {
            return bindUntilEvent((ActivityLifecycleable) activity, event);
        } else {
            throw new IllegalArgumentException("view isn't ActivityLifecycleable");
        }
    }

    /**
     * 绑定 Fragment 的指定生命周期
     *
     * @param fragment
     * @param event
     * @param <T>
     * @return
     */
    public static <T> LifecycleTransformer<T> bindUntilEvent(@NonNull final Fragment fragment,
                                                             final FragmentEvent event) {
        Preconditions.checkNotNull(fragment, "fragment == null");
        if (fragment instanceof FragmentLifecycleable) {
            return bindUntilEvent((FragmentLifecycleable) fragment, event);
        } else {
            throw new IllegalArgumentException("view isn't FragmentLifecycleable");
        }
    }

    public static <T, R> LifecycleTransformer<T> bindUntilEvent(@NonNull final Lifecycleable<R> lifecycleable, final R event) {
        Preconditions.checkNotNull(lifecycleable, "lifecycleable == null");
        return RxLifecycle.bindUntilEvent(lifecycleable.provideLifecycleSubject(), event);
    }

//    /**
//     * 绑定 Activity/Fragment 的生命周期
//     *
//     * @param activity
//     * @param <T>
//     * @return
//     */
//    public static <T> LifecycleTransformer<T> bindToLifecycle(@NonNull Activity activity) {
//        Preconditions.checkNotNull(activity, "activity == null");
//        if (activity instanceof Lifecycleable) {
//            return bindToLifecycle((Lifecycleable) activity);
//        } else {
//            throw new IllegalArgumentException("view isn't Lifecycleable");
//        }
//    }

    public static <T> LifecycleTransformer<T> bindToLifecycle(@NonNull Lifecycleable lifecycleable) {
        Preconditions.checkNotNull(lifecycleable, "lifecycleable == null");
        if (lifecycleable instanceof ActivityLifecycleable) {
            return RxLifecycleAndroid.bindActivity(((ActivityLifecycleable) lifecycleable).provideLifecycleSubject());
        } else if (lifecycleable instanceof FragmentLifecycleable) {
            return RxLifecycleAndroid.bindFragment(((FragmentLifecycleable) lifecycleable).provideLifecycleSubject());
        } else {
            throw new IllegalArgumentException("Lifecycleable not match");
        }
    }
}
