package com.movie58.http;

/**
 * Created by yangxing on 2019/5/8 0008.
 * HttpUrl.UPDATE
 */
public class HttpUrl {
    //http://api.anboi.cn/api.php/member/play/searchLog
    public static String baseUrl = "http://api.anboi.cn/api.php/";
//    public static String baseUrl = "http://58ys999.com/api.php/";

    public static String HOME_TAB = baseUrl + "decorate/Index/nav";

    public static String SEARCH_TAB = baseUrl + "collect/Collect/searchIndex";
    public static String SEARCH_HOT = baseUrl + "collect/Collect/navMostList";
    public static String SCREEN_INDEX = baseUrl + "collect/Collect/screenIndex";
    public static String SEARCH = baseUrl + "collect/Collect/search";
    public static String HOME_LIST = baseUrl + "decorate/Index/index";
    public static String VERIFY_CODE = baseUrl + "member/public/sendValidateCodeSmg";
    public static String REGISTER = baseUrl + "member/public/register";
    public static String LOGIN = baseUrl + "member/public/login";
    public static String LOGOUT = baseUrl + "member/public/logout";
    public static String CHANGE_PWD = baseUrl + "member/public/passwordReset";
    public static String CHECK_PHONE = baseUrl + "member/public/checkMobile";
    public static String CHANGE_USER = baseUrl + "member/member/editUserInfo";
    public static String CHECK_CODE = baseUrl + "member/member/checkValidateCode";
    public static String UPLOAD_AVATAR = baseUrl + "member/member/avatarUpload";
    public static String USER_INFO = baseUrl + "member/member/getUserInfo";
    public static String DETAIL = baseUrl + "collect/Collect/show";
    public static String CHANGE_MORE = baseUrl + "collect/Collect/index";
    public static String PUBLISH_COMMENT = baseUrl + "collect/comment/publishComment";
    public static String MOVIE_COMMENTS = baseUrl + "collect/comment/getVodComments";
    public static String MOVIE_ALL_COMMENTS = baseUrl + "collect/comment/getAllReplyComments";
    public static String MOVIE_COMMENTS_REPLY = baseUrl + "collect/comment/replyComment";
    public static String MOVIE_ZAN = baseUrl + "collect/comment/topComment";
    public static String MOVIE_ZAN_CANCEL = baseUrl + "collect/comment/cancelTopComment";
    public static String MOVIE_COLLECT = baseUrl + "member/collect/collect";
    public static String MOVIE_COLLECT_CANCEL = baseUrl + "member/collect/cancelCollect";
    public static String PROJECT_LIST = baseUrl + "project/project/index";
    public static String PROJECT_DETAIL = baseUrl + "project/project/show";
    public static String PROJECT_COMMENT = baseUrl + "project/comment/getProjectComments";
    public static String PROJECT_ZAN = baseUrl + "project/comment/topComment";
    public static String PROJECT_ZAN_CANCEL = baseUrl + "project/comment/cancelTopComment";
    public static String PROJECT_COMMENT_PUBLISH = baseUrl + "project/comment/publishComment";
    public static String MOST_LIST = baseUrl + "collect/Collect/navMostList";
    public static String FEEDBACK = baseUrl + "member/back_message/backMessage";
    public static String FEEDBACK_LIST = baseUrl + "member/back_message/getMessages";
    public static String INVIDE_CODE = baseUrl + "member/member/inviteValidate";
    public static String COLLECT_LIST = baseUrl + "member/collect/index";
    public static String EXCHANGE = baseUrl + "member/exchange/exchange";
    public static String EXCHANGE_LIST = baseUrl + "member/exchange/index";
    public static String PLAY_HISTORY = baseUrl + "member/play/index";
    public static String PLAY_HISTORY_CANCEL = baseUrl + "member/play/deletePlayLog";
    public static String DANMU_LIST = baseUrl + "collect/barrage/getVodBarrage";
    public static String DANMU_SEND = baseUrl + "collect/barrage/publishBarrage";
    public static String COLLECT_CANCEL = baseUrl + "member/collect/batchCancelCollect";
    public static String PLAY_RECORD = baseUrl + "collect/play/record";
    //    public static String PLAY_RECORD = baseUrl + "member/play/record";
    public static String PLAY_LOG = baseUrl + "collect/play/getPlayLog";
    //    public static String PLAY_LOG = baseUrl + "member/play/getPlayLog";
    public static String ADD_EXP = baseUrl + "member/experience_center/addExperience";
    public static String HELP_LIST = baseUrl + "member/help/index";
    public static String RULE_INDEX = baseUrl + "member/task_center/getRuleList";
    public static String RULE_REWARD = baseUrl + "member/task_center/getGoldReward";
    public static String LEVEL_DETAIL = baseUrl + "member/level/index";
    public static String LEVEL_UP = baseUrl + "member/member/getExperienceLog";
    public static String INVITE_LIST = baseUrl + "member/invite/index";
    public static String GOLD_LIST = baseUrl + "member/gold/getGoldLog";
    public static String CONVERT_LIST = baseUrl + "member/special_center/getRuleList";
    public static String CONVERT_USE = baseUrl + "member/special_center/exchangeRight";
    public static String MSG_SYSTEM = baseUrl + "member/system_message/getMessages";
    public static String MSG_FEEDBACK = baseUrl + "member/back_message/getMessages";
    public static String GET_AD = baseUrl + "advert/advert/index";
    public static String UPDATE = baseUrl + "setting/soft_update/getSettings";
    public static String GOLD_SETTING = baseUrl + "setting/cash/getSetting";
    public static String GOLD_DUIHUAN = baseUrl + "member/cash/exchange";
    public static String GOLD_HIS = baseUrl + "member/cash/logList";
    public static String QQ_INFOR = baseUrl + "member/ac/index";
    public static String SHARE_INFO = baseUrl + "setting/setting/getImg";
}
