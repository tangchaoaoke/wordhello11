package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/10 0010.
 */
public class HotImgInfo {
    private String img;
    private String up_right_text;
    private String down_right_text;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getUp_right_text() {
        return up_right_text;
    }

    public void setUp_right_text(String up_right_text) {
        this.up_right_text = up_right_text;
    }

    public String getDown_right_text() {
        return down_right_text;
    }

    public void setDown_right_text(String down_right_text) {
        this.down_right_text = down_right_text;
    }
}
