/*
 * Copyright © 2018 Yan Zhenjie.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.movie58.http;

import com.yanzhenjie.kalle.exception.ConnectTimeoutError;
import com.yanzhenjie.kalle.exception.HostError;
import com.yanzhenjie.kalle.exception.NetworkError;
import com.yanzhenjie.kalle.exception.ParseError;
import com.yanzhenjie.kalle.exception.ReadTimeoutError;
import com.yanzhenjie.kalle.exception.URLError;
import com.yanzhenjie.kalle.exception.WriteException;
import com.yanzhenjie.kalle.simple.Callback;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Created by yangxing on 2018/10/9 0009.
 */
public abstract class NormalCallback<S> extends Callback<S, String> {

    public NormalCallback() {
    }

    @Override
    public Type getSucceed() {
        Type superClass = getClass().getGenericSuperclass();
        return ((ParameterizedType) superClass).getActualTypeArguments()[0];
    }

    @Override
    public Type getFailed() {
        return String.class;
    }

    @Override
    public void onStart() {
    }

    @Override
    public void onException(Exception e) {
        String message;
        if (e instanceof NetworkError) {
            message = "网络不可用";
        } else if (e instanceof URLError) {
            message = "Url格式错误";
        } else if (e instanceof HostError) {
            message = "没有找到Url指定服务器";
        } else if (e instanceof ConnectTimeoutError) {
            message = "连接服务器超时，请重试";
        } else if (e instanceof WriteException) {
            message = "发送数据错误，请检查网络";
        } else if (e instanceof ReadTimeoutError) {
            message = "读取服务器数据超时，请检查网络";
        } else if (e instanceof ParseError) {
            message = "解析数据时发生异常";
        } else {
            message = "发生未知异常，请稍后重试";
        }
        onFinnalyException();
//        onResponse(SimpleResponse.<S, String>newBuilder()
//                .failed(message)
//                .build());
    }

    @Override
    public void onResponse(SimpleResponse<S, String> response) {
        try {
            if (response.isSucceed()){
                onFinaly(response);
            }else{
                onFinnalyException();
            }
        } catch (Exception e) {
        }
    }

    public void onFinaly(SimpleResponse<S, String> response) {
    }

    public void onFinnalyException() {

    }

    @Override
    public void onCancel() {
    }

    @Override
    public void onEnd() {
    }


}