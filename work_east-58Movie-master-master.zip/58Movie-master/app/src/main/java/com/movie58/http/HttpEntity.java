package com.movie58.http;

/**
 * Created by yangxing on 2018/10/9 0009.
 */
public class HttpEntity {

    /**
     * code : 1
     * msg : 操作成功
     * data : [{"id":9,"cat_name":"推荐","create_time":1556887596,"update_time":1556887596,"sort":0,"page_name":"recommend"},{"id":2,"cat_name":"电影","create_time":null,"update_time":null,"sort":1,"page_name":"movie"},{"id":1,"cat_name":"电视剧","create_time":null,"update_time":null,"sort":2,"page_name":"tv"},{"id":3,"cat_name":"动漫","create_time":1556375262,"update_time":1556375262,"sort":3,"page_name":"anime"},{"id":10,"cat_name":"综艺","create_time":1557195873,"update_time":1557195873,"sort":4,"page_name":"variety"}]
     */

    private int code;
    private String msg;
    private String data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
