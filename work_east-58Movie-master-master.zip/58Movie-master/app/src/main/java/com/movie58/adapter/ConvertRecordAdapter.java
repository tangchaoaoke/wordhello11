package com.movie58.adapter;

import android.support.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.ConvertRecordInfo;

import java.util.List;

/**
 * Created by yangxing on 2019/6/26 0026.
 */
public class ConvertRecordAdapter extends BaseQuickAdapter<ConvertRecordInfo, BaseViewHolder> {


    public ConvertRecordAdapter(@Nullable List<ConvertRecordInfo> data) {
        super(R.layout.item_convert_record, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, ConvertRecordInfo item) {
        int f = (int) (1 / item.getScale());
        helper.setText(R.id.tv_time, item.getCreate_time())
                .setText(R.id.tv_gold, item.getGold_num() + "")
                .setText(R.id.tv_scale, (int)Float.parseFloat(item.getRmb())+ ":" + f);

        if (item.getStatus() == 0) {
            helper.setText(R.id.tv_state, "未兑换")
                    .setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.color_ff0000));
        }else{
            helper.setText(R.id.tv_state, "已兑换")
                    .setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.color_base));
        }
    }
}
