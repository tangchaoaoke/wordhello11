package com.movie58.newdemand.base;

import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.movie58.newdemand.utils.DisplayUtil;
import com.zhy.autolayout.utils.AutoUtils;

public abstract class BaseAty extends BaseActivity{

    public void initTopview(RelativeLayout relay, RelativeLayout relay_top) {
        int StatusBarHeight = DisplayUtil.getStateBar(this);
        if (StatusBarHeight <= 0) {
            StatusBarHeight = (int) DisplayUtil.dip2px(this, 20);
        }
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) relay.getLayoutParams();
        lp.height = AutoUtils.getPercentHeightSize(150);
        lp.topMargin = StatusBarHeight;
        relay.setLayoutParams(lp);

        LinearLayout.LayoutParams lp2 = (LinearLayout.LayoutParams) relay_top.getLayoutParams();
        lp2.height = AutoUtils.getPercentHeightSize(150)+StatusBarHeight;
        relay_top.setLayoutParams(lp2);

    }

    public void initTopview(RelativeLayout relay, RelativeLayout relay_top,int h) {
        int StatusBarHeight = DisplayUtil.getStateBar(this);
        if (StatusBarHeight <= 0) {
            StatusBarHeight = (int) DisplayUtil.dip2px(this, 20);
        }
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) relay.getLayoutParams();
        lp.height =h;
        lp.topMargin = StatusBarHeight;
        relay.setLayoutParams(lp);

        LinearLayout.LayoutParams lp2 = (LinearLayout.LayoutParams) relay_top.getLayoutParams();
        lp2.height =h+StatusBarHeight;
        relay_top.setLayoutParams(lp2);

    }
}
