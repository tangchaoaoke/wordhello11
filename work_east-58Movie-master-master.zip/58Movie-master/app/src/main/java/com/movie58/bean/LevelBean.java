package com.movie58.bean;

import java.util.List;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class LevelBean {
    /**
     * user_info : {"avatar":"http://47.105.218.54/upload/member/20190514/947b7c4a312144c5687403185c79ba86.jpeg","experience":22,"level_id":1,"level_name":"V1","next_level_name":"V2","upgrade_exp":28,"min_experience":1,"max_experience":50}
     * level_list : [{"id":1,"level_name":"V1","min_experience":1,"create_time":null,"update_time":null,"max_experience":50},{"id":2,"level_name":"V2","min_experience":50,"create_time":null,"update_time":null,"max_experience":200},{"id":3,"level_name":"V3","min_experience":200,"create_time":null,"update_time":null,"max_experience":500},{"id":4,"level_name":"V4","min_experience":500,"create_time":1558622204,"update_time":1558622204,"max_experience":1100},{"id":5,"level_name":"V5","min_experience":1100,"create_time":1558622237,"update_time":1558622237,"max_experience":2000},{"id":6,"level_name":"V6","min_experience":2000,"create_time":1558622321,"update_time":1558622321,"max_experience":3200},{"id":7,"level_name":"V7","min_experience":3200,"create_time":1558622339,"update_time":1558622339,"max_experience":4700},{"id":8,"level_name":"V8","min_experience":4700,"create_time":1558622670,"update_time":1558622670,"max_experience":6500},{"id":9,"level_name":"V9","min_experience":6500,"create_time":1558622682,"update_time":1558622682,"max_experience":8900},{"id":10,"level_name":"V10","min_experience":8900,"create_time":1558622702,"update_time":1558622702,"max_experience":1000000}]
     * grant_rule : [{"id":1,"rule_name":"每日登录","rule_desc":"每日登录","experience_num":10,"top_limit":1,"rule_code":"login_in","create_time":1558264673,"update_time":1558264673},{"id":2,"rule_name":"观看影片","rule_desc":"观看影片","experience_num":9,"top_limit":2,"rule_code":"play_vod","create_time":1558264673,"update_time":1558264673},{"id":3,"rule_name":"观看广告","rule_desc":"观看广告","experience_num":7,"top_limit":1,"rule_code":"play_advert","create_time":1558264673,"update_time":1558264673},{"id":4,"rule_name":"分享影片","rule_desc":"分享影片","experience_num":8,"top_limit":5,"rule_code":"share_vod","create_time":1558264673,"update_time":1558264673}]
     */

    private UserInfoBean user_info;
    private List<LevelListBean> level_list;
    private List<GrantRuleBean> grant_rule;

    public UserInfoBean getUser_info() {
        return user_info;
    }

    public void setUser_info(UserInfoBean user_info) {
        this.user_info = user_info;
    }

    public List<LevelListBean> getLevel_list() {
        return level_list;
    }

    public void setLevel_list(List<LevelListBean> level_list) {
        this.level_list = level_list;
    }

    public List<GrantRuleBean> getGrant_rule() {
        return grant_rule;
    }

    public void setGrant_rule(List<GrantRuleBean> grant_rule) {
        this.grant_rule = grant_rule;
    }

    public static class UserInfoBean {
        /**
         * avatar : http://47.105.218.54/upload/member/20190514/947b7c4a312144c5687403185c79ba86.jpeg
         * experience : 22
         * level_id : 1
         * level_name : V1
         * next_level_name : V2
         * upgrade_exp : 28
         * min_experience : 1
         * max_experience : 50
         */

        private String avatar;
        private int experience;
        private int level_id;
        private String level_name;
        private String next_level_name;
        private int upgrade_exp;
        private int min_experience;
        private int max_experience;

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public int getExperience() {
            return experience;
        }

        public void setExperience(int experience) {
            this.experience = experience;
        }

        public int getLevel_id() {
            return level_id;
        }

        public void setLevel_id(int level_id) {
            this.level_id = level_id;
        }

        public String getLevel_name() {
            return level_name;
        }

        public void setLevel_name(String level_name) {
            this.level_name = level_name;
        }

        public String getNext_level_name() {
            return next_level_name;
        }

        public void setNext_level_name(String next_level_name) {
            this.next_level_name = next_level_name;
        }

        public int getUpgrade_exp() {
            return upgrade_exp;
        }

        public void setUpgrade_exp(int upgrade_exp) {
            this.upgrade_exp = upgrade_exp;
        }

        public int getMin_experience() {
            return min_experience;
        }

        public void setMin_experience(int min_experience) {
            this.min_experience = min_experience;
        }

        public int getMax_experience() {
            return max_experience;
        }

        public void setMax_experience(int max_experience) {
            this.max_experience = max_experience;
        }
    }

    public static class LevelListBean {
        /**
         * id : 1
         * level_name : V1
         * min_experience : 1
         * create_time : null
         * update_time : null
         * max_experience : 50
         */

        private int id;
        private String level_name;
        private int min_experience;
        private Object create_time;
        private Object update_time;
        private int max_experience;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getLevel_name() {
            return level_name;
        }

        public void setLevel_name(String level_name) {
            this.level_name = level_name;
        }

        public int getMin_experience() {
            return min_experience;
        }

        public void setMin_experience(int min_experience) {
            this.min_experience = min_experience;
        }

        public Object getCreate_time() {
            return create_time;
        }

        public void setCreate_time(Object create_time) {
            this.create_time = create_time;
        }

        public Object getUpdate_time() {
            return update_time;
        }

        public void setUpdate_time(Object update_time) {
            this.update_time = update_time;
        }

        public int getMax_experience() {
            return max_experience;
        }

        public void setMax_experience(int max_experience) {
            this.max_experience = max_experience;
        }
    }

    public static class GrantRuleBean {
        /**
         * id : 1
         * rule_name : 每日登录
         * rule_desc : 每日登录
         * experience_num : 10
         * top_limit : 1
         * rule_code : login_in
         * create_time : 1558264673
         * update_time : 1558264673
         */

        private int id;
        private String rule_name;
        private String rule_desc;
        private int experience_num;
        private int top_limit;
        private String rule_code;
        private int create_time;
        private int update_time;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getRule_name() {
            return rule_name;
        }

        public void setRule_name(String rule_name) {
            this.rule_name = rule_name;
        }

        public String getRule_desc() {
            return rule_desc;
        }

        public void setRule_desc(String rule_desc) {
            this.rule_desc = rule_desc;
        }

        public int getExperience_num() {
            return experience_num;
        }

        public void setExperience_num(int experience_num) {
            this.experience_num = experience_num;
        }

        public int getTop_limit() {
            return top_limit;
        }

        public void setTop_limit(int top_limit) {
            this.top_limit = top_limit;
        }

        public String getRule_code() {
            return rule_code;
        }

        public void setRule_code(String rule_code) {
            this.rule_code = rule_code;
        }

        public int getCreate_time() {
            return create_time;
        }

        public void setCreate_time(int create_time) {
            this.create_time = create_time;
        }

        public int getUpdate_time() {
            return update_time;
        }

        public void setUpdate_time(int update_time) {
            this.update_time = update_time;
        }
    }
}
