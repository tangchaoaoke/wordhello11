package com.movie58.newdemand.interfaces;


import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.net.ApiTool;
import com.movie58.account.Account;
import com.movie58.http.HttpUrl;

import org.xutils.http.RequestParams;

public class Sheet {


    //片单导航栏
    public void d(ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "collect/collect/navSheet");
        if (Account.getInstance().isLogined()) {
            params.addHeader("XX-Token", Account.getInstance().getToken());
        }
        params.addHeader("XX-Device-Type", "android");
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "navSheet");
    }

    //影片列表
    public void ds(String cat_id, String sheet_id, int page, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "collect/collect/search");
        if (Account.getInstance().isLogined()) {
            params.addHeader("XX-Token", Account.getInstance().getToken());
        }

        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("cat_id", cat_id);
        params.addBodyParameter("sheet_id", sheet_id);
        params.addBodyParameter("size", "15");
        params.addBodyParameter("page", String.valueOf(page));
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "search");
    }

    //创建片单
    public void d2(String sheet_name, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/createSheet");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("sheet_name", sheet_name);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "createSheet");
    }

    //删除片单  member/play/deleteSheet
    public void d4(String sheet_id, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/deleteSheet");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("sheet_id", sheet_id);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "deleteSheet");
    }

    //我的片单
    public void d3(ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/sheetVodList");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "sheetVodList");
    }

    //片单添加影片
    //sheet_id 片单id
    //vod_ids  影片id 1,2,3
    public void d5(String sheet_id, String vod_ids, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/addVodSheet");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("sheet_id", sheet_id);
        params.addBodyParameter("vod_ids", vod_ids);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "addVodSheet");
    }


    //更改片单名字
    public void e(String sheet_id, String sheet_name, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/replaceSheetName");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("sheet_id", sheet_id);
        params.addBodyParameter("sheet_name", sheet_name);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "replaceSheetName");
    }

    //片单删除影片
    public void e2(String sheet_id, String vod_ids, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/delVodSheet");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("sheet_id", sheet_id);
        params.addBodyParameter("vod_ids", vod_ids);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "delVodSheet");
    }

    //搜索影片
    public void e3(String sheet_id, String source_name, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "collect/collect/search");
        params.addHeader("XX-Token", Account.getInstance().getToken());
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("sheet_id", sheet_id);
        params.addBodyParameter("source_name", source_name);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "search");
    }
}
