package com.movie58.adapter;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bigkoo.convenientbanner.holder.Holder;
import com.movie58.R;
import com.movie58.bean.HomeListInfo;
import com.movie58.img.PicassoUtils;

/**
 * Created by yangxing on 2019/5/10 0010.
 */
public class BannerImgHolder extends Holder<HomeListInfo.ParamsBean.ListBean> {
    private ImageView ivImg;
    TextView tvTitle;
    Context ctx;

    public BannerImgHolder(Context ctx, View itemView) {
        super(itemView);
        this.ctx = ctx;
    }

    @Override
    protected void initView(View itemView) {
        ivImg = itemView.findViewById(R.id.iv_banner);
        tvTitle = itemView.findViewById(R.id.tv_title);
    }

    @Override
    public void updateUI(HomeListInfo.ParamsBean.ListBean data) {
        PicassoUtils.LoadImageWithDetfult(ctx, data.getImg_url(), ivImg, R.drawable.pic_emptypage_failure);
        tvTitle.setText(data.getVod_name());
    }
}
