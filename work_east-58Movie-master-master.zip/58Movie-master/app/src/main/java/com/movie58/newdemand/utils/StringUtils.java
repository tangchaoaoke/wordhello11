package com.movie58.newdemand.utils;


public class StringUtils {

    public static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }

}
