package com.movie58.newdemand.ui.tscreen;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.movie58.R;
import com.movie58.newdemand.base.BaseAty;
import com.yanbo.lib_screen.entity.ClingDevice;
import com.yanbo.lib_screen.event.DeviceEvent;
import com.yanbo.lib_screen.listener.ItemClickListener;
import com.yanbo.lib_screen.manager.ClingManager;
import com.yanbo.lib_screen.manager.DeviceManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class DeviceListAty extends BaseAty {

    @BindView(R.id.imv_01)
    ImageView imv_01;
    @BindView(R.id.tv_01)
    TextView tv_01;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.scro_01)
    NestedScrollView scro_01;
    @BindView(R.id.relay_play)
    RelativeLayout relay_play;
    private List<ClingDevice> clingDevices;
    private ClingDeviceAdapter adapter;
    private String json_details;
    private int play_anthology;

    @Override
    public int getLayoutId() {
        return R.layout.aty_device_list;
    }

    @Override
    public void initPresenter() {
    }

    @Override
    public void initView() {
        json_details = getIntent().getStringExtra("json_details");
        play_anthology = getIntent().getIntExtra("play_anthology", 0);
    }


    @Override
    public void requestData() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTranslanteBar();
        ClingManager.getInstance().startClingService();
        Glide.with(this).load(R.drawable.aic_08).into(imv_01);
        startSearch();
    }

    private CountDownTimer mTimer;

    public void startSearch() {
        cancel();
        tv_01.setText("正在搜索可投屏设备..");
        imv_01.setVisibility(View.VISIBLE);
        scro_01.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        relay_play.setVisibility(View.GONE);
        if (mTimer == null) {
            mTimer = new CountDownTimer((long) (5 * 1000), 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    clingDevices = DeviceManager.getInstance().getClingDeviceList();
                    if (clingDevices != null && clingDevices.size() > 0) {
                        cancel();
                        imv_01.setVisibility(View.GONE);
                        isRefresh = false;
                        tv_01.setText("已搜索可投屏设备(" + clingDevices.size() + ")");
                        recyclerView.setVisibility(View.VISIBLE);
                        relay_play.setVisibility(View.VISIBLE);
                        initList();
                    } else {
                        tv_01.setText("正在搜索可投屏设备..");
                    }
                }

                @Override
                public void onFinish() {
                    if (clingDevices != null && clingDevices.size() > 0) {
                    } else {
                        tv_01.setText("未搜索可投屏设备");
                        isRefresh = false;
                        imv_01.setVisibility(View.GONE);
                        scro_01.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.GONE);
                        relay_play.setVisibility(View.GONE);
                    }
                }
            };
            mTimer.start();
        }
    }

    private boolean isRefresh = true;

    @OnClick({R.id.imgv_cancel, R.id.imgv_refresh, R.id.relay_play})
    void click(View v) {
        switch (v.getId()) {
            case R.id.imgv_cancel:
                finish();
                break;
            case R.id.imgv_refresh:
                if (isRefresh) {
                    return;
                }
                startSearch();
                break;
            case R.id.relay_play:
                if (DeviceManager.getInstance().getCurrClingDevice() == null) {
                    showShortToast("请先连接设备");
                    return;
                }
                Intent intent = new Intent(this, DevicePlayAty.class);
                intent.putExtra("json_details", json_details);
                intent.putExtra("play_anthology", play_anthology);
                startActivity(intent);
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cancel();
        ClingManager.getInstance().destroy();
    }


    public void cancel() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    public void initList() {
        if (adapter == null) {
            adapter = new ClingDeviceAdapter(this, clingDevices);
            LinearLayoutManager layoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setAdapter(adapter);
            adapter.setItemClickListener(new ItemClickListener() {
                @Override
                public void onItemAction(int action, Object object) {
                    ClingDevice device = (ClingDevice) object;
                    DeviceManager.getInstance().setCurrClingDevice(device);
                    Toast.makeText(getBaseContext(), "选择了设备 " + device.getDevice().getDetails().getFriendlyName(), Toast.LENGTH_LONG).show();
                    refresh();
                }
            });
        } else {
            adapter.setdata(clingDevices);
        }
    }

    public void refresh() {
        if (adapter == null) {
            adapter = new ClingDeviceAdapter(this, clingDevices);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.setdata(clingDevices);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventBus(DeviceEvent event) {
        refresh();
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }


}
