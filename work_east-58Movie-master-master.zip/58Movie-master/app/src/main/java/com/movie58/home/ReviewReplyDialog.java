package com.movie58.home;

import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.TimeUtils;
import com.cbman.roundimageview.RoundImageView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BottomPopupView;
import com.lxj.xpopup.interfaces.OnSelectListener;
import com.movie58.R;
import com.movie58.bean.MovieReviewInfo;
import com.movie58.bean.ReplyInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.OnDoubleClickListener;
import com.movie58.util.ToolUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangxing on 2019/6/10 0010.
 */
public class ReviewReplyDialog extends BottomPopupView {

    RoundImageView ivHead;
    TextView tvName, tvDate, tvZan, tvReview;
    RecyclerView rvList;
    EditText etCommon;
    Button btnSend;
    RelativeLayout layoutBottom;
    RelativeLayout layoutMain;
    View view;

    MovieReviewInfo reviewInfo;
    Context ctx;
    private int replyId;

    ReplyAdapter mAdapter;

    public ReviewReplyDialog(@NonNull Context context, MovieReviewInfo reviewInfo) {
        super(context);
        ctx = context;
        this.reviewInfo = reviewInfo;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_review_reply;
    }

    @Override
    protected void onCreate() {
        super.onCreate();

        layoutMain = findViewById(R.id.layout);
        view = findViewById(R.id.view);
        ivHead = findViewById(R.id.iv_head);
        tvName = findViewById(R.id.tv_name);
        tvDate = findViewById(R.id.tv_date);
        tvZan = findViewById(R.id.tv_zan);
        tvReview = findViewById(R.id.tv_review);
        rvList = findViewById(R.id.rv_list);
        etCommon = findViewById(R.id.et_common);
        btnSend = findViewById(R.id.btn_send);
        layoutBottom = findViewById(R.id.layout_bottom4);

        PicassoUtils.LoadImageWithDetfult(ctx, reviewInfo.getAvatar(), ivHead, R.drawable.avatar);
        tvName.setText(reviewInfo.getSend_user_name());
        tvDate.setText(reviewInfo.getUpdate_time());
        tvReview.setText(reviewInfo.getComments());
        tvZan.setText(reviewInfo.getTop_num() + "");
        if (reviewInfo.getIs_top() == 1) {
            tvZan.setCompoundDrawablesWithIntrinsicBounds(R.drawable.zan1, 0, 0, 0);
        }else{
            tvZan.setCompoundDrawablesWithIntrinsicBounds(R.drawable.zan, 0, 0, 0);
        }

        /**
         * 软键盘上推布局
         */
        layoutBottom.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect rect = new Rect();
            layoutBottom.getWindowVisibleDisplayFrame(rect);
            int availableHeight = rect.bottom - layoutBottom.getTop();
            View focusedChild = layoutBottom.getFocusedChild();
            float contentHeight = 0;
            if (focusedChild != null) {
                contentHeight = focusedChild.getY() + focusedChild.getHeight();
            }
            int deltaY = (int) (availableHeight - contentHeight);

            if (deltaY < 0) {
                layoutBottom.setTranslationY(deltaY);
            } else {
                layoutBottom.setTranslationY(0);
            }
        });
        replyId = reviewInfo.getId();

        etCommon.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (TextUtils.isEmpty(s)) {
                    btnSend.setEnabled(false);
                } else {
                    btnSend.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                if (isShow()) {
                    dismiss();
                }
            }
        });

        layoutMain.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                etCommon.requestFocus();
                showDialog(reviewInfo.getComments(), reviewInfo.getSend_user_name());
            }
        });

        btnSend.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                String review = etCommon.getText().toString().trim();
                if (TextUtils.isEmpty(review)) {
                    ToastUtils.show("回复内容不能为空");
                    return;
                }
                reply(reviewInfo.getId(), review);
            }
        });



        mAdapter = new ReplyAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(ctx));
//        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(ctx)
//                .color(ctx.getResources().getColor(R.color.line))
//                .marginProvider(new HorizontalDividerItemDecoration.MarginProvider() {
//                    @Override
//                    public int dividerLeftMargin(int position, RecyclerView parent) {
//                        return ctx.getResources().getDimensionPixelOffset(R.dimen.dp_15);
//                    }
//
//                    @Override
//                    public int dividerRightMargin(int position, RecyclerView parent) {
//                        return 0;
//                    }
//                }).build());
        mAdapter.bindToRecyclerView(rvList);

        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                replyId = mAdapter.getItem(position).getId();
                showDialog(mAdapter.getItem(position).getComments(), mAdapter.getItem(position).getSend_user_name());
            }
        });

        getReview();
    }

    private void showDialog(String review, String name){
        new XPopup.Builder(getContext())
//                        .enableDrag(false)
                .asBottomList("请选择", new String[]{"回复", "复制"},
                        new OnSelectListener() {
                            @Override
                            public void onSelect(int position, String text) {
                                if (position == 0) {
                                    etCommon.requestFocus();
                                    etCommon.setHint("回复@" + name);
                                    etCommon.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            ToolUtil.showSoftInput(etCommon);
                                        }
                                    }, 300);

                                }else{
                                    ToolUtil.copy(ctx, review);
                                    ToastUtils.show("评论内容已复制到剪切板");
                                }
                            }
                        })
                .show();
    }


    private class ReplyAdapter extends BaseQuickAdapter<ReplyInfo, BaseViewHolder> {

        public ReplyAdapter(@Nullable List<ReplyInfo> data) {
            super(R.layout.item_review_replay, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, ReplyInfo item) {
            RoundImageView ivImg = helper.getView(R.id.iv_head);
            PicassoUtils.LoadImageWithDetfult(mContext, item.getAvatar(), ivImg, R.drawable.avatar);
            String review;
            if (reviewInfo.getId() == item.getReply_id()) {
                review = item.getComments() + " {" + TimeUtils.getFriendlyTimeSpanByNow(item.getUpdate_time()) + "}";
            }else{
                review = "回复{@" + item.getReply_name() + "}" + item.getComments() + " {" + TimeUtils.getFriendlyTimeSpanByNow(item.getUpdate_time()) + "}";
            }


            helper.setText(R.id.tv_name1, item.getSend_user_name())
                    .setText(R.id.tv_review1, ToolUtil.getTextWithColor(review, R.color.color_969699, R.color.color_323233))
                    .addOnClickListener(R.id.tv_zan);
        }
    }

    private void getReview() {
        Kalle.post(HttpUrl.MOVIE_ALL_COMMENTS)
                .param("comment_id", reviewInfo.getId())
                .perform(new LoadingCallback<String>(ctx) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            List<ReplyInfo> list = FastJsonUtil.toList(response.succeed(), "all_reply_comments", ReplyInfo.class);
                            if (list == null || list.isEmpty()) {
                                return;
                            }
                            mAdapter.setNewData(list);
                        } else {
                            ToastUtils.show(response.failed());

                        }
                    }
                });
    }

    private void reply(int reviewId, String review) {
        Kalle.post(HttpUrl.MOVIE_COMMENTS_REPLY)
                .param("vod_id", reviewInfo.getVod_id())
                .param("reply_main_comment_id", reviewInfo.getId())
                .param("reply_user_id", reviewInfo.getSend_user_id())
                .param("reply_id", reviewId)
                .param("comments", review)
                .perform(new LoadingCallback<String>(ctx) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            getReview();
                            etCommon.clearFocus();
                            etCommon.setText("");
                        } else {
                            ToastUtils.show(response.failed());

                        }
                    }
                });
    }
}
