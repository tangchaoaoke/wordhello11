package com.movie58.my;

import android.view.View;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.base.BaseFragment;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class MsgFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;


    public static MsgFragment newInstance() {
        return new MsgFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("我的消息");
    }

    @OnClick({R.id.iv_back, R.id.tv_system, R.id.tv_feedback})
    void Click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                getMActivity().finish();
                break;
            case R.id.tv_system:
                start(MsgSystemFragment.newInstance());
                break;
            case R.id.tv_feedback:
                start(MsgFeedbackFragment.newInstance());
                break;
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_msg;
    }

}
