package com.movie58.event;

/**
 * Created by yangxing on 2017/12/15 0015.
 */

public class Event {


    public static final int CODE_01_TAB_HOME = 1001;
    public static final int CODE_02_SCHOOL_REVIEW = 1002;
    public static final int CODE_03_SCHOOL_REVIEW_BTN = 1003;
    public static final int CODE_04_SCHOOL_TIME_FILE = 1004;
    public static final int CODE_05_SCHOOL_TIME_VIDEO = 1005;
    public static final int CODE_06_SCHOOL_PROFRESS = 1006;
    public static final int CODE_07_SCHOOL_SORT = 1007;
    public static final int CODE_08_SCHOOL_SEARCH = 1008;
    public static final int CODE_09_SCHOOL_RESULT_REFRESH = 1009;
    public static final int CODE_10_SCHOOL_MY_CLICK = 1010;
    public static final int CODE_11_SCHOOL_RESULT_CLICK = 1011;
    public static final int CODE_12_SCHOOL_CARD_CLICK = 1012;
    public static final int CODE_13_SCHOOL_REVIEW_STATE = 1013;
    public static final int CODE_14_AVATAR = 1014;
    public static final int CODE_15_MESSAGE_UNREAD = 1015;
    public static final int CODE_16_MIAN_APPLICATION = 1016;
    public static final int CODE_17_IM_UNREAD = 1017;
    public static final int CODE_18_WORDLIST_REFRESH = 1018;
    public static final int CODE_19_MODE = 1019;
    public static final int CODE_20_HOME_TAB = 1020;
    public static final int CODE_21_WORDLIST_ITEM = 1021;
    public static final int CODE_22_WORDLIST_TIME = 1022;
    public static final int CODE_23_EXPRESS_ADDRESS = 1023;
    public static final int CODE_24_EXPRESS_ADDRESS_ADD = 1024;
    public static final int CODE_25_EXPRESS_ADDRESS_EDIT = 1025;
    public static final int CODE_26_EXPRESS_ADDRESS_DELETE = 1026;
    public static final int CODE_27_EXPRESS_INFO = 1027;
    public static final int CODE_28_EXPRESS_PRICE = 1028;
    public static final int CODE_29_EXPRESS_REMARK = 1029;
    public static final int CODE_30_EXPRESS_NAME = 1030;
    public static final int CODE_31_INSTALLWORK_LIST = 1031;
    public static final int CODE_32_INSTALLWORK_YUYUE = 1032;
    public static final int CODE_33_INSTALLWORK_FOLLOW = 1033;
    public static final int CODE_34_INSTALLWORK_TO_MATERIALS = 1034;
    public static final int CODE_35_INSTALLWORK_INFO = 1035;
    public static final int CODE_36_INSTALLWORK_ISFOLLOW = 1036;
    public static final int CODE_37_INSTALLWORK_STATUS = 1037;
    public static final int CODE_38_INSTALLWORK_MATERIALS = 1038;
    public static final int CODE_39_INSTALLWORK_ADDED = 1039;
    public static final int CODE_40_INSTALLWORK_END = 1040;
    public static final int CODE_41_INSTALLWORK_COUNT = 1041;
    public static final int CODE_42_INSTALLWORK_NAVIGATION = 1042;
    public static final int CODE_43_FOUND = 1043;
    public static final int CODE_44_INSTALLWORK_SAVE = 1044;
    public static final int CODE_45_PAY_ALI = 1045;
    public static final int CODE_46_PAY_WEIXIN = 1046;
    public static final int CODE_47_HUNHE_BACK = 1047;
    public static final int CODE_48_LOGIN_IN = 1048;
    public static final int CODE_49_LOGIN_OUT = 1049;
    public static final int CODE_50_REFRESH_NUM = 1050;
    public static final int CODE_51_FILTER_OPEN = 1051;
    public static final int CODE_52_FILTER_CLOSE = 1052;
    public static final int CODE_53_REGISTER_AREA = 1053;
    public static final int CODE_54_FILTER_ONE_SEL = 1054;
    public static final int CODE_55_FILTER_TWO_SEL = 1055;
    public static final int CODE_56_FILTER_THREE_SEL = 1056;
    public static final int CODE_57_FILTER_RESET = 1057;
    public static final int CODE_58_COLLECTION = 1058;
    public static final int CODE_59_MESSAGE = 1059;
    public static final int CODE_60_FEEDBACK = 1060;
    /**
     * 刷新播放记录
     */
    public static final int CODE_61_REFRESH_PLAY_HISTORY = 1061;

    int event;

    Object obj1;
    Object obj2;
    Object obj3;
    Object obj4;
    Object obj5;
    Object obj6;

    public Event() {
    }

    public Event(int event) {
        setEvent(event);
    }

    public int getEvent() {
        return event;
    }

    public void setEvent(int event) {
        this.event = event;
    }

    public Object getObj1() {
        return obj1;
    }

    public Event setObj1(Object obj1) {
        this.obj1 = obj1;
        return this;
    }

    public Object getObj2() {
        return obj2;
    }

    public Event setObj2(Object obj2) {
        this.obj2 = obj2;
        return this;
    }

    public Object getObj3() {
        return obj3;
    }

    public Event setObj3(Object obj3) {
        this.obj3 = obj3;
        return this;
    }

    public Object getObj4() {
        return obj4;
    }

    public Event setObj4(Object obj4) {
        this.obj4 = obj4;
        return this;
    }

    public Object getObj5() {
        return obj5;
    }

    public Event setObj5(Object obj5) {
        this.obj5 = obj5;
        return this;
    }

    public Object getObj6() {
        return obj6;
    }

    public Event setObj6(Object obj6) {
        this.obj6 = obj6;
        return this;
    }
}
