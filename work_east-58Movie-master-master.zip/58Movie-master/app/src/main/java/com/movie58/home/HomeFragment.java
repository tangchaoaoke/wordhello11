package com.movie58.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewPager;
import android.util.SparseArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.ui.NavigationAty;
import com.movie58.newdemand.view.LoadingTip;
import com.movie58.account.Account;
import com.movie58.account.LoginActivity;
import com.movie58.base.BaseFragment;
import com.movie58.bean.HomeTab;
import com.movie58.bean.SearchHotInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.my.CacheActivity;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.zhy.autolayout.utils.AutoUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class HomeFragment extends BaseFragment implements LoadingTip.onReloadListener {

    @BindView(R.id.layout_tab)
    SlidingTabLayout layoutTab;
    @BindView(R.id.vp)
    ViewPager vp;
    @BindView(R.id.iv_history)
    ImageView ivHistory;
    @BindView(R.id.iv_cache)
    ImageView ivCache;
    @BindView(R.id.tv_all)
    TextView tvAll;
    @BindView(R.id.layout_search)
    RelativeLayout layoutSearch;
    @BindView(R.id.tv_search)
    TextView tvSearch;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.relay)
    RelativeLayout relay;
    @BindView(R.id.imv_all)
    ImageView imv_all;
    @BindView(R.id.loadedTip)
    LoadingTip loadedTip;


    List<HomeTab> listTab = new ArrayList<>();

    private ArrayList<BaseFragment> list_frg;

    private int selPosition = 0;

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initTopview(relay, relay_top, AutoUtils.getPercentHeightSize(230));
        requestData();
        loadedTip.setOnReloadListener(this);
    }


    public void requestData() {
        loadedTip.setLoadingTip(LoadingTip.LoadStatus.loading);
        getTab();
    }

    @Override
    protected void initView() {
        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                selPosition = position;
                switch (position) {
                    case 0:
                        ivHistory.setVisibility(View.VISIBLE);
                        ivCache.setVisibility(View.VISIBLE);
                        tvAll.setVisibility(View.GONE);
                        imv_all.setVisibility(View.GONE);
                        break;
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        ivHistory.setVisibility(View.INVISIBLE);
                        ivCache.setVisibility(View.INVISIBLE);
                        tvAll.setVisibility(View.VISIBLE);
                        imv_all.setVisibility(View.VISIBLE);
                        break;
                }
                getHot(listTab.get(position).getId());
            }

            @Override
            public void onTabReselect(int position) {

            }
        });

        vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                selPosition = i;
                switch (i) {
                    case 0:
                    case 5:
                        ivHistory.setVisibility(View.VISIBLE);
                        ivCache.setVisibility(View.VISIBLE);
                        tvAll.setVisibility(View.GONE);
                        imv_all.setVisibility(View.GONE);
                        break;
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        ivHistory.setVisibility(View.INVISIBLE);
                        ivCache.setVisibility(View.INVISIBLE);
                        tvAll.setVisibility(View.VISIBLE);
                        imv_all.setVisibility(View.VISIBLE);
                        break;

                }
                getHot(listTab.get(i).getId());
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    @OnClick({R.id.layout_search, R.id.iv_history, R.id.iv_cache,
            R.id.tv_all, R.id.relay_right, R.id.imv_all})
    void click(View v) {
        switch (v.getId()) {
            case R.id.layout_search:
                startActivity(SearchActivity.class);
                break;
            case R.id.iv_history:
                if (Account.getInstance().isLogined()) {
                    startActivity(PlayHistoryActivity.class);
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.iv_cache:
                if (Account.getInstance().isLogined()) {
                    startActivity(CacheActivity.class);
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.imv_all:
            case R.id.tv_all:
                ArrayMap map = new ArrayMap();
                map.put("id", listTab.get(selPosition).getId());
                map.put("name", listTab.get(selPosition).getCat_name());
                startActivity(MovieAllActivity.class, map);
                break;
            case R.id.relay_right:
                if (listTab == null || listTab.size() == 0) {
                    return;
                }
                ArrayList<String> list = new ArrayList<>();
                ArrayList<String> list2 = new ArrayList<>();
                for (int i = 0; i < listTab.size(); i++) {
                    list.add(listTab.get(i).getId() + "");
                    list2.add(listTab.get(i).getCat_name() + "");
                }
                Intent intent = new Intent(getActivity(), NavigationAty.class);
                intent.putStringArrayListExtra("data", list);
                intent.putStringArrayListExtra("data2", list2);
                getActivity().startActivityForResult(intent, 1314);
                break;
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1314) {
                List<HomeTab> listTab2 = new ArrayList<>();
                ArrayList<String> list = data.getStringArrayListExtra("data");

                for (int j = 0; j < list.size(); j++) {
                    for (int i = 0; i < listTab.size(); i++) {
                        if (list.get(j).equals(listTab.get(i).getId() + "")) {
                            listTab2.add(listTab.get(i));
                            break;
                        }
                    }
                }
                listTab.clear();
                listTab.addAll(listTab2);

                list_frg = new ArrayList<>();
                list_frg.clear();
                for (int i = 0; i < listTab.size(); i++) {
                    list_frg.add(MovieFragment.newInstance(listTab.get(i).getId()));
                }
                clearFrg();
                vp.setAdapter(new MyPagerAdapter(getChildFragmentManager()));
                layoutTab.setViewPager(vp);
                vp.setOffscreenPageLimit(list_frg.size());
            }
        }
    }

    public void clearFrg() {
        if (vp.getAdapter() != null) {
            //获取FragmentManager实现类的class对象,这里指的就是FragmentManagerImpl
            Class<? extends FragmentManager> aClass = getChildFragmentManager().getClass();
            try {
                //1.获取其mAdded字段
                Field f = aClass.getDeclaredField("mAdded");
                f.setAccessible(true);
                //强转成ArrayList
                ArrayList<Fragment> list = (ArrayList) f.get(getChildFragmentManager());
                //清空缓存
                list.clear();

                //2.获取mActive字段
                f = aClass.getDeclaredField("mActive");
                f.setAccessible(true);
                //强转成SparseArray
                SparseArray<Fragment> array = (SparseArray) f.get(getChildFragmentManager());
                //清空缓存
                array.clear();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void reload() {
        requestData();
    }

    private class MyPagerAdapter extends FragmentPagerAdapter {
        FragmentManager mFragmentManager;

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
            mFragmentManager = fm;
        }

        @Override
        public int getCount() {
            return list_frg.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return listTab.get(position).getCat_name();
        }

        @Override
        public Fragment getItem(int position) {
            return list_frg.get(position);
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }
    }

    private void getTab() {
        Kalle.post(HttpUrl.HOME_TAB)
                .tag(tag)
                .perform(new NormalCallback<List<HomeTab>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<HomeTab>, String> response) {
                        if (response.isSucceed()) {
                            loadedTip.setLoadingTip(LoadingTip.LoadStatus.finish);
                            listTab = response.succeed();
                            if (listTab != null && !listTab.isEmpty()) {
                                list_frg = new ArrayList<>();
                                for (int i = 0; i < listTab.size(); i++) {
                                    list_frg.add(MovieFragment.newInstance(listTab.get(i).getId()));
                                }
                                vp.setAdapter(new MyPagerAdapter(getChildFragmentManager()));
                                layoutTab.setViewPager(vp);
                                vp.setOffscreenPageLimit(list_frg.size());
                                getHot(listTab.get(0).getId());
                            }
                        }
                    }

                    @Override
                    public void onFinnalyException() {
                        loadedTip.setLoadingTip(LoadingTip.LoadStatus.error);
                    }
                });
    }

    private void getHot(int id) {
        Kalle.post(HttpUrl.SEARCH_HOT)
                .param("cat_id", id)
                .perform(new NormalCallback<List<SearchHotInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<SearchHotInfo>, String> response) {
                        if (response.isSucceed()) {
                            List<SearchHotInfo> list = response.succeed();
                            if (list != null && !list.isEmpty()) {
                                tvSearch.setText(list.get(0).getSource_name());
                            }
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_home;
    }
}
