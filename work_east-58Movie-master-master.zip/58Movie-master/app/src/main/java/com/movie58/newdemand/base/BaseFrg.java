package com.movie58.newdemand.base;

public abstract class BaseFrg extends BaseFragment {
}
