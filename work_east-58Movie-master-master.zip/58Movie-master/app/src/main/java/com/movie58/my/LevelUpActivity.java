package com.movie58.my;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.LevelUpInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class LevelUpActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    LevelUpAdapter mAdapter;
    int page = 1;

    @Override
    protected void initView() {
        tvTitle.setText("成长记录");

        mAdapter = new LevelUpAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).colorResId(R.color.line).build());
        mAdapter.bindToRecyclerView(rvList);

        layoutRefresh.autoRefresh();
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    private void getList(){
        Kalle.get(HttpUrl.LEVEL_UP)
                .param("page", page)
                .param("szie", 10)
                .perform(new LoadingCallback<List<LevelUpInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<LevelUpInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initList(List<LevelUpInfo> list){


        if (list == null) {
            list = new ArrayList<>();
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
            layoutRefresh.finishRefresh();
        }else{
            mAdapter.addData(list);
            layoutRefresh.finishLoadMore();
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }


    @OnClick(R.id.iv_back)
    void click(){
        finish();
    }


    @Override
    protected int getLayout() {
        return R.layout.activity_level_up;
    }

    private class LevelUpAdapter extends BaseQuickAdapter<LevelUpInfo, BaseViewHolder>{

        public LevelUpAdapter(@Nullable List<LevelUpInfo> data) {
            super(R.layout.item_level_up, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, LevelUpInfo item) {
            helper.setText(R.id.tv_name, item.getRule_name())
                    .setText(R.id.tv_time, item.getCreate_time())
                    .setText(R.id.tv_up, "+" + item.getExperience_num());
        }
    }
}
