package com.movie58.my;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.bean.FeedbackInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class MsgFeedbackFragment extends BaseFragment {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    int page = 1;

    FeedbackAdapter mAdapter;

    public static MsgFeedbackFragment newInstance() {
        return new MsgFeedbackFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("反馈记录");
        tvRight.setText("我要反馈");

        mAdapter = new FeedbackAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).colorResId(R.color.line)
                .margin(getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_15), 0).build());
        mAdapter.bindToRecyclerView(rvList);


        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    @OnClick({R.id.iv_back, R.id.tv_right})
    void Click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.tv_right:
                startActivity(FeedbackActivity.class);
                break;
        }
    }

    @Override
    protected void initData() {
        layoutRefresh.autoRefresh();
    }

    private void getList(){
        Kalle.get(HttpUrl.MSG_FEEDBACK)
                .param("page", page)
                .param("szie", 10)
                .perform(new LoadingCallback<List<FeedbackInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<FeedbackInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initList(List<FeedbackInfo> list){


        if (list == null) {
            list = new ArrayList<>();
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
            layoutRefresh.finishRefresh();
        }else{
            mAdapter.addData(list);
            layoutRefresh.finishLoadMore();
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_msg_system;
    }

    class FeedbackAdapter extends BaseQuickAdapter<FeedbackInfo, BaseViewHolder> {

        public FeedbackAdapter(@Nullable List<FeedbackInfo> data) {
            super(R.layout.item_feedback, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, FeedbackInfo item) {
            helper.setText(R.id.tv_title, item.getBack_type_name())
                    .setText(R.id.tv_name, TextUtils.isEmpty(item.getSource_name())? "无": item.getSource_name())
                    .setText(R.id.tv_content, item.getBack_content())
                    .setText(R.id.tv_time, item.getCreate_time());
            LinearLayout layout = helper.getView(R.id.layout_reply);
            if (item.getReply_content() != null && !item.getReply_content().isEmpty()) {
                for (int i = 0; i < item.getReply_content().size(); i++){
                    FeedbackInfo.ReplyContentBean info = item.getReply_content().get(i);
                    View view = LayoutInflater.from(getMActivity()).inflate(R.layout.item_feedback_reply, new LinearLayout(getMActivity()));
                    View v = view.findViewById(R.id.v);
                    TextView tvContent = view.findViewById(R.id.tv_content1);
                    TextView tvTime = view.findViewById(R.id.tv_time1);
                    if (i == 0) {
                        v.setVisibility(View.GONE);
                    }else{
                        v.setVisibility(View.VISIBLE);
                    }
                    tvContent.setText(info.getBack_content());
                    tvTime.setText(info.getCreate_time());
                    layout.addView(view);
                }
            }

        }
    }
}
