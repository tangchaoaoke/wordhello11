package com.movie58.newdemand.utils;

public class AppConfigs {

    public static String UUID = "";
}
