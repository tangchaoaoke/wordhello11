package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class SystemInfo {
    /**
     * message_title : 大家注意，最近盗号现象严重
     * message_content : 请大家保管好自己的账号请大家保管好自己的账号请大家保管好自己的账号请大家保管好自己的账号请大家保管好自己的账号请大家保管好自己的账号请大家保管好自己的账号！！！！
     * create_time : 2019-05-23 14:16:43
     */

    private String message_title;
    private String message_content;
    private String create_time;

    public String getMessage_title() {
        return message_title;
    }

    public void setMessage_title(String message_title) {
        this.message_title = message_title;
    }

    public String getMessage_content() {
        return message_content;
    }

    public void setMessage_content(String message_content) {
        this.message_content = message_content;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }
}
