package com.movie58.home;

import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.interfaces.History;
import com.movie58.account.Account;
import com.movie58.adapter.SearchHotAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.SearchHotInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.util.OnDoubleClickListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/4/29 0029.
 */
public class SearchHotFragment extends BaseFragment {

    @BindView(R.id.rv_list)
    RecyclerView rvList;


    //R.layout.item_search_hot

    private History history;
    int intId;

    List<SearchHotInfo> listHot = new ArrayList<>();
    SearchHotAdapter mAdapter;

    public static SearchHotFragment newInstance(int id) {
        SearchHotFragment fragment = new SearchHotFragment();
        Bundle b = new Bundle();
        b.putInt("id", id);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        intId = b.getInt("id");
    }

    @Override
    protected void initView() {
        history = new History();
        mAdapter = new SearchHotAdapter(listHot);
        GridLayoutManager manager = new GridLayoutManager(getActivity(), 2);
        rvList.setLayoutManager(manager);
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                EventBus.getDefault().post(new Event(Event.CODE_05_SCHOOL_TIME_VIDEO).setObj1(mAdapter.getItem(position).getSource_name()));
                if (Account.getInstance().isLogined()){
                    history.b(Account.getInstance().getToken(), mAdapter.getItem(position).getSource_name(), SearchHotFragment.this);
                }
            }
        });
    }

    @Override
    protected void initData() {
        getList();
    }

    private void getList() {
        Kalle.post(HttpUrl.SEARCH_HOT)
                .param("cat_id", intId)
                .perform(new NormalCallback<List<SearchHotInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<SearchHotInfo>, String> response) {
                        if (response.isSucceed()) {
                            listHot = response.succeed();
                            if (listHot != null && !listHot.isEmpty()) {
                                mAdapter.setNewData(listHot);
                            } else {
                                mAdapter.setNewData(null);
                                View view = LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null);
                                mAdapter.setEmptyView(view);
                            }
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_search_hot;
    }
}
