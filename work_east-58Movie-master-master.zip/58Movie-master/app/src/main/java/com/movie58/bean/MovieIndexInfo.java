package com.movie58.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class MovieIndexInfo {
    /**
     * screen_conditions : {"source_area":"area","source_type":"area","source_year":"area","source_habit":"area","update_schedule":"area"}
     * default_list : [{"source_name":"流浪地球1111","source_img":"https://pic.china-gif.com/pic/upload/vod/2019-02/15494025274.jpg","description":"流量地球大片抢先看","pingfen":"2.0","lead_role":"屈楚萧,吴京,李光洁,吴孟达","up_right_text":"66","down_right_text":"77","id":107,"img_link":"/collect/collect/show/id/107.html"}]
     */

    private ScreenConditionsBean screen_conditions;
    private List<MovieListInfo> default_list = new ArrayList<>();

    public ScreenConditionsBean getScreen_conditions() {
        return screen_conditions;
    }

    public void setScreen_conditions(ScreenConditionsBean screen_conditions) {
        this.screen_conditions = screen_conditions;
    }

    public List<MovieListInfo> getDefault_list() {
        return default_list;
    }

    public void setDefault_list(List<MovieListInfo> default_list) {
        this.default_list = default_list;
    }

    public static class ScreenConditionsBean {
        private List<SourceAreaBean> source_area = new ArrayList<>();
        private List<SourceTypeBean> source_type = new ArrayList<>();
        private List<SourceYearBean> source_year = new ArrayList<>();
        private List<SourceHabitBean> source_habit = new ArrayList<>();
        private List<UpdateScheduleBean> update_schedule = new ArrayList<>();

        public List<SourceAreaBean> getSource_area() {
            return source_area;
        }

        public void setSource_area(List<SourceAreaBean> source_area) {
            this.source_area = source_area;
        }

        public List<SourceTypeBean> getSource_type() {
            return source_type;
        }

        public void setSource_type(List<SourceTypeBean> source_type) {
            this.source_type = source_type;
        }

        public List<SourceYearBean> getSource_year() {
            return source_year;
        }

        public void setSource_year(List<SourceYearBean> source_year) {
            this.source_year = source_year;
        }

        public List<SourceHabitBean> getSource_habit() {
            return source_habit;
        }

        public void setSource_habit(List<SourceHabitBean> source_habit) {
            this.source_habit = source_habit;
        }

        public List<UpdateScheduleBean> getUpdate_schedule() {
            return update_schedule;
        }

        public void setUpdate_schedule(List<UpdateScheduleBean> update_schedule) {
            this.update_schedule = update_schedule;
        }

        public static class SourceAreaBean {
            /**
             * area_name : 国产剧
             * id : 1
             */

            private String area_name;
            private String id;

            public String getArea_name() {
                return area_name;
            }

            public void setArea_name(String area_name) {
                this.area_name = area_name;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }

        public static class SourceTypeBean {
            /**
             * type_name : 喜剧
             * id : 1
             */

            private String type_name;
            private String id;

            public String getType_name() {
                return type_name;
            }

            public void setType_name(String type_name) {
                this.type_name = type_name;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }

        public static class SourceYearBean {
            /**
             * year_code : 0
             * year_name : 其他
             */

            private String year_code;
            private String year_name;

            public String getYear_code() {
                return year_code;
            }

            public void setYear_code(String year_code) {
                this.year_code = year_code;
            }

            public String getYear_name() {
                return year_name;
            }

            public void setYear_name(String year_name) {
                this.year_name = year_name;
            }
        }

        public static class SourceHabitBean {
            /**
             * habit_code : most
             * habit_name : 最高播放
             */

            private String habit_code;
            private String habit_name;

            public String getHabit_code() {
                return habit_code;
            }

            public void setHabit_code(String habit_code) {
                this.habit_code = habit_code;
            }

            public String getHabit_name() {
                return habit_name;
            }

            public void setHabit_name(String habit_name) {
                this.habit_name = habit_name;
            }
        }

        public static class UpdateScheduleBean {
            /**
             * schedule_code : 1
             * schedule_name : 已完结
             */

            private String schedule_code;
            private String schedule_name;

            public String getSchedule_code() {
                return schedule_code;
            }

            public void setSchedule_code(String schedule_code) {
                this.schedule_code = schedule_code;
            }

            public String getSchedule_name() {
                return schedule_name;
            }

            public void setSchedule_name(String schedule_name) {
                this.schedule_name = schedule_name;
            }
        }
    }
}
