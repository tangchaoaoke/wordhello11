package com.movie58.bean;

public class QQInfo {
    private String potato_url;
    private String qq;

    public String getPotato_url() {
        return potato_url;
    }

    public void setPotato_url(String potato_url) {
        this.potato_url = potato_url;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }
}
