package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/22 0022.
 */
public class ConvertInfo {
    /**
     * id : 213
     * exchange_code : {75C11DCD-481A-4A65-E86D-EE43C32EAF10}
     * user_id : 8
     * exchange_time : 2019-05-22 11:35:58
     * before_exchange_gold : 0
     * update_time : 1558496158
     * after_exchange_gold : 1
     * exchange_gold : 1
     */

    private int id;
    private String exchange_code;
    private int user_id;
    private String exchange_time;
    private String before_exchange_gold;
    private int update_time;
    private String after_exchange_gold;
    private String exchange_gold;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExchange_code() {
        return exchange_code;
    }

    public void setExchange_code(String exchange_code) {
        this.exchange_code = exchange_code;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getExchange_time() {
        return exchange_time;
    }

    public void setExchange_time(String exchange_time) {
        this.exchange_time = exchange_time;
    }

    public String getBefore_exchange_gold() {
        return before_exchange_gold;
    }

    public void setBefore_exchange_gold(String before_exchange_gold) {
        this.before_exchange_gold = before_exchange_gold;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public String getAfter_exchange_gold() {
        return after_exchange_gold;
    }

    public void setAfter_exchange_gold(String after_exchange_gold) {
        this.after_exchange_gold = after_exchange_gold;
    }

    public String getExchange_gold() {
        return exchange_gold;
    }

    public void setExchange_gold(String exchange_gold) {
        this.exchange_gold = exchange_gold;
    }
}
