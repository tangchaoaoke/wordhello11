package com.movie58.newdemand.base;


import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.utils.ToastUitl;
import com.zhy.autolayout.AutoLayoutActivity;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import butterknife.ButterKnife;

public abstract class BaseActivity extends AutoLayoutActivity implements ApiListener {

    public Context mContext;
    private boolean isTwoBack;
    protected boolean hasAnimiation = true;
    private boolean isVertical = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        doBeforeSetcontentView();
        setContentView(getLayoutId());
        x.view().inject(this);
        mContext = this;
        initPresenter();
        setStatus();
        initDateView();
        initView();
        requestData();
    }

    BasePopupView dialogReview_base;

    public void stopProgressDialog() {
        if (dialogReview_base != null && dialogReview_base.isShow()) {
            dialogReview_base.dismiss();
        }
    }

    public void startProgressDialog() {
        if (dialogReview_base == null) {
            dialogReview_base = new XPopup.Builder(this)
                    .asLoading("加载中...");
        }
        if (dialogReview_base != null && !dialogReview_base.isShow()) {
            dialogReview_base.show();
        }
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        super.setContentView(layoutResID);
        ButterKnife.bind(this);
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        ButterKnife.bind(this);
    }


    public void setIsVertical(boolean isVertical) {
        this.isVertical = isVertical;
    }

    private void doBeforeSetcontentView() {
        AppManager.getInstance().addActivity(this);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (isVertical) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    public void setStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#FF5833"));
//            if (map.get("status_text_color_type").equals("1")) {   //黑色
//                window.getDecorView().setSystemUiVisibility(
//                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//            }
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#FF5833"));
            //底部导航栏
            //window.setNavigationBarColor(activity.getResources().getColor(colorResId));
        }


    }

    public void setStatus(String color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(color));
//            if (map.get("status_text_color_type").equals("1")) {   //黑色
//                window.getDecorView().setSystemUiVisibility(
//                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//            }
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(color));
            //底部导航栏
            //window.setNavigationBarColor(activity.getResources().getColor(colorResId));
        }
    }


    public abstract int getLayoutId();

    public abstract void initPresenter();

    public abstract void initView();

    public void initDateView() {
    }

    public abstract void requestData();

    public void setBackTwo(boolean isTwoBack) {
        this.isTwoBack = isTwoBack;
    }


    public void SetTranslanteBar() {
        fullScreen(this);
    }

    private void fullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                //5.x开始需要把颜色设置透明，否则导航栏会呈现系统默认的浅灰色
                Window window = activity.getWindow();
                View decorView = window.getDecorView();
                //两个 flag 要结合使用，表示让应用的主体内容占用系统状态栏的空间
                int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                decorView.setSystemUiVisibility(option);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                //导航栏颜色也可以正常设置
//                window.setNavigationBarColor(Color.TRANSPARENT);

//                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//                window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
//                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//                window.setStatusBarColor(Color.TRANSPARENT);
            } else {
                Window window = activity.getWindow();
                WindowManager.LayoutParams attributes = window.getAttributes();
                int flagTranslucentStatus = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
                int flagTranslucentNavigation = WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION;
                attributes.flags |= flagTranslucentStatus;
//                attributes.flags |= flagTranslucentNavigation;
                window.setAttributes(attributes);
            }
        }
    }

    public void startActivity(Class<?> cls) {
        startActivity(cls, null);
    }

    public void startActivityForResult(Class<?> cls, int requestCode) {
        startActivityForResult(cls, null, requestCode);
    }

    public void startActivityForResult(Class<?> cls, Bundle bundle,
                                       int requestCode) {
        Intent intent = new Intent();
        intent.setClass(this, cls);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivityForResult(intent, requestCode);
    }

    public void startActivity(Class<?> cls, Bundle bundle) {
        Intent intent = new Intent();
        intent.setClass(this, cls);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);

    }


    public void showShortToast(String text) {
        ToastUitl.showShort(this, text);
    }

    public void showShortToast(int resId) {
        ToastUitl.showShort(this, resId);
    }

    public void showLongToast(int resId) {
        ToastUitl.showLong(this, resId);
    }

    public void showLongToast(String text) {
        ToastUitl.showLong(this, text);
    }


    private long firstTime;

    @Override
    public void onBackPressed() {
        if (isTwoBack) {
            if (System.currentTimeMillis() - firstTime < 3000) {
                hasAnimiation = false;
                AppManager.getInstance().AppExit(this);
                System.exit(0);
            } else {
                firstTime = System.currentTimeMillis();
                showShortToast("再按一次返回桌面");

            }
        } else {
            super.onBackPressed();
        }

    }


    public void startActivity(String s1) {
        Intent intent = new Intent();
        PackageManager packageManager = getPackageManager();
        PackageInfo packageInfo = null;
        try {
            packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        ComponentName comp = new ComponentName(packageInfo.packageName, s1);
        intent.setComponent(comp);
        startActivity(intent);
    }


    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void finish() {
        super.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppManager.getInstance().removeActivity(this);
        if (dialogReview_base != null) {
            dialogReview_base.dismiss();
            dialogReview_base = null;
        }
    }

    @Override
    public void onCancelled(Callback.CancelledException var1) {
    }


    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
    }


    @Override
    public void onError(int error, RequestParams params) {

    }

    @Override
    public void onExceptionType(Throwable var1, RequestParams params, String type) {
        stopProgressDialog();
    }

    protected BaseFragment currentFragment;
    private List<BaseFragment> fragments;


    public void addFragment(Class<?> cls, Object data) {
        FragmentParam param = new FragmentParam();
        param.cls = cls;
        param.data = data;
        param.addToBackStack = false;
        processFragement(param);
    }

    public void addFragment2(Class<?> cls, Object data, String id) {
        FragmentParam param = new FragmentParam();
        param.cls = cls;
        param.data = data;
        param.Id = id;
        param.addToBackStack = false;
        processFragement(param);
    }

    public void addFragment(Class<?> cls, Object data, String tag) {
        FragmentParam param = new FragmentParam();
        param.cls = cls;
        param.data = data;
        param.tag = tag;
        param.addToBackStack = false;
        this.processFragement(param);
    }

    private void processFragement(FragmentParam param) {
        int containerId;
        if (!TextUtils.isEmpty(param.Id)) {
            containerId = getFragmentContainerId2();
        } else {
            containerId = getFragmentContainerId();
        }

        Class cls = param.cls;
        if (cls != null) {
            try {
                String e = getFragmentTag(param);
                BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentByTag(e);
                if (fragment == null) {
                    fragment = (BaseFragment) cls.newInstance();
                }
//              fragment.onComeIn(param.data);
                if (this.currentFragment != null) {
//                  this.currentFragment.onLeave();
                }

                if (this.fragments == null) {
                    this.fragments = new ArrayList();
                }
                addDistinctEntry(this.fragments, fragment);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                if (param.type != FragmentParam.TYPE.ADD) {
                    ft.replace(containerId, fragment, e);
                } else if (!fragment.isAdded()) {
                    ft.add(containerId, fragment, e);
                    if (param.data != null) {
                        fragment.initrefreshData(param.data);
                    }
                } else {
                    Iterator var7 = this.fragments.iterator();
                    while (var7.hasNext()) {
                        BaseFragment lastFragment = (BaseFragment) var7.next();
                        ft.hide(lastFragment);
                    }
                    if (this.currentFragment != null) {
                        this.currentFragment.onPause();
                    }
                    ft.show(fragment);
                    fragment.onResume();
                    if (param.data != null) {
                        fragment.refreshData(param.data);
                    }
                }
                this.currentFragment = fragment;
                if (param.addToBackStack) {
                    ft.addToBackStack(e);
                }
                ft.commitAllowingStateLoss();

            } catch (InstantiationException var9) {
                var9.printStackTrace();
            } catch (IllegalAccessException var10) {
                var10.printStackTrace();
            }
        }
    }

    public static <V> boolean addDistinctEntry(List<V> sourceList, V entry) {
        return (sourceList != null && !sourceList.contains(entry)) && sourceList.add(entry);
    }

    protected int getFragmentContainerId() {
        return 0;
    }

    protected int getFragmentContainerId2() {
        return 0;
    }

//    protected String getFragmentTag(FragmentParam param) {
//        StringBuilder sb = new StringBuilder(param.cls.toString());
//        return sb.toString();
//    }

    protected String getFragmentTag(FragmentParam param) {
        StringBuilder sb = new StringBuilder(param.cls.toString() + param.tag);
        return sb.toString();
    }

}
