package com.movie58.my;

import android.view.View;

import com.chad.library.adapter.base.BaseViewHolder;

/**
 * Created by yangxing on 2019/8/13 0013.
 */
public class DownLoadHolder extends BaseViewHolder {
    int id;

    public DownLoadHolder(View view) {
        super(view);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
