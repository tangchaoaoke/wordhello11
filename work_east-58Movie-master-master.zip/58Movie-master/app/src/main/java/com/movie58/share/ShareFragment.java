package com.movie58.share;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.blankj.utilcode.util.PathUtils;
import com.hjq.toast.ToastUtils;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.bean.ShareBean;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.PermissionUtil;
import com.movie58.util.ToolUtil;
import com.orhanobut.logger.Logger;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yanzhenjie.permission.runtime.Permission;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class ShareFragment extends BaseFragment {

    @BindView(R.id.tv_code)
    TextView tvCode;
    @BindView(R.id.btn)
    Button btn;
    @BindView(R.id.iv_share)
    ImageView ivShare;
    @BindView(R.id.btn_save)
    SuperButton btnSave;
    @BindView(R.id.btn_invite)
    SuperButton btnInvite;
    @BindView(R.id.top)
    LinearLayout layoutTop;
    @BindView(R.id.layout_shot)
    RelativeLayout layoutShot;
    @BindView(R.id.iv_share_bg)
    ImageView ivShareBg;

    boolean topShow = false;

    BasePopupView loadingPopup;
    private boolean compress;
    private ShareBean shareBean;

    public static ShareFragment newInstance(boolean show) {
        ShareFragment fragment = new ShareFragment();
        Bundle b = new Bundle();
        b.putBoolean("show", show);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        topShow = b.getBoolean("show");
    }

    @Override
    protected void initView() {
        getBgInfo();
        if (topShow) {
            layoutTop.setVisibility(View.VISIBLE);
        } else {
            layoutTop.setVisibility(View.GONE);
        }
        loadingPopup = new XPopup.Builder(getMActivity())
                .asLoading("保存中...");
    }


    private void getBgInfo() {
        Kalle.get(HttpUrl.SHARE_INFO)
                .tag(tag)
                .perform(new NormalCallback<ShareBean>() {

                    @Override
                    public void onFinaly(SimpleResponse<ShareBean, String> response) {
                        if (response.isSucceed()) {
                            shareBean = response.succeed();
                            String shareImg = shareBean.getShare_bc_img();
                            PicassoUtils.LoadImageWithDetfult(getActivity(), shareImg, ivShareBg, R.drawable.bg_share);
                            PicassoUtils.LoadImage(getActivity(), shareBean.getShare_qr_img(), ivShare);
                        } else {
                            ivShareBg.setImageResource(R.drawable.bg_share);
                        }
                    }
                });
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();

        if (Account.getInstance().isLogined()) {
            tvCode.setText(Account.getInstance().getInviteCode());
            tvCode.setTextSize(TypedValue.COMPLEX_UNIT_SP, 35);
        } else {
            tvCode.setText("请登录后查看");
            tvCode.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        }

    }

    @OnClick({R.id.btn, R.id.btn_save, R.id.btn_invite, R.id.iv_back})
    void Click(View v) {
        switch (v.getId()) {
            case R.id.btn:
                if (Account.getInstance().isLogined()) {
                    ToolUtil.copy(getMActivity(), tvCode.getText().toString());
                    ToastUtils.show("邀请码已复制到剪切板");
                }
                break;
            case R.id.btn_save:
                new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                    @Override
                    public void onGranted() {
                        loadingPopup.show();
                        layoutShot.setDrawingCacheEnabled(true);
                        layoutShot.buildDrawingCache();
                        Bitmap bitmap = Bitmap.createBitmap(layoutShot.getDrawingCache());
                        String fn = System.currentTimeMillis() + ".png";
                        File f = new File(PathUtils.getExternalDcimPath(), fn);
                        if (f.exists()) {
                            f.delete();
                        }
                        try {
                            OutputStream os = new FileOutputStream(f);
                            compress = bitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
                            os.flush();
                            os.close();
                            save();

                        } catch (Exception e) {
                            Logger.e("TAG", "", e);
                        }
                        getMActivity().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File(f.getAbsolutePath()))));
                    }
                }).showPermission(Permission.Group.STORAGE);
                break;
            case R.id.btn_invite:
                new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                    @Override
                    public void onGranted() {
                        share();
                    }
                }).showPermission(Permission.Group.STORAGE);
                break;
            case R.id.iv_back:
                getMActivity().finish();
                break;
            default:
                break;
        }
    }

    private void save() {
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", 3)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        loadingPopup.dismiss();
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            ToastUtils.show("保存成功，+" + gold + " 金币");
                        } else {

                        }
                    }
                });
    }

    private void share() {
        new ShareAction(getMActivity())
                .setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE, SHARE_MEDIA.SINA)
                .setShareboardclickCallback(new ShareBoardlistener() {
                    @Override
                    public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                        if (shareBean == null || TextUtils.isEmpty(shareBean.getShare_url())) {
                            return;
                        }
                        UMImage image = new UMImage(getMActivity(), R.drawable.erweima);
                        UMWeb web = new UMWeb(shareBean.getShare_url());
                        web.setTitle("58影视，各种大片抢先看");
                        web.setThumb(image);
                        web.setDescription("58影视，各种最新资源，各种热播大片，实时更新，带你一饱眼福");
                        new ShareAction(getMActivity())
                                .setPlatform(share_media)
                                .withMedia(web)
                                .setCallback(new UMShareListener() {
                                    @Override
                                    public void onStart(SHARE_MEDIA share_media) {
                                        Logger.d("33333333333333333333333333");
                                    }

                                    @Override
                                    public void onResult(SHARE_MEDIA share_media) {

                                    }

                                    @Override
                                    public void onError(SHARE_MEDIA share_media, Throwable throwable) {
                                        Logger.d("222222222222222 " + throwable.getMessage());
                                    }

                                    @Override
                                    public void onCancel(SHARE_MEDIA share_media) {

                                    }
                                })
                                .share();
                    }
                }).open();
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_share;
    }
}
