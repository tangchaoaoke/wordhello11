package com.movie58.my;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.CollectInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.yanzhenjie.kalle.FormBody;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/6 0006.
 */
public class FeedbackActivity extends BaseUseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv)
    TextView tv;
    @BindView(R.id.rb_1)
    RadioButton rb1;
    @BindView(R.id.rb_2)
    RadioButton rb2;
    @BindView(R.id.rb_3)
    RadioButton rb3;
    @BindView(R.id.rb_4)
    RadioButton rb4;
    @BindView(R.id.rb_5)
    RadioButton rb5;
    @BindView(R.id.rb_6)
    RadioButton rb6;
    @BindView(R.id.rb_7)
    RadioButton rb7;
    @BindView(R.id.rb_8)
    RadioButton rb8;
    @BindView(R.id.rb_9)
    RadioButton rb9;
    @BindView(R.id.et)
    EditText et;
    @BindView(R.id.et_qq)
    EditText etQq;
    @BindView(R.id.et_email)
    EditText etEmail;

    String tag;

    @Override
    protected void initView() {
        tvTitle.setText("反馈");
        getList();
    }

    private void getList(){
        Kalle.post(HttpUrl.FEEDBACK_LIST)
                .tag(tag)
                .param("page", 1)
                .param("size", 10)
                .perform(new NormalCallback<List<CollectInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<CollectInfo>, String> response) {
                        if (response.isSucceed()) {

                        }else{

                        }
                    }
                });
    }

    @OnClick({R.id.iv_back, R.id.tv})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.tv:
                getTag();
                String content = et.getText().toString().trim();
                if (TextUtils.isEmpty(content)) {
                    ToastUtils.show("请填写详细描述");
                    return;
                }
                submit(content);
                break;
        }
    }

    private void getTag(){
        tag = "";
        if (rb1.isChecked()) {
            tag = tag + "," + rb1.getText();
        }
        if (rb2.isChecked()) {
            tag = tag + "," + rb2.getText();
        }
        if (rb3.isChecked()) {
            tag = tag + "," + rb3.getText();
        }
        if (rb4.isChecked()) {
            tag = tag + "," + rb4.getText();
        }
        if (rb5.isChecked()) {
            tag = tag + "," + rb5.getText();
        }
        if (rb6.isChecked()) {
            tag = tag + "," + rb6.getText();
        }
        if (rb7.isChecked()) {
            tag = tag + "," + rb7.getText();
        }
        if (rb8.isChecked()) {
            tag = tag + "," + rb8.getText();
        }
        if (rb9.isChecked()) {
            tag = tag + "," + rb9.getText();
        }
        if (!TextUtils.isEmpty(tag)) {
            tag = tag.substring(1);
        }
    }

    private void submit(String content){
        FormBody.Builder builder = FormBody.newBuilder();
        builder.param("back_content", content);
        if (!TextUtils.isEmpty(tag)) {
            builder.param("back_type_name", tag);
        }
        String qq = etQq.getText().toString().trim();
        if (!TextUtils.isEmpty(qq)) {
            builder.param("qq", qq);
        }
        String email = etEmail.getText().toString().trim();
        if (!TextUtils.isEmpty(email)) {
            builder.param("email", email);
        }
        Kalle.post(HttpUrl.FEEDBACK)
                .tag(tag)
                .body(builder.build())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("感谢您的反馈，我们已经收到");
                            getMActivity().finish();
                            EventBus.getDefault().post(new Event(Event.CODE_10_SCHOOL_MY_CLICK));
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_feedback;
    }

}
