package com.movie58.account;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.fm.openinstall.OpenInstall;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.bean.LoginInfo;
import com.movie58.bean.UserInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.MD5Util;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class Register2Fragment extends BaseFragment {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.tv_phone)
    TextView tvPhone;
    @BindView(R.id.et_verify)
    EditText etVerify;
    @BindView(R.id.tv_error)
    TextView tvError;
    @BindView(R.id.tv_error1)
    TextView tvError1;
    @BindView(R.id.et_pwd)
    EditText etPwd;
    @BindView(R.id.btn_login)
    SuperButton btnLogin;


    String strPhone, strCode, strPwd;

    public static Register2Fragment newInstance(String phone, String code) {
        Register2Fragment fragment = new Register2Fragment();
        Bundle b = new Bundle();
        b.putString("phone", phone);
        b.putString("code", code);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        strPhone = b.getString("phone");
        strCode = b.getString("code");
    }

    @Override
    protected void initView() {
        tvTitle.setText("欢迎注册");
        tvRight.setText("登录");
        tvPhone.setText(ToolUtil.getPhone(strPhone));

        etVerify.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s.toString().trim())) {

                }else{

                    tvError.setVisibility(View.INVISIBLE);
                }
            }
        });
        etPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s.toString().trim())) {

                }else{

                    tvError1.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    @OnClick({R.id.iv_back, R.id.tv_right, R.id.btn_login})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.tv_right:
                startActivity(LoginActivity.class);
                break;
            case R.id.btn_login:
                String verify  = etVerify.getText().toString().trim();
                if (TextUtils.isEmpty(verify)) {
                    tvError.setText("请输入验证码");
                    tvError.setVisibility(View.VISIBLE);
                    return;
                }
                strPwd = etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(strPwd)) {
                    tvError1.setText("请输入密码");
                    tvError1.setVisibility(View.VISIBLE);
                    return;
                }
                if (!ToolUtil.isPwd(strPwd)) {
                    tvError1.setText("请输入6～12位数字和字母密码");
                    tvError1.setVisibility(View.VISIBLE);
                    return;
                }
                register(verify);
                break;
        }
    }

    private void register(String verify){
        Kalle.post(HttpUrl.REGISTER)
                .tag(tag)
                .param("user_mobile", strPhone)
                .param("invite_code", strCode)
                .param("verification_code", verify)
                .param("password", MD5Util.GetMD5Code(strPwd))
                .param("device_type", "android")
                .perform(new LoadingCallback<LoginInfo>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<LoginInfo, String> response) {
                        if (response.isSucceed()) {
                            UserInfo info = response.succeed().getUser();
                            Account.getInstance().setUserTel(strPhone)
                                    .setToken(response.succeed().getToken())
                                    .setUserId(info.getId())
                                    .setLevel(info.getLevel_name())
                                    .setInviteCode(info.getUser_login());

                            Kalle.getConfig().getHeaders().set("XX-Token", Account.getInstance().getToken());

                            EventBus.getDefault().post(new Event(Event.CODE_48_LOGIN_IN));
                            getMActivity().finish();

                            OpenInstall.reportRegister();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_register2;
    }

}
