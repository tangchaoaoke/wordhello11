package com.movie58.newdemand.database;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 *
 */
@Table(name = "Record")
public class Record {

    //指明字段,主键,是否自增长,约束(不能为空)
    @Column(name = "id", isId = true, autoGen = true, property = "NOT NULL")
    private int id;

    @Column(name = "source_name")
    private String source_name;
    @Column(name = "source_img")
    private String source_img;
    @Column(name = "played_time")
    private String played_time;
    @Column(name = "ids")
    private String ids;
    @Column(name = "total_time")
    private String total_time;

    public int getId() {
        return id;
    }

    public String getTotal_time() {
        return total_time;
    }

    public void setTotal_time(String total_time) {
        this.total_time = total_time;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public String getSource_img() {
        return source_img;
    }

    public void setSource_img(String source_img) {
        this.source_img = source_img;
    }

    public String getPlayed_time() {
        return played_time;
    }

    public void setPlayed_time(String played_time) {
        this.played_time = played_time;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return "Record{" +
                "id=" + id +
                ", source_name='" + source_name + '\'' +
                ", source_img='" + source_img + '\'' +
                ", played_time='" + played_time + '\'' +
                ", ids='" + ids + '\'' +
                ", total_time='" + total_time + '\'' +
                '}';
    }
}
