package com.movie58.newdemand.ui.history


import android.content.Context
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.movie58.App
import com.movie58.R
import com.movie58.newdemand.base.BaseAty
import com.movie58.newdemand.database.Record
import com.movie58.newdemand.utils.ImagesUtils
import com.zhy.autolayout.utils.AutoUtils
import kotlinx.android.synthetic.main.ainclude_top.*
import kotlinx.android.synthetic.main.aty_playrecord_nologin.*
import org.xutils.DbManager
import org.xutils.ex.DbException
import org.xutils.x
import java.util.ArrayList

class PlayRecordNoLoginAty : BaseAty() {

    private var db: DbManager? = null
    private var list: ArrayList<Record>? = null

    override fun getLayoutId(): Int = R.layout.aty_playrecord_nologin

    override fun initPresenter() {}

    override fun initView() {}

    override fun requestData() {}

    private var adapter: GoldRecyclerAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SetTranslanteBar()
        initTopview(relay, relay_top)
        tv_title.text = "播放历史"
        relay_back.setOnClickListener { finish() }
        db = x.getDb((applicationContext as App).daoConfig)
        recyclerview.layoutManager = LinearLayoutManager(this)
        adapter = GoldRecyclerAdapter(this)
        recyclerview.adapter = adapter
        refreshLayout.setEnableRefresh(true)
        refreshLayout.setEnableLoadmore(true)
        refreshLayout.loadMoreReturn()
        selectData()
    }

    inner class GoldRecyclerAdapter(context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        private val inflater: LayoutInflater = LayoutInflater.from(context)
        private var context2 = context
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
                RecyclerView.ViewHolder = fGoldViewHolder(inflater.inflate(R.layout.item_play_history, parent, false))

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            var holder1: fGoldViewHolder = holder as fGoldViewHolder
            ImagesUtils.disImg(context2, list!![position].source_img, holder1.iv_player)
        }

        override fun getItemCount() = if (list == null || list!!.size == 0) 0 else list!!.size
        inner class fGoldViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            var iv_player: ImageView? = null
            init {
                AutoUtils.autoSize(itemView)
                iv_player = itemView.findViewById(R.id.iv_player)
            }
        }
    }


    fun selectData() {
        try {
            list = db?.selector(Record::class.java)?.orderBy("id", true)?.findAll() as ArrayList<Record>
        } catch (e: DbException) {
            e.printStackTrace()
        }
//        for (index in list!!.indices){
//            println(list!![index].toString())//输出0，1，2
//        }
//        Log.e("ddddddddddddd",list!!.size.toString() );
        adapter?.notifyDataSetChanged()
    }
}
