package com.movie58.my;

import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.MD5Util;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/8 0008.
 */
public class ChangePwdFragment1 extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_phone)
    TextView tvPhone;
    @BindView(R.id.et_code)
    EditText etCode;
    @BindView(R.id.btn_verify)
    SuperButton btnVerify;
    @BindView(R.id.et_pwd)
    EditText etPwd;
    @BindView(R.id.iv_see)
    ImageView ivSee;
    @BindView(R.id.btn_reset)
    SuperButton btnReset;


    public static ChangePwdFragment1 newInstance() {
        return new ChangePwdFragment1();
    }

    @Override
    protected void initView() {
        tvTitle.setText("修改密码");
        tvPhone.setText(ToolUtil.getPhone(Account.getInstance().getUserTel()));
    }

    @OnClick({R.id.iv_back, R.id.iv_see, R.id.btn_verify, R.id.btn_reset})
    void click(View v){
        hideSoftInput();
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.iv_see:
                if (etPwd.getInputType() == InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                    etPwd.setInputType(InputType.TYPE_CLASS_TEXT);
                }else{
                    etPwd.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
                break;
            case R.id.btn_verify:
                getCode(Account.getInstance().getUserTel());
                break;
            case R.id.btn_reset:
                String verify  = etCode.getText().toString().trim();
                if (TextUtils.isEmpty(verify)) {
                    ToastUtils.show("请输入验证码");
                    return;
                }
                String strPwd = etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(strPwd)) {
                    ToastUtils.show("请输入密码");
                    return;
                }
                if (!ToolUtil.isPwd(strPwd)) {
                    ToastUtils.show("请输入6～12位数字和字母密码");
                    return;
                }
                changePwd(verify, strPwd);
                break;
        }
    }

    private void getCode(String phone){
        Kalle.get(HttpUrl.VERIFY_CODE)
                .tag(tag)
                .param("user_mobile", phone)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToolUtil.countDown(btnVerify, 60000, 1000, "获取验证码");
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void changePwd(String code, String pwd){
        Kalle.get(HttpUrl.CHANGE_PWD)
                .tag(tag)
                .param("user_mobile", Account.getInstance().getUserTel())
                .param("password", MD5Util.GetMD5Code(pwd))
                .param("verification_code", code)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("密码修改成功！");
                            popTo(SafeCenterFragment.class, false);
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_change_pwd1;
    }

}
