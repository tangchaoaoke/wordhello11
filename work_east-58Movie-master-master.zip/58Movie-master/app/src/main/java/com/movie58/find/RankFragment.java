package com.movie58.find;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;

import com.flyco.tablayout.SegmentTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseFragment;
import com.movie58.bean.HomeTab;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.view.NoMoveViewPager;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/4/26 0026.
 */
public class RankFragment extends BaseFragment {

    @BindView(R.id.layout_tab2)
    SegmentTabLayout layoutTab;
    @BindView(R.id.vp2)
    NoMoveViewPager vp;

    private String[] mTitles ;
    List<HomeTab> listTab = new ArrayList<>();


    public static RankFragment newInstance() {
        return new RankFragment();
    }

    @Override
    protected void initView() {

        getTab();
        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                vp.setCurrentItem(position);
            }

            @Override
            public void onTabReselect(int position) {
            }
        });

        vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                layoutTab.setCurrentTab(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private class MyPagerAdapter extends FragmentPagerAdapter {
        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return listTab.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mTitles[position];
        }

        @Override
        public Fragment getItem(int position) {
            return RankItemFragment.newInstance(listTab.get(position).getId());
        }
    }


    private void getTab(){
        Kalle.post(HttpUrl.HOME_TAB)
                .tag(tag)
                .perform(new NormalCallback<List<HomeTab>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<HomeTab>, String> response) {
                        if (response.isSucceed()) {
                            List<HomeTab> list = response.succeed();
                            if (list != null && !list.isEmpty()) {
                                listTab.clear();
                                for (HomeTab tab : list){
                                    if (!"推荐".equals(tab.getCat_name()) && !"解说".equals(tab.getCat_name())) {
                                        listTab.add(tab);
                                    }
                                }
                                mTitles = new String[listTab.size()];
                                for(int i = 0; i< listTab.size(); i++){
                                    mTitles[i] = listTab.get(i).getCat_name();
                                }
                                vp.setAdapter(new MyPagerAdapter(getFragmentManager()));
                                layoutTab.setTabData(mTitles);
                            }
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_rank;
    }

}
