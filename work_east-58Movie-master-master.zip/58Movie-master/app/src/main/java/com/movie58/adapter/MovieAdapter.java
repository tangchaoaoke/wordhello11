package com.movie58.adapter;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.bigkoo.convenientbanner.ConvenientBanner;
import com.bigkoo.convenientbanner.holder.CBViewHolderCreator;
import com.cbman.roundimageview.RoundImageView;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.HomeListInfo;
import com.movie58.event.Event;
import com.movie58.img.PicassoUtils;
import com.movie58.util.OnDoubleClickListener;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangxing on 2019/5/10 0010.
 */
public class MovieAdapter extends BaseMultiItemQuickAdapter<HomeListInfo, BaseViewHolder> {

    public final static int TYPE_1 = 1;
    public final static int TYPE_2 = 2;
    public final static int TYPE_3 = 3;
    public final static int TYPE_4 = 4;
    public final static int TYPE_5 = 5;
    public final static int TYPE_6 = 6;
    public final static int TYPE_7 = 7;
    public final static int TYPE_CENTER = 8;
    public final static int TYPE_BANNER = 9;

    int catId;


    public MovieAdapter(List<HomeListInfo> data, int catId) {
        super(data);
        this.catId = catId;
        addItemType(TYPE_1, R.layout.item_movie_list_1);//单图
        addItemType(TYPE_2, R.layout.item_movie_list_2);//两列图
        addItemType(TYPE_3, R.layout.item_movie_list_3);//三列图
        addItemType(TYPE_4, R.layout.item_movie_list_4);//三列图
        addItemType(TYPE_5, R.layout.item_movie_list_5);//单图+两列图
        addItemType(TYPE_6, R.layout.item_movie_list_6);//三列图
        addItemType(TYPE_7, R.layout.item_movie_list_7);//单图+两列图
        addItemType(TYPE_CENTER, R.layout.item_movie_center);
        addItemType(TYPE_BANNER, R.layout.item_movie_banner);
    }

    @Override
    protected void convert(BaseViewHolder helper, HomeListInfo item) {
        switch (helper.getItemViewType()) {
            case TYPE_1: {
                helper.setText(R.id.tv_title, item.getParams().getTitle());
                helper.setVisible(R.id.tv_refresh, false)
                        .setVisible(R.id.tv_more, false);
                initBig(helper, item);
            }
            break;
            case TYPE_2:
            case TYPE_3:
            case TYPE_4:
            case TYPE_6: {
                helper.setText(R.id.tv_title, item.getParams().getTitle());
                helper.setVisible(R.id.tv_refresh, true)
                        .setVisible(R.id.tv_more, true)
                        .addOnClickListener(R.id.tv_refresh)
                        .addOnClickListener(R.id.tv_more);
                initSmall(helper, item);
            }
            break;
            case TYPE_5:
            case TYPE_7: {
                helper.setText(R.id.tv_title, item.getParams().getTitle());
                helper.setVisible(R.id.tv_refresh, true)
                        .setVisible(R.id.tv_more, true)
                        .addOnClickListener(R.id.tv_refresh)
                        .addOnClickListener(R.id.tv_more);
                initBig(helper, item);
                initSmall(helper, item);
            }
            break;
            case TYPE_BANNER: {
                ConvenientBanner banner = helper.getView(R.id.layout_banner);
                banner.setPages(new CBViewHolderCreator() {
                    @Override
                    public BannerImgHolder createHolder(View itemView) {
                        return new BannerImgHolder(mContext, itemView);
                    }

                    @Override
                    public int getLayoutId() {
                        return R.layout.item_banner_image;
                    }
                }, item.getParams().getList())
                        .setPageIndicator(new int[]{R.drawable.ic_page_indicator, R.drawable.ic_page_indicator_focused})
                        .setPageIndicatorAlign(ConvenientBanner.PageIndicatorAlign.ALIGN_PARENT_RIGHT)
                        .setOnItemClickListener(new com.bigkoo.convenientbanner.listener.OnItemClickListener() {
                            @Override
                            public void onItemClick(int position) {
                                EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(item.getParams().getList().get(position)));
                            }
                        });
                banner.startTurning();
            }
            break;
            case TYPE_CENTER: {
                int size = item.getParams().getList().size();
                switch (size) {
                    case 0: {
                        helper.setGone(R.id.layout_1, false)
                                .setGone(R.id.layout_2, false)
                                .setGone(R.id.layout_3, false)
                                .setGone(R.id.layout_4, false);

                    }
                    break;
                    case 1: {
                        helper.setGone(R.id.layout_1, true)
                                .setGone(R.id.layout_2, false)
                                .setGone(R.id.layout_3, false)
                                .setGone(R.id.layout_4, false)
                                .setText(R.id.tv_1, item.getParams().getList().get(0).getImg_title());
                        RoundImageView iv1 = helper.getView(R.id.iv_1);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(0).getImg_url(), iv1, R.drawable.pic_emptypage_failure);

                    }
                    break;
                    case 2: {
                        helper.setGone(R.id.layout_1, true)
                                .setGone(R.id.layout_2, true)
                                .setGone(R.id.layout_3, false)
                                .setGone(R.id.layout_4, false)
                                .setText(R.id.tv_1, item.getParams().getList().get(0).getImg_title())
                                .setText(R.id.tv_2, item.getParams().getList().get(1).getImg_title());
                        RoundImageView iv1 = helper.getView(R.id.iv_1);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(0).getImg_url(), iv1, R.drawable.pic_emptypage_failure);
                        RoundImageView iv2 = helper.getView(R.id.iv_2);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(1).getImg_url(), iv2, R.drawable.pic_emptypage_failure);
                    }
                    break;
                    case 3: {
                        helper.setGone(R.id.layout_1, true)
                                .setGone(R.id.layout_2, true)
                                .setGone(R.id.layout_3, true)
                                .setGone(R.id.layout_4, false)
                                .setText(R.id.tv_1, item.getParams().getList().get(0).getImg_title())
                                .setText(R.id.tv_2, item.getParams().getList().get(1).getImg_title())
                                .setText(R.id.tv_3, item.getParams().getList().get(2).getImg_title());
                        RoundImageView iv1 = helper.getView(R.id.iv_1);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(0).getImg_url(), iv1, R.drawable.pic_emptypage_failure);
                        RoundImageView iv2 = helper.getView(R.id.iv_2);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(1).getImg_url(), iv2, R.drawable.pic_emptypage_failure);
                        RoundImageView iv3 = helper.getView(R.id.iv_3);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(2).getImg_url(), iv3, R.drawable.pic_emptypage_failure);
                    }
                    break;
                    default: {
                        helper.setGone(R.id.layout_1, true)
                                .setGone(R.id.layout_2, true)
                                .setGone(R.id.layout_3, true)
                                .setGone(R.id.layout_4, true)
                                .setText(R.id.tv_1, item.getParams().getList().get(0).getImg_title())
                                .setText(R.id.tv_2, item.getParams().getList().get(1).getImg_title())
                                .setText(R.id.tv_3, item.getParams().getList().get(2).getImg_title())
                                .setText(R.id.tv_4, item.getParams().getList().get(3).getImg_title());
                        RoundImageView iv1 = helper.getView(R.id.iv_1);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(0).getImg_url(), iv1, R.drawable.pic_emptypage_failure);
                        RoundImageView iv2 = helper.getView(R.id.iv_2);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(1).getImg_url(), iv2, R.drawable.pic_emptypage_failure);
                        RoundImageView iv3 = helper.getView(R.id.iv_3);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(2).getImg_url(), iv3, R.drawable.pic_emptypage_failure);
                        RoundImageView iv4 = helper.getView(R.id.iv_4);
                        PicassoUtils.LoadImageWithDetfult(mContext, item.getParams().getList().get(3).getImg_url(), iv4, R.drawable.pic_emptypage_failure);
                    }
                    break;
                }
                helper.setOnClickListener(R.id.layout_1, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                        EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(item.getParams().getList().get(0)));
                    }
                });
                helper.setOnClickListener(R.id.layout_2, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                        EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(item.getParams().getList().get(1)));
                    }
                });
                helper.setOnClickListener(R.id.layout_3, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                        EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(item.getParams().getList().get(2)));
                    }
                });
                helper.setOnClickListener(R.id.layout_4, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                        EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(item.getParams().getList().get(3)));
                    }
                });
            }
            break;
        }
    }


    private void initBig(BaseViewHolder helper, HomeListInfo item) {
        if (item.getParams().getList().isEmpty()) {
            return;
        }
        HomeListInfo.ParamsBean.ListBean bean = item.getParams().getList().get(0);
        ImageView ivImg = helper.getView(R.id.iv_big);
        PicassoUtils.LoadImageWithDetfult(mContext, bean.getImg_url(), ivImg, R.drawable.pic_emptypage_failure);
        if (TextUtils.isEmpty(bean.getUp_right_text())) {
            helper.setGone(R.id.tv_tag, false);
        } else {
            helper.setVisible(R.id.tv_tag, true);
            helper.setText(R.id.tv_tag, bean.getUp_right_text());
            if (TextUtils.isEmpty(bean.getDown_right_text())) {
                helper.setGone(R.id.tv_big_bottom, false);
            } else {
                helper.setVisible(R.id.tv_big_bottom, true);
                helper.setText(R.id.tv_big_bottom, bean.getDown_right_text())
                        .setTextColor(R.id.tv_big_bottom, mContext.getResources().getColor(R.color.color_ff5722));
            }
        }
        helper.setText(R.id.tv_big_title, bean.getVod_name())
                .setText(R.id.tv_big_content, bean.getDescription());
        helper.setOnClickListener(R.id.iv_big, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(bean));
            }
        });
    }

    private void initSmall(BaseViewHolder helper, HomeListInfo item) {
        List<HomeListInfo.ParamsBean.ListBean> list = new ArrayList<>();
        int count = 2;
        switch (helper.getItemViewType()) {
            case TYPE_2:
                count = 2;
                list.addAll(item.getParams().getList());
                break;
            case TYPE_3:
                count = 3;
                list.addAll(item.getParams().getList());
                break;
            case TYPE_4:
                count = 2;
                list.addAll(item.getParams().getList());
                break;
            case TYPE_6:
                count = 3;
                list.addAll(item.getParams().getList());
                break;
            case TYPE_5:
                count = 2;
                if (item.getParams().getList().size() > 1) {
                    list.addAll(item.getParams().getList().subList(1, item.getParams().getList().size()));
                }
                break;
            case TYPE_7:
                count = 3;
                if (item.getParams().getList().size() > 1) {
                    list.addAll(item.getParams().getList().subList(1, item.getParams().getList().size()));
                }
                break;
        }
        if (list != null && !list.isEmpty()) {
            RecyclerView rv = helper.getView(R.id.rv);
            MovieListItemAdapter adapter = new MovieListItemAdapter(list, helper.getItemViewType());
            rv.setLayoutManager(new GridLayoutManager(mContext, count));
            adapter.bindToRecyclerView(rv);
            adapter.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                    if (OnDoubleClickListener.CanClick.NoClick()) return;
                    EventBus.getDefault().post(new Event(Event.CODE_06_SCHOOL_PROFRESS).setObj1(catId).setObj2(list.get(position)));
                }
            });
        }

    }
}
