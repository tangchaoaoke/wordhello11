package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class GoldInfo {
    /**
     * rule_name : 兑换码兑换
     * gold_num : 1
     * create_time : 2019-05-22 13:43:04
     */

    private String rule_name;
    private int gold_num;
    private String create_time;

    public String getRule_name() {
        return rule_name;
    }

    public void setRule_name(String rule_name) {
        this.rule_name = rule_name;
    }

    public int getGold_num() {
        return gold_num;
    }

    public void setGold_num(int gold_num) {
        this.gold_num = gold_num;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }
}
