package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.FindHotInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class HotAdapter extends BaseQuickAdapter<FindHotInfo, BaseViewHolder> {

    public HotAdapter(@Nullable List<FindHotInfo> data) {
        super(R.layout.item_find_hot, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, FindHotInfo item) {
        helper.setText(R.id.tv_title, item.getProject_name())
                .setText(R.id.tv_time, item.getCreate_time());
        ImageView ivImg = helper.getView(R.id.iv_img);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getProject_banner(), ivImg, R.drawable.pic_emptypage_failure);
        helper.addOnClickListener(R.id.iv_share);
    }
}
