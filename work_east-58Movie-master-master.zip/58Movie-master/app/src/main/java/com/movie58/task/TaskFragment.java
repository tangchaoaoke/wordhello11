package com.movie58.task;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.account.LoginActivity;
import com.movie58.adapter.RuleAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.RuleBean;
import com.movie58.bean.ShareBean;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.share.ShareActivity;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.PermissionUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.orhanobut.logger.Logger;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yanzhenjie.permission.runtime.Permission;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;
import com.zhy.autolayout.utils.AutoUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class TaskFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.layout_invite)
    LinearLayout layoutInvite;
    @BindView(R.id.layout_convert)
    LinearLayout layoutConvert;
    @BindView(R.id.tv_ren)
    TextView tvRen;
    @BindView(R.id.tv_bi)
    TextView tvBi;
    @BindView(R.id.tv_tian)
    TextView tvTian;
    @BindView(R.id.rv_rule)
    RecyclerView rvRule;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.relay)
    RelativeLayout relay;
    RuleAdapter mAdapter;
    RuleBean ruleBean;

    public static TaskFragment newInstance() {
        return new TaskFragment();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initTopview(relay, relay_top, AutoUtils.getPercentHeightSize(440));

    }

    @Override
    protected void initView() {
        tvTitle.setText("任务");

        mAdapter = new RuleAdapter(new ArrayList<>());
        rvRule.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvRule.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).build());

        mAdapter.bindToRecyclerView(rvRule);

        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                if (!Account.getInstance().isLogined()) {
                    startActivity(LoginActivity.class);
                    ToastUtils.show("请先登录");
                    return;
                }
                RuleBean.RuleListBean bean = mAdapter.getItem(position);
                if (view.getId() == R.id.btn) {

//                    "id":1,"rule_name":"邀请用户注册"
//                    "id":2,"rule_name":"每日签到"
//                    "id":3,"rule_name":"保存官网地址"
//                    "id":4,"rule_name":"点击广告"
//                    "id":5,"rule_name":"观影满30分钟"
//                    "id":6,"rule_name":"分享专题"
//                    "id":7,"rule_name":"分享影片到微信"
//                    "id":8,"rule_name":"分享影片到QQ"
//                    "id":9,"rule_name":"分享影片到微博"

                    switch (bean.getId()) {
                        case 1:
                        case 3:
                            startActivity(ShareActivity.class);
                            break;
                        case 2:
                            Sign(bean.getId(), bean.getGold_num());
                            break;
                        case 4:
                        case 5:
                            EventBus.getDefault().post(new Event(Event.CODE_01_TAB_HOME));
                            break;
                        case 6:
                            EventBus.getDefault().post(new Event(Event.CODE_16_MIAN_APPLICATION));
                            break;
                        case 7:
                            new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                                @Override
                                public void onGranted() {
                                    getShareInfo(7);
                                }
                            }).showPermission(Permission.Group.STORAGE);
                            break;
                        case 8:
                            new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                                @Override
                                public void onGranted() {
                                    getShareInfo(8);
                                }
                            }).showPermission(Permission.Group.STORAGE);
                            break;
                        case 9:
                            new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                                @Override
                                public void onGranted() {
                                    getShareInfo(9);
                                }
                            }).showPermission(Permission.Group.STORAGE);
                            break;
                    }

                }
            }
        });
    }

    private void getShareInfo(int i) {
        Kalle.get(HttpUrl.SHARE_INFO)
                .tag(tag)
                .perform(new LoadingCallback<ShareBean>(getActivity()) {

                    @Override
                    public void onFinaly(SimpleResponse<ShareBean, String> response) {
                        if (response.isSucceed()) {
                            ShareBean shareBean = response.succeed();
                            if (shareBean == null || TextUtils.isEmpty(shareBean.getShare_url())) {
                                ToastUtils.show("获取分享地址失败");
                                return;
                            }
                            share(shareBean.getShare_url(), i);
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @OnClick({ R.id.layout_invite, R.id.layout_convert, R.id.layout_ren, R.id.layout_bi})
    void click(View v) {
        switch (v.getId()) {
//            case R.id.iv_back:
//                EventBus.getDefault().post(new Event(Event.CODE_01_TAB_HOME));
//                break;
            case R.id.layout_invite: {
                if (ruleBean == null) {
                    return;
                }
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("count", ruleBean.getInvite_count());
                startActivity(InviteListActivity.class, map);
            }
            break;
            case R.id.layout_convert:
                if (Account.getInstance().isLogined()) {
                    startActivity(ConvertListActivity.class);
                } else {
                    ToastUtils.show("请先登录");
                }
                break;
            case R.id.layout_ren: {
                if (ruleBean == null) {
                    return;
                }
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("count", ruleBean.getInvite_count());
                startActivity(InviteListActivity.class, map);
            }
            break;
            case R.id.layout_bi: {
                startActivity(JinbiActivity.class);
            }
            break;

        }
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        getRule();
    }

    private void getRule() {
        Kalle.get(HttpUrl.RULE_INDEX)
                .perform(new NormalCallback<RuleBean>() {
                    @Override
                    public void onFinaly(SimpleResponse<RuleBean, String> response) {
                        if (response.isSucceed()) {
                            ruleBean = response.succeed();
                            if (ruleBean == null) {
                                return;
                            }
                            tvRen.setText(ruleBean.getInvite_count() + "");
                            tvBi.setText(ruleBean.getGold_num() + "");
                            tvTian.setText(ruleBean.getContinuous_count() + "");
                            initList(ruleBean.getRule_list());
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    private void initList(List<RuleBean.RuleListBean> list) {
        if (list == null) {
            list = new ArrayList<>();
        }
        if (list.isEmpty()) {
            mAdapter.setNewData(null);
        } else {
            mAdapter.setNewData(list);
        }
    }

    private void Sign(int id, int bi) {
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            getRule();
                            ToastUtils.show("签到成功，+" + bi + " 金币");
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void share(String share_url, int type) {
        ShareAction action = new ShareAction(getMActivity());
        if (type == 7) {
            action.setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE);
        } else if (type == 8) {
            action.setDisplayList(SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE);
        } else {
            action.setDisplayList(SHARE_MEDIA.SINA);
        }
        action.setShareboardclickCallback(new ShareBoardlistener() {
            @Override
            public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                UMImage image = new UMImage(getMActivity(), R.drawable.erweima);
                UMWeb web = new UMWeb(share_url);
                web.setTitle("58影视，各种大片抢先看");
                web.setThumb(image);
                web.setDescription("58影视，各种最新资源，各种热播大片，实时更新，带你一饱眼福");
                new ShareAction(getMActivity())
                        .setPlatform(share_media)
                        .withMedia(web)
                        .setCallback(new UMShareListener() {
                            @Override
                            public void onStart(SHARE_MEDIA share_media) {
                                Logger.d("33333333333333333333333333");
                            }

                            @Override
                            public void onResult(SHARE_MEDIA share_media) {
                                if (share_media == SHARE_MEDIA.WEIXIN || share_media == SHARE_MEDIA.WEIXIN_CIRCLE) {
                                    save(7);
                                } else if (share_media == SHARE_MEDIA.QQ || share_media == SHARE_MEDIA.QZONE) {
                                    save(8);
                                } else {
                                    save(9);
                                }
                            }

                            @Override
                            public void onError(SHARE_MEDIA share_media, Throwable throwable) {
                                Logger.d("222222222222222 " + throwable.getMessage());
                            }

                            @Override
                            public void onCancel(SHARE_MEDIA share_media) {

                            }
                        })
                        .share();
            }
        }).open();
    }

    private void save(int id) {
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            ToastUtils.show("分享成功，+" + gold + " 金币");
                            getRule();
                        } else {

                        }
                    }
                });
    }


    @Override
    protected int getLayout() {
        return R.layout.fragment_task;
    }

}
