package com.movie58.util;

import android.text.TextUtils;
import android.util.Log;

import com.movie58.BuildConfig;


/**
 * Log工具类
 */
public class LogUtil {
    private static final String TAG = "PRETTY_LOGGER";


    private static final boolean isLog = BuildConfig.DEBUG;

    public static void d(String message) {
        if (isLog) {
            if (!TextUtils.isEmpty(message)){
                if(message.length() > 3000){
                    int count = message.length() / 3000;
                    for (int i = 0; i <= count; i++) {
                        int max = 3000 * (i + 1);
                        if (max >= message.length()) {
                            Log.d(TAG, i + "/" + count + ": " + message.substring(3000 * i));
                        } else {
                            Log.d(TAG, i + "/" + count + ": " + message.substring(3000 * i, max));
                        }
                    }
                }else{
                    Log.d(TAG, message);
                }
            }else{

            }
        }
    }

}
