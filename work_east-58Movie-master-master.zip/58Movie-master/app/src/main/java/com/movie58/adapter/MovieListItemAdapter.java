package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.blankj.utilcode.util.ScreenUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.HomeListInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

import static com.movie58.adapter.MovieAdapter.TYPE_2;
import static com.movie58.adapter.MovieAdapter.TYPE_3;
import static com.movie58.adapter.MovieAdapter.TYPE_4;
import static com.movie58.adapter.MovieAdapter.TYPE_5;
import static com.movie58.adapter.MovieAdapter.TYPE_6;
import static com.movie58.adapter.MovieAdapter.TYPE_7;

/**
 * Created by yangxing on 2019/5/10 0010.
 */
public class MovieListItemAdapter extends BaseQuickAdapter<HomeListInfo.ParamsBean.ListBean, BaseViewHolder> {

    private int type;

    public MovieListItemAdapter(@Nullable List<HomeListInfo.ParamsBean.ListBean> data, int type) {
        super(R.layout.include_list_xiao, data);
        this.type = type;
    }

    @Override
    protected void convert(BaseViewHolder helper, HomeListInfo.ParamsBean.ListBean item) {
        int margin = mContext.getResources().getDimensionPixelOffset(R.dimen.dp_6);
        int widthPix = ScreenUtils.getScreenWidth();
        int width;
        int height = 0;
        RelativeLayout.LayoutParams params = null;
        switch (type) {
            case TYPE_2://横排2张
            case TYPE_4:
            case TYPE_5:{
                width = (widthPix - (margin * 1)) / 2;
                height = width / 3 * 2;
                params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
                int mo = helper.getLayoutPosition() % 2;
                if (mo == 0) {
                    params.leftMargin = 0;
                    params.rightMargin = margin / 2;
                } else if (mo == 1) {
                    params.leftMargin = margin / 2;
                    params.rightMargin = 0;
                }
            }
                break;
            case TYPE_3://竖排三张
            case TYPE_6:
            case TYPE_7:{
                width = (widthPix - (margin * 2)) / 3;
                height = width / 2 * 3;
                params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
                int mo = helper.getLayoutPosition() % 3;
                if (mo == 0) {
                    params.leftMargin = 0;
                    params.rightMargin = margin / 2;
                } else if (mo == 1) {
                    params.leftMargin = margin / 2;
                    params.rightMargin = margin / 2;
                } else {
                    params.leftMargin = margin / 2;
                    params.rightMargin = 0;
                }
            }
                break;
        }

        ImageView ivImg = helper.getView(R.id.iv_small);
        ivImg.setLayoutParams(params);
        helper.itemView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        PicassoUtils.LoadImageWithDetfult(mContext, item.getImg_url(), ivImg, R.drawable.pic_emptypage_failure);

        if (TextUtils.isEmpty(item.getUp_right_text())) {
            helper.setGone(R.id.tv_tag, false);
        } else {
            helper.setVisible(R.id.tv_tag,true);
            helper.setText(R.id.tv_tag, item.getUp_right_text());
        }
        helper.setText(R.id.tv_small_title, item.getVod_name())
                .setText(R.id.tv_small_content, item.getDescription());
        if (TextUtils.isEmpty(item.getDown_right_text())) {
            helper.setGone(R.id.tv_small_bottom, false);
        } else {
            helper.setVisible(R.id.tv_small_bottom, true);
            helper.setText(R.id.tv_small_bottom, item.getDown_right_text())
                    .setTextColor(R.id.tv_small_bottom, mContext.getResources().getColor(R.color.color_ff5722));
        }
    }
}
