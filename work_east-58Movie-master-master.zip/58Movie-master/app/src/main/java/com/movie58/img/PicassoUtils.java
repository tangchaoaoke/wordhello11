package com.movie58.img;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.widget.ImageView;

import com.movie58.App;
import com.movie58.BuildConfig;
import com.movie58.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.squareup.picasso.Transformation;

/**
 * picasso 图片处理工具类<BR/>
 * 优缺点：对图片处理强大，取消已经不在视野范围的ImageView图片资源的加载（否则会导致图片错位），
 * 使用4.0+系统上的HTTP缓存来代替磁盘缓存；只能得到结果，不能监听图片下载过程
 * <BR/> Picasso 可以与okhttp搭配
 */
public class PicassoUtils {

    DownLoadListener downLoadListener;
    LoadListener loadListener;

    public static void initPicasso(){
        Picasso picasso = new Picasso.Builder(App.getContext())
                .downloader(new OkHttp3Downloader(App.getContext()))//图片存放位置
                .defaultBitmapConfig(Bitmap.Config.RGB_565)
                .loggingEnabled(BuildConfig.DEBUG)
                //默认图片质量，优先RGB_565,   RGB_8888
                .build();
        try {
            Picasso.setSingletonInstance(picasso);
        } catch (IllegalStateException e){
            e.printStackTrace();
        }
    }

    /****
     * 图片加载成功过后在显示图片
     * @param context
     * @param path
     * @param imageView
     * @param listener
     */
    public static void LoadImageCallBack(Context context, String path, final ImageView imageView, LoadListener listener) {
        Picasso.with(context)
                .load(path)
                .into(imageView, new Callback() {
                    @Override
                    public void onSuccess() {
                        if (listener != null) {
                            listener.LoadSuc();
                        }
                    }

                    @Override
                    public void onError() {
                        if (listener != null) {
                            listener.LoadFail();
                        }
                    }
                });
    }


    public static void LoadImage(Context context, String path, ImageView imageView) {
        if (path != null && !path.equals("")) {
            Picasso.with(context).load(path).error(R.mipmap.ic_launcher).into(imageView);
        } else {
            imageView.setImageResource(R.mipmap.ic_launcher);
        }
    }

    public static void LoadImageWithDetfult(Context context, String path, ImageView imageView, int defaultId) {
        if (!TextUtils.isEmpty(path)) {
            Picasso.with(context).load(path).placeholder(defaultId).error(defaultId).into(imageView);
        } else {
            imageView.setImageResource(defaultId);
        }
    }
    public static void LoadImageWithErrorDetfult(Context context, String path, ImageView imageView, int defaultId) {
        if (!TextUtils.isEmpty(path)) {
            Picasso.with(context).load(path).error(defaultId).into(imageView);
        } else {
            imageView.setImageResource(defaultId);
        }
    }


    public static void downLoadImg(Context ctx, String imgurl, DownLoadListener listener){
        Target target = new Target(){
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                try {
                    listener.DownLoadSuc(bitmap);
                } catch (Exception e) {
                    e.printStackTrace();
                    listener.DownLoadFail();
                }
            }

            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
                listener.DownLoadFail();
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {

            }
        };
        Picasso.with(ctx).load(imgurl).into(target);
    }

    public interface DownLoadListener {
        void DownLoadSuc(Bitmap bitmap);
        void DownLoadFail();
    }

    public void setDownLoadListener(DownLoadListener listener) {
        this.downLoadListener = listener;
    }

    public interface LoadListener {
        void LoadSuc();
        void LoadFail();
    }

    public void setDownLoadListener(LoadListener listener) {
        this.loadListener = listener;
    }

    /**
     * 加载图片（圆形）
     *
     * @param context
     * @param url
     * @param imageView
     */
    public static void LoadCircleImageDefalut(Context context, String url, ImageView imageView, int defaultid) {
        if (!TextUtils.isEmpty(url)) {
            Picasso.with(context).load(url).placeholder(defaultid).error(defaultid).transform(new CircleTransform()).into(imageView);
        } else {
            imageView.setImageResource(defaultid);
        }

    }

    /**
     * 加载图片（圆角）
     *
     * @param context
     * @param url
     * @param imageView
     */
    public static void LoadRoundImageDefalut(Context context, String url, ImageView imageView, int defaultid) {
        if (!TextUtils.isEmpty(url)) {
            Picasso.with(context).load(url).placeholder(defaultid).error(defaultid).transform(new RoundTransform(3)).into(imageView);
        } else {
            imageView.setImageResource(defaultid);
        }

    }

    //--------------------------------------------------

    /**
     * 设置圆形图片
     */
    public static class CircleTransform implements Transformation {
        @Override
        public Bitmap transform(Bitmap source) {
            int size = Math.min(source.getWidth(), source.getHeight());

            int x = (source.getWidth() - size) / 2;
            int y = (source.getHeight() - size) / 2;

            Bitmap squaredBitmap = Bitmap.createBitmap(source, x, y, size, size);
            if (squaredBitmap != source) {
                source.recycle();
            }

            Bitmap bitmap = Bitmap.createBitmap(size, size, source.getConfig());

            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint();
            BitmapShader shader = new BitmapShader(squaredBitmap,
                    BitmapShader.TileMode.CLAMP, BitmapShader.TileMode.CLAMP);
            paint.setShader(shader);
            paint.setAntiAlias(true);
            float r = size / 2f;
            canvas.drawCircle(r, r, r, paint);

            squaredBitmap.recycle();
            return bitmap;
        }

        @Override
        public String key() {
            return "circle";
        }
    }
    //------------------------------------------------------

    /**
     * 绘制圆角
     */
    public static class RoundTransform implements Transformation {
        private float radius;

        public RoundTransform(float radius) {
            this.radius = radius;
        }

        @Override
        public String key() {
            return "round";
        }

        @Override
        public Bitmap transform(Bitmap source) {
            final Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setShader(new BitmapShader(source, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));

            Bitmap output = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(output);
            canvas.drawRoundRect(new RectF(0, 0, source.getWidth(), source.getHeight()), radius, radius, paint);
            if (source != output) {
                source.recycle();
            }
            return output;
        }

    }

}