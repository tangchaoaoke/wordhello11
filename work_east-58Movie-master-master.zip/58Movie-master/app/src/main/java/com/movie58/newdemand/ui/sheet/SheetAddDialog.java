package com.movie58.newdemand.ui.sheet;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.movie58.R;
import com.movie58.home.PlayHistoryActivity;


/**
 * Created by Administrator on 2016/12/1.
 */

public class SheetAddDialog extends Dialog {


    private PlayHistoryActivity context;

    public SheetAddDialog(@NonNull Context context) {
        super(context);
        this.context = (PlayHistoryActivity) context;
    }

    private EditText editText;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_sheet_add);
        Window dialogWindow = getWindow();
        dialogWindow.setBackgroundDrawable(null);
        dialogWindow.setGravity(Gravity.BOTTOM);
        setCanceledOnTouchOutside(true);

        WindowManager m = context.getWindowManager();
        Display d = m.getDefaultDisplay();
//
        WindowManager.LayoutParams layoutParams = dialogWindow.getAttributes();
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
//        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        dialogWindow.setAttributes(layoutParams);

        editText = findViewById(R.id.edit);
        mInputManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);

        showSoftInput();
        findViewById(R.id.tv_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        findViewById(R.id.tv_ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editText.getText().toString())) {
                    return;
                }
                if (anInterface != null) {
                    dismiss();
                    anInterface.addSheet(editText.getText().toString());
                }
            }
        });
    }
    /**
     * 编辑框获取焦点，并显示软件盘
     */

    private InputMethodManager mInputManager;//软键盘管理类

    public void showSoftInput() {
        editText.requestFocus();
        editText.post(new Runnable() {
            @Override
            public void run() {
                mInputManager.showSoftInput(editText, 0);
            }
        });
    }


    @Override
    public void dismiss() {
        super.dismiss();

    }

    SheetAddDialogInterface anInterface;

    public interface SheetAddDialogInterface {
        void addSheet(String name);
    }

    public void setSheetAddDialogInterface(SheetAddDialogInterface anInterface) {
        this.anInterface = anInterface;
    }

}
