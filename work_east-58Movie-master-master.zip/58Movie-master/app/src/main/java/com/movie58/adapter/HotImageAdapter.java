package com.movie58.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.bean.HotDetailInfo;
import com.movie58.event.Event;
import com.movie58.img.PicassoUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Created by yangxing on 2019/5/20 0020.
 */
public class HotImageAdapter extends PagerAdapter {

    List<HotDetailInfo.ParamsBean.ListBean> list;
    private Context mContext;
    int width, height;

    public HotImageAdapter(Context ctx, List<HotDetailInfo.ParamsBean.ListBean> list, int width, int height) {
        this.mContext = ctx;
        this.list = list;
        this.width = width;
        this.height = height;
    }

    @Override
    public int getCount() {
        return list.size();// 返回数据的个数
    }

    @Override
    public Object instantiateItem(final ViewGroup container, final int position) {//子View显示
        View view = View.inflate(container.getContext(), R.layout.item_hot_img, new RelativeLayout(mContext));
        ImageView ivImg = view.findViewById(R.id.iv_img);
        ImageView ivTop = view.findViewById(R.id.iv_top);
        TextView tvBottom = view.findViewById(R.id.tv_bottom);

//        int margin = mContext.getResources().getDimensionPixelOffset(R.dimen.dp_10);
//        int widthPix = ScreenUtils.getScreenWidth() - DensityUtil.dp2px(30);
//        int width = (widthPix - (margin * 2)) / 3;
//        int height = width / 2 * 3;
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(width, height);
//        int mo = position % 3;
//        if (mo == 0) {
//            params.leftMargin = 0;
//            params.rightMargin = margin / 2;
//        }else if(mo == 1){
//            params.leftMargin = margin / 2;
//            params.rightMargin = margin / 2;
//        }else{
//            params.leftMargin = margin / 2;
//            params.rightMargin = 0;
//        }
        ivImg.setLayoutParams(params);
        view.setLayoutParams(new RelativeLayout.LayoutParams(width, height));


        PicassoUtils.LoadImageWithDetfult(mContext, list.get(position).getImg_url(), ivImg, R.drawable.pic_emptypage_failure);
        if (TextUtils.isEmpty(list.get(position).getUp_right_text())) {
            ivTop.setVisibility(View.GONE);
        }else{
            switch (list.get(position).getUp_right_text()){
                case "火爆":
                    ivTop.setVisibility(View.VISIBLE);
                    ivTop.setImageResource(R.drawable.hot_huobao);
                    break;
                case "热播":
                    ivTop.setImageResource(R.drawable.hot_rebo);
                    ivTop.setVisibility(View.VISIBLE);
                    break;
                case "1080P":
                    ivTop.setImageResource(R.drawable.hot_1080);
                    ivTop.setVisibility(View.VISIBLE);
                    break;
                default:
                    ivTop.setVisibility(View.GONE);
                    break;
            }
        }
        if (TextUtils.isEmpty(list.get(position).getDown_right_text())) {
            tvBottom.setText(list.get(position).getPingfen());
            tvBottom.setTextColor(mContext.getResources().getColor(R.color.color_ff5722));
        }else{
            tvBottom.setText(list.get(position).getDown_right_text());
            tvBottom.setTextColor(mContext.getResources().getColor(R.color.white));
        }

        ivImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EventBus.getDefault().post(new Event(Event.CODE_09_SCHOOL_RESULT_REFRESH).setObj1(position));
            }
        });

        container.addView(view);//添加到父控件
        return view;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;// 过滤和缓存的作用
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);//从viewpager中移除掉
    }
}
