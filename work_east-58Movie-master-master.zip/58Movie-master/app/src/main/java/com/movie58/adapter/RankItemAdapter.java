package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.RankItemInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class RankItemAdapter extends BaseQuickAdapter<RankItemInfo, BaseViewHolder> {

    public RankItemAdapter(@Nullable List<RankItemInfo> data) {
        super(R.layout.item_rank_item, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, RankItemInfo item) {
        helper.setText(R.id.tv_title, item.getSource_name())
                .setText(R.id.tv_type, item.getType_name())
                .setText(R.id.tv_desc, "简介:" + item.getDescription())
                .setText(R.id.tv_no, "No." + (helper.getLayoutPosition() + 1));
        ImageView ivImg = helper.getView(R.id.iv_img);
        PicassoUtils.LoadImageWithDetfult(mContext, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
        helper.addOnClickListener(R.id.btn_play);

        if (TextUtils.isEmpty(item.getUp_right_text())) {
            helper.setGone(R.id.iv_top, false);
        }else{
            switch (item.getUp_right_text()){
                case "火爆":
                    helper.setGone(R.id.iv_top, true);
                    helper.setImageResource(R.id.iv_top, R.drawable.hot_huobao);
                    break;
                case "热播":
                    helper.setImageResource(R.id.iv_top, R.drawable.hot_rebo);
                    helper.setGone(R.id.iv_top, true);
                    break;
                case "1080P":
                    helper.setImageResource(R.id.iv_top, R.drawable.hot_1080);
                    helper.setGone(R.id.iv_top, true);
                    break;
                default:
                    helper.setGone(R.id.iv_top, false);
                    break;
            }
        }
        if (TextUtils.isEmpty(item.getDown_right_text())) {
            helper.setText(R.id.tv_bottom, item.getPingfen())
                    .setTextColor(R.id.tv_bottom, mContext.getResources().getColor(R.color.color_ff5722));
        }else{
            helper.setText(R.id.tv_bottom, item.getDown_right_text())
                    .setTextColor(R.id.tv_bottom, mContext.getResources().getColor(R.color.white));
        }

        switch (item.getTrend()){
            case 0:
                helper.setImageResource(R.id.iv_level, R.drawable.hot_ping);
                break;
            case 1:
                helper.setImageResource(R.id.iv_level, R.drawable.hot_shang);
                break;
            case -1:
                helper.setImageResource(R.id.iv_level, R.drawable.hot_xia);
                break;
        }

        switch (helper.getLayoutPosition()){
            case 0:
                helper.setBackgroundRes(R.id.tv_no, R.drawable.rank_1);
                break;
            case 1:
                helper.setBackgroundRes(R.id.tv_no, R.drawable.rank_2);
                break;
            case 2:
                helper.setBackgroundRes(R.id.tv_no, R.drawable.rank_3);
                break;
            default:
                helper.setBackgroundRes(R.id.tv_no, R.drawable.rank_4);
                break;
        }
    }
}
