package com.movie58.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.SPUtils;
import com.fm.openinstall.OpenInstall;
import com.fm.openinstall.listener.AppInstallAdapter;
import com.fm.openinstall.listener.AppWakeUpAdapter;
import com.fm.openinstall.model.AppData;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.http.HttpUrl;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.LogUtil;
import com.movie58.util.OnDoubleClickListener;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.orhanobut.logger.Logger;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/6/3 0003.
 */
public class WelcomeActivity extends BaseUseActivity {


    @BindView(R.id.iv_img)
    ImageView ivImg;
    @BindView(R.id.ad_time)
    TextView tvTime;

    String adUrl;
    String adImg;
    String adTitle;

    @Override
    protected int getLayout() {
        return R.layout.activity_welcome;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tvTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                startActivity(MainActivity.class);
                finish();

            }
        });

        adImg = SPUtils.getInstance().getString(SPContant.WELCOME_IMAGE);
        if (!TextUtils.isEmpty(adImg)) {
            PicassoUtils.LoadImageWithErrorDetfult(getMActivity(), adImg, ivImg, R.drawable.welcom);
        }
        if (ToolUtil.isNetworkConnected(getMActivity())) {
            getAd();
        } else {
            ivImg.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(MainActivity.class);
                    finish();
                }
            }, 1000);
        }
//获取唤醒参数

        OpenInstall.getWakeUp(getIntent(), wakeUpAdapter);
        //获取OpenInstall安装数据
        OpenInstall.getInstall(new AppInstallAdapter() {
            @Override
            public void onInstall(AppData appData) {
                //获取渠道数据
                String channelCode = appData.getChannel();
                //获取自定义数据
                String bindData = appData.getData();
                Logger.d("OpenInstall", "getInstall : installData = " + appData.toString());
            }
        });

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // 此处要调用，否则App在后台运行时，会无法截获
        OpenInstall.getWakeUp(intent, wakeUpAdapter);
    }

    AppWakeUpAdapter wakeUpAdapter = new AppWakeUpAdapter() {
        @Override
        public void onWakeUp(AppData appData) {
            //获取渠道数据
            String channelCode = appData.getChannel();
            //获取绑定数据
            String bindData = appData.getData();
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cancel();
        wakeUpAdapter = null;
    }


    private android.os.CountDownTimer timer;

    private void getAd() {
        Kalle.get(HttpUrl.GET_AD)
                .tag(tag)
                .param("position_code", "init")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {


                            if (response.isSucceed()) {
                                if (TextUtils.isEmpty(adImg)) {
                                    adImg = FastJsonUtil.toString(response.succeed(), "advert_img");
                                    PicassoUtils.LoadImageWithErrorDetfult(getMActivity(), adImg, ivImg, R.drawable.welcom);
                                }
                                adUrl = FastJsonUtil.toString(response.succeed(), "advert_url");
                                adTitle = FastJsonUtil.toString(response.succeed(), "advert_name");
                                if (!TextUtils.isEmpty(adUrl)) {
                                    ivImg.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if (OnDoubleClickListener.CanClick.NoClick()) return;
                                            ArrayMap<String, Object> map = new ArrayMap<>();
                                            map.put("url", adUrl);
                                            map.put("title", adTitle);
                                            startActivity(WebViewActivity.class, map);
                                        }
                                    });
                                    tvTime.setEnabled(false);

                                    cancel();
                                    timer = new android.os.CountDownTimer(1000, 1000) {

                                        @SuppressLint("DefaultLocale")
                                        @Override
                                        public void onTick(long millisUntilFinished) {
                                            tvTime.setText(String.format("%d S", millisUntilFinished / 1000));
                                        }

                                        @Override
                                        public void onFinish() {
                                            tvTime.setEnabled(true);
                                            startActivity(MainActivity.class);
                                            finish();
                                        }
                                    };
                                    timer.start();
                                } else {
                                    tvTime.setEnabled(false);
                                    cancel();
                                   timer = new android.os.CountDownTimer(3000, 1000) {

                                        @SuppressLint("DefaultLocale")
                                        @Override
                                        public void onTick(long millisUntilFinished) {
                                            tvTime.setText(String.format("%d S", millisUntilFinished / 1000));
                                        }

                                        @Override
                                        public void onFinish() {
                                            tvTime.setEnabled(true);
                                            startActivity(MainActivity.class);
                                            finish();
                                        }
                                    };
                                    timer.start();
                                }

                            } else {
                                if (TextUtils.isEmpty(adImg)) {
                                    ivImg.setImageResource(R.drawable.welcom);
                                }
                                tvTime.setEnabled(false);
                                cancel();
                                timer = new android.os.CountDownTimer(3000, 1000) {
                                    @SuppressLint("DefaultLocale")
                                    @Override
                                    public void onTick(long millisUntilFinished) {
                                        tvTime.setText(String.format("%d S", millisUntilFinished / 1000));
                                    }

                                    @Override
                                    public void onFinish() {
                                        tvTime.setEnabled(true);
                                        startActivity(MainActivity.class);
                                        finish();
                                    }
                                };
                                timer.start();
                            }
                    }
                });
    }

    public void cancel() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }


}
