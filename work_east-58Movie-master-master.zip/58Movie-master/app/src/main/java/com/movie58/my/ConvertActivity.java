package com.movie58.my;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.ConvertAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.ConvertInfo;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 兑换码
 * Created by yangxing on 2019/5/22 0022.
 */
public class ConvertActivity extends BaseUseActivity {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.btn_convert)
    SuperButton btnConvert;
    @BindView(R.id.et_common)
    EditText etCommon;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;

    int page = 1;
    ConvertAdapter mAdapter;

    @Override
    protected void initView() {
        tvTitle.setText("兑换码");

        mAdapter = new ConvertAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).build());
        mAdapter.bindToRecyclerView(rvList);

        View header = LayoutInflater.from(getMActivity()).inflate(R.layout.layout_convert_header, new RelativeLayout(getMActivity()));
        mAdapter.addHeaderView(header);

        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });

        layoutRefresh.autoRefresh();
    }

    @OnClick({R.id.iv_back, R.id.btn_convert})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.btn_convert:
                String code = etCommon.getText().toString().trim();
                if (TextUtils.isEmpty(code)) {
                    ToastUtils.show("请输入兑换码");
                    return;
                }
                exchange(code);
                break;
        }
    }

    private void getList(){
        Kalle.post(HttpUrl.EXCHANGE_LIST)
                .tag(tag)
                .param("page", page)
                .param("size", 10)
                .perform(new LoadingCallback<List<ConvertInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<ConvertInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else{
                            ToastUtils.show(response.failed());
                            page -- ;
                            layoutRefresh.finishRefresh();
                            layoutRefresh.finishLoadMore();
                        }
                    }
                });
    }

    void initList(List<ConvertInfo> list) {
        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
        }else{
            mAdapter.addData(list);
        }
        layoutRefresh.finishRefresh();
        layoutRefresh.finishLoadMore();
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }
    }

    private void exchange(String content){
        Kalle.post(HttpUrl.EXCHANGE)
                .tag(tag)
                .param("exchange_code", content)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("兑换成功");
                            etCommon.setText("");
                            page = 1;
                            getList();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_convert;
    }

}
