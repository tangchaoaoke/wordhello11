package com.movie58.bean;

public class ShareBean {
    private String share_qr_img;
    private String share_bc_img;
    private String share_url;

    public String getShare_qr_img() {
        return share_qr_img;
    }

    public void setShare_qr_img(String share_qr_img) {
        this.share_qr_img = share_qr_img;
    }

    public String getShare_bc_img() {
        return share_bc_img;
    }

    public void setShare_bc_img(String share_bc_img) {
        this.share_bc_img = share_bc_img;
    }

    public String getShare_url() {
        return share_url;
    }

    public void setShare_url(String share_url) {
        this.share_url = share_url;
    }
}
