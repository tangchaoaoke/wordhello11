package com.movie58.my;

import android.view.View;
import android.widget.TextView;

import com.allen.library.SuperTextView;
import com.movie58.R;
import com.movie58.base.BaseFragment;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/7 0007.
 */
public class SafeCenterFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.layout_phone)
    SuperTextView layoutPhone;
    @BindView(R.id.layout_pwd)
    SuperTextView layoutPwd;
    @BindView(R.id.layout_change)
    SuperTextView layoutChange;


    public static SafeCenterFragment newInstance() {
        return new SafeCenterFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("账号安全中心");
    }

    @OnClick({R.id.iv_back, R.id.layout_pwd, R.id.layout_change})
    void click(View v){
        hideSoftInput();
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.layout_pwd:
                start(ChangePwdFragment.newInstance());
                break;
            case R.id.layout_change:
                start(ChangePhoneFragment.newInstance());
                break;
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_setting_center;
    }

}
