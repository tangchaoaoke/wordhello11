package com.movie58.my;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.blankj.utilcode.util.SPUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hss01248.dialog.StyleDialog;
import com.hss01248.dialog.interfaces.DialogListener;
import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadConnectListener;
import com.liulishuo.filedownloader.FileDownloadListener;
import com.liulishuo.filedownloader.FileDownloadSampleListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.model.FileDownloadStatus;
import com.liulishuo.filedownloader.util.FileDownloadUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.bean.DownloadInfo;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.ToolUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.orhanobut.logger.Logger;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.io.File;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/8/5 0005.
 */
public class CacheFragment extends BaseFragment {

    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.btn_del)
    SuperButton btnDel;
    @BindView(R.id.btn_all)
    SuperButton btnAll;
    @BindView(R.id.layout_bottom)
    RelativeLayout layoutBottom;

    List<DownloadInfo> list = new ArrayList<>();
    List<DownloadInfo> listDown = new ArrayList<>();

    DownloadAdapter mAdapter;

    public static CacheFragment newInstance(List<DownloadInfo> list) {
        CacheFragment fragment = new CacheFragment();
        Bundle b = new Bundle();
        b.putSerializable("cache", (Serializable) list);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {

        FileDownloader.setup(getMActivity());

        Bundle b = getArguments();
        list = (List<DownloadInfo>) b.getSerializable("cache");


        if (list == null) {
            list = new ArrayList<>();
        }

        String downList = SPUtils.getInstance().getString(Account.getInstance().getUserId() + "ing");

        if (TextUtils.isEmpty(downList)) {
            listDown = new ArrayList<>();
        }else{
            listDown = FastJsonUtil.toList(downList, DownloadInfo.class);
        }

        for(DownloadInfo info : list){
            String path = createPath(info.getUrl());
            info.setPath(path);
            info.setId(FileDownloadUtils.generateId(info.getUrl(), path));
        }

        for(DownloadInfo info : list){
            if (!listDown.contains(info)) {
                listDown.add(info);
            }
        }

        for(DownloadInfo info : listDown){
            String path = createPath(info.getUrl());
            info.setPath(path);
            info.setId(FileDownloadUtils.generateId(info.getUrl(), path));
        }

        putJson(listDown);

        TasksManager.getImpl().onCreate(new WeakReference<>(this));
    }


    private void putJson(List<DownloadInfo> list){
        String json = FastJsonUtil.toJson(list);
        SPUtils.getInstance().put(Account.getInstance().getUserId() + "ing", json);
    }

    @Override
    public void onDestroy() {
        TasksManager.getImpl().onDestroy();
        FileDownloader.getImpl().pauseAll();
        super.onDestroy();
    }

    @Override
    protected void initView() {

        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        mAdapter = new DownloadAdapter(listDown);
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvList);

    }

    public static class TasksManager {
        private final static class HolderClass {
            private final static TasksManager INSTANCE  = new TasksManager();
        }

        public static TasksManager getImpl() {
            return HolderClass.INSTANCE;
        }

//        private List<DownloadInfo> modelList;

        private TasksManager() {
//            String downList = SPUtils.getInstance().getString(Account.getInstance().getUserId() + "ing");
//            if (TextUtils.isEmpty(downList)) {
//                modelList = new ArrayList<>();
//            }else{
//                modelList = FastJsonUtil.toList(downList, DownloadInfo.class);
//            }
        }

        private SparseArray<BaseDownloadTask> taskSparseArray = new SparseArray<>();

        public void addTaskForViewHolder(final BaseDownloadTask task) {
            taskSparseArray.put(task.getId(), task);
        }

        public void removeTaskForViewHolder(final int id) {
            taskSparseArray.remove(id);
        }

        public void removeTaskForHolderId(final int holderId){

            int id = 0;
            for(int i = 0; i < taskSparseArray.size(); i++){
                BaseDownloadTask task = taskSparseArray.get(taskSparseArray.keyAt(i));
                if (task.getId() == holderId) {
                    id = task.getId();
                    break;
                }
            }
            if (id != 0) {
                taskSparseArray.remove(id);
            }

        }

        public void updateViewHolder(final int id, final DownLoadHolder holder) {
            final BaseDownloadTask task = taskSparseArray.get(id);
            if (task == null) {
                return;
            }

            task.setTag(holder);
        }

        public void releaseTask() {
            taskSparseArray.clear();
        }

        private FileDownloadConnectListener listener;

        private void registerServiceConnectionListener(final WeakReference<CacheFragment>
                                                               activityWeakReference) {
            if (listener != null) {
                FileDownloader.getImpl().removeServiceConnectListener(listener);
            }

            listener = new FileDownloadConnectListener() {

                @Override
                public void connected() {
                    if (activityWeakReference == null
                            || activityWeakReference.get() == null) {
                        return;
                    }

                    activityWeakReference.get().postNotifyDataChanged();
                }

                @Override
                public void disconnected() {
                    if (activityWeakReference == null
                            || activityWeakReference.get() == null) {
                        return;
                    }

                    activityWeakReference.get().postNotifyDataChanged();
                }
            };

            FileDownloader.getImpl().addServiceConnectListener(listener);
        }

        private void unregisterServiceConnectionListener() {
            FileDownloader.getImpl().removeServiceConnectListener(listener);
            listener = null;
        }

        public void onCreate(final WeakReference<CacheFragment> activityWeakReference) {
            if (!isReady()) {
                FileDownloader.getImpl().bindService();
                registerServiceConnectionListener(activityWeakReference);
            }
        }

        public void onDestroy() {
            unregisterServiceConnectionListener();
            releaseTask();
        }

        public boolean isReady() {
            return FileDownloader.getImpl().isServiceConnected();
        }

//        public DownloadInfo get(final int position) {
//            return modelList.get(position);
//        }
//
//        public DownloadInfo getById(final String url) {
//            for (DownloadInfo model : modelList) {
//                if (model.getUrl().equals(url)) {
//                    return model;
//                }
//            }
//
//            return null;
//        }

        /**
         * @param status Download Status
         * @return has already downloaded
         * @see FileDownloadStatus
         */
        public boolean isDownloaded(final int status) {
            return status == FileDownloadStatus.completed;
        }

        public int getStatus(final int id, String path) {
            return FileDownloader.getImpl().getStatus(id, path);
        }

        public long getTotal(final int id) {
            return FileDownloader.getImpl().getTotal(id);
        }

        public long getSoFar(final int id) {
            return FileDownloader.getImpl().getSoFar(id);
        }

//        public int getTaskCounts() {
//            return modelList.size();
//        }

    }

    public String createPath(final String url) {
        if (TextUtils.isEmpty(url)) {
            return null;
        }
        return FileDownloadUtils.getDefaultSaveFilePath(url);
    }

    public void postNotifyDataChanged() {
        if (mAdapter != null) {
            getMActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mAdapter != null) {
                        mAdapter.notifyDataSetChanged();
                    }
                }
            });
        }
    }


    @Override
    protected int getLayout() {
        return R.layout.fragment_cache;
    }


    public class DownloadAdapter extends BaseQuickAdapter<DownloadInfo, DownLoadHolder>{

        public DownloadAdapter(@Nullable List<DownloadInfo> data) {
            super(R.layout.item_cache, data);
        }

        @Override
        protected void convert(DownLoadHolder helper, DownloadInfo item) {
            helper.setText(R.id.tv_name, item.getTitle());
            ImageView ivImg = helper.getView(R.id.iv_player);
            PicassoUtils.LoadImageWithDetfult(mContext, item.getImg(), ivImg, R.drawable.pic_emptypage_failure);
            helper.setId(item.getId());
            helper.setOnClickListener(R.id.layout, new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    CharSequence action = ((TextView)helper.getView(R.id.tv_state)).getText();
                    if (action.equals("开始") || action.equals("暂停") || action.equals("错误")) {
                        // to start
                        // to start
                        final BaseDownloadTask task = FileDownloader.getImpl().create(item.getUrl())
                                .setPath(item.getPath())
                                .setCallbackProgressTimes(100)
                                .setListener(taskDownloadListener);

                        TasksManager.getImpl().addTaskForViewHolder(task);
                        TasksManager.getImpl().updateViewHolder(task.getId(), helper);

                        task.start();
                    } else if (((String)action).contains("B/s")) {
                        // to pause
                        FileDownloader.getImpl().pause(item.getId());
                    } else if (action.equals("完成")) {
                        // to delete
//                        new File(TasksManager.getImpl().get(helper.getLayoutPosition()).getPath()).delete();

                        updateNotDownloaded(helper, FileDownloadStatus.INVALID_STATUS, 0, 0);
                    }
                }
            });

            helper.setOnLongClickListener(R.id.layout, new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {

                    StyleDialog.buildIosAlert(getMActivity(), "提示", "确定删除吗？")
                            .setBtnText("取消", "确定")
                            .setBtnColor(R.color.color_base)
                            .setListener(new DialogListener() {
                                @Override
                                public void onFirst() {

                                }

                                @Override
                                public void onSecond() {
                                    new File(item.getPath()).delete();
                                    new File(FileDownloadUtils.getTempPath(item.getPath())).delete();
                                    FileDownloader.getImpl().pause(item.getId());
                                    FileDownloader.getImpl().clear(item.getId(), item.getPath());
                                    TasksManager.getImpl().removeTaskForHolderId(helper.getId());
                                    listDown.remove(helper.getLayoutPosition());
                                    notifyDataSetChanged();
                                    putJson(getData());

                                }
                            }).show();




                    return false;
                }
            });


            if (TasksManager.getImpl().isReady()) {
                final int status = TasksManager.getImpl().getStatus(item.getId(), item.getPath());
                if (status == FileDownloadStatus.pending ) {
                    // start task, but file not created yet
                    updateDownloading(helper, status, TasksManager.getImpl().getSoFar(item.getId()), TasksManager.getImpl().getTotal(item.getId()), 0);
                } else if (!new File(item.getPath()).exists() &&
                        !new File(FileDownloadUtils.getTempPath(item.getPath())).exists()) {
                    // not exist file
                    updateNotDownloaded(helper, status, 0, 0);
                } else if (TasksManager.getImpl().isDownloaded(status)) {
                    // already downloaded and exist
                    updateDownloaded(helper);
                } else if (status == FileDownloadStatus.started ||
                        status == FileDownloadStatus.connected || status == FileDownloadStatus.progress) {
                    // downloading
                    updateDownloading(helper, status, TasksManager.getImpl().getSoFar(item.getId())
                            , TasksManager.getImpl().getTotal(item.getId()), 0);
                } else {
                    // not start
                    updateNotDownloaded(helper, status, TasksManager.getImpl().getSoFar(item.getId())
                            , TasksManager.getImpl().getTotal(item.getId()));
                }
            } else {
                helper.setText(R.id.tv_state, "开始");
                helper.setText(R.id.tv_total, "");
            }






        }

        private FileDownloadListener taskDownloadListener = new FileDownloadSampleListener() {

            private DownLoadHolder checkCurrentHolder(final BaseDownloadTask task) {
                final DownLoadHolder tag = (DownLoadHolder) task.getTag();
                if (tag.getId() != task.getId()) {
                    return null;
                }

                return tag;
            }

            @Override
            protected void pending(BaseDownloadTask task, int soFarBytes, int totalBytes) {
                super.pending(task, soFarBytes, totalBytes);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }
                updateDownloading(tag, FileDownloadStatus.pending, soFarBytes , totalBytes, task.getSpeed());
            }

            @Override
            protected void started(BaseDownloadTask task) {
                super.started(task);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }
            }

            @Override
            protected void connected(BaseDownloadTask task, String etag, boolean isContinue, int soFarBytes, int totalBytes) {
                super.connected(task, etag, isContinue, soFarBytes, totalBytes);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }

                updateDownloading(tag, FileDownloadStatus.connected, soFarBytes, totalBytes, task.getSpeed());
            }

            @Override
            protected void progress(BaseDownloadTask task, int soFarBytes, int totalBytes) {
                super.progress(task, soFarBytes, totalBytes);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }
                Logger.d("progress............speed = " + task.getSpeed() + " ....... soFarBytes = " + soFarBytes);
                updateDownloading(tag, FileDownloadStatus.progress, soFarBytes, totalBytes, task.getSpeed());
            }

            @Override
            protected void error(BaseDownloadTask task, Throwable e) {
                super.error(task, e);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }
                Logger.d("error............error = " + e.getMessage());
                updateNotDownloaded(tag, FileDownloadStatus.error, task.getLargeFileSoFarBytes(), task.getLargeFileTotalBytes());
                TasksManager.getImpl().removeTaskForViewHolder(task.getId());
            }

            @Override
            protected void paused(BaseDownloadTask task, int soFarBytes, int totalBytes) {
                super.paused(task, soFarBytes, totalBytes);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }
                Logger.d("paused............speed = " + task.getSpeed() + " ....... soFarBytes = " + soFarBytes);
                updateNotDownloaded(tag, FileDownloadStatus.paused, soFarBytes, totalBytes);
                TasksManager.getImpl().removeTaskForViewHolder(task.getId());
            }

            @Override
            protected void completed(BaseDownloadTask task) {
                super.completed(task);
                final DownLoadHolder tag = checkCurrentHolder(task);
                if (tag == null) {
                    return;
                }

                updateDownloaded(tag);
                TasksManager.getImpl().removeTaskForViewHolder(task.getId());

                //添加到下载完成
                DownloadInfo info = listDown.get(tag.getLayoutPosition());
                String downList = SPUtils.getInstance().getString(Account.getInstance().getUserId() + "end1");
                List<DownloadInfo> list = FastJsonUtil.toList(downList, DownloadInfo.class);
                if (list == null) {
                    list = new ArrayList<>();
                }
                list.add(info);
                String json = FastJsonUtil.toJson(list);
                SPUtils.getInstance().put(Account.getInstance().getUserId() + "end1", json);
                //下载中删除
                listDown.remove(tag.getLayoutPosition());
                notifyDataSetChanged();
                putJson(getData());
            }
        };

        public void updateDownloaded(DownLoadHolder helper) {
            ContentLoadingProgressBar pb = helper.getView(R.id.pb);
            pb.setMax(1);
            pb.setProgress(1);

            helper.setText(R.id.tv_state, "下载完成");
            helper.setText(R.id.tv_total, "");
        }

        public void updateNotDownloaded(DownLoadHolder helper, final int status, final long sofar, final long total) {
            ContentLoadingProgressBar pb = helper.getView(R.id.pb);
            if (sofar > 0 && total > 0) {
                final float percent = sofar  / (float) total;
                pb.setMax(100);
                pb.setProgress((int) (percent * 100));
            } else {
                pb.setMax(1);
                pb.setProgress(0);
            }

            switch (status) {
                case FileDownloadStatus.error:
                    helper.setText(R.id.tv_state, "错误");
                    helper.setText(R.id.tv_total, "");
                    break;
                case FileDownloadStatus.paused:
                    helper.setText(R.id.tv_state, "暂停");
                    helper.setText(R.id.tv_total, ToolUtil.formatFileSize(sofar) + "/" + ToolUtil.formatFileSize(total));
                    break;
                default:
                    helper.setText(R.id.tv_state, "开始");
                    helper.setText(R.id.tv_total, "");
                    break;
            }

        }

        public void updateDownloading(DownLoadHolder helper, final int status, final long sofar, final long total, int speed) {
            ContentLoadingProgressBar pb = helper.getView(R.id.pb);
            final float percent = sofar / (float) total;
            pb.setMax(100);
            pb.setProgress((int) (percent * 100));

            switch (status) {
                case FileDownloadStatus.pending:
                    helper.setText(R.id.tv_state, "开始");
                    helper.setText(R.id.tv_total, "");
                    break;
                case FileDownloadStatus.started:
//                    helper.setText(R.id.tv_state, "开始下载");
//                    break;
                case FileDownloadStatus.connected:
//                    helper.setText(R.id.tv_state, "连接成功");
//                    break;
                case FileDownloadStatus.progress:
                    helper.setText(R.id.tv_state, ToolUtil.formatFileSize1(speed));
                    helper.setText(R.id.tv_total, ToolUtil.formatFileSize(sofar) + "/" + ToolUtil.formatFileSize(total));
                    break;
                    case FileDownloadStatus.paused:
                        helper.setText(R.id.tv_state, "暂停");
                        helper.setText(R.id.tv_total, ToolUtil.formatFileSize(sofar) + "/" + ToolUtil.formatFileSize(total));
                        break;
            }
        }

    }


}
