package com.movie58.task;

import android.widget.EditText;

import com.allen.library.SuperButton;
import com.movie58.R;
import com.movie58.base.BaseFragment;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/6/26 0026.
 */
public class ConvertBankFragment extends BaseFragment {

    @BindView(R.id.et_bank)
    EditText etBank;
    @BindView(R.id.et_no)
    EditText etNo;
    @BindView(R.id.et_name)
    EditText etName;
    @BindView(R.id.et_address)
    EditText etAddress;
    @BindView(R.id.btn_bank)
    SuperButton btnBank;


    public static ConvertBankFragment newInstance() {
        return new ConvertBankFragment();
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_convert_bank;
    }
}
