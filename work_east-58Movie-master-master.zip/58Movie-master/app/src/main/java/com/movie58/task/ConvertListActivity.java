package com.movie58.task;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.ConvertListInfo;
import com.movie58.bean.LimitInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 兑换中心
 * Created by yangxing on 2019/5/27 0027.
 */
public class ConvertListActivity extends BaseUseActivity {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv1)
    TextView tv1;
    @BindView(R.id.rv_list)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.btn)
    SuperButton btn;
    int page = 1;
    int strCount;
    ConvertAdapter mAdapter;
    LimitInfo limitInfo;

    @Override
    protected void initView() {
        tvTitle.setText("兑换中心");
        mAdapter = new ConvertAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).colorResId(R.color.line).build());
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                convert(mAdapter.getItem(position).getId());
            }
        });
        getSetting();
        getList();
        layoutRefresh.setEnableRefresh(false);
        layoutRefresh.setEnableLoadMore(false);
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    @OnClick({R.id.iv_back,R.id.btn})
    void click(View v){
        switch (v.getId()){
            case R.id.iv_back:
                finish();
                break;
            case R.id.btn:
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("limit", limitInfo);
                startActivity(ConvertCenterActivity.class, map);
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_18_WORDLIST_REFRESH:
                getSetting();
                getList();
                break;
        }
    }

    private void getSetting(){
        Kalle.get(HttpUrl.GOLD_SETTING)
                .perform(new NormalCallback<LimitInfo>() {
                    @Override
                    public void onFinaly(SimpleResponse<LimitInfo, String> response) {
                        if (response.isSucceed()) {
                            limitInfo = response.succeed();
                            if (limitInfo.getIs_open() == 1) {
                                btn.setVisibility(View.VISIBLE);
                            }else{
                                btn.setVisibility(View.GONE);
//                                btn.setVisibility(View.VISIBLE);
                            }
                        }else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    private void getList(){
        Kalle.get(HttpUrl.CONVERT_LIST)
//                .param("page", page)
//                .param("szie", 10)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            strCount = FastJsonUtil.toInt(response.succeed(), "gold_num");
                            tv1.setText(strCount + "");
                            List<ConvertListInfo> list = FastJsonUtil.toList(response.succeed(), "rule_list", ConvertListInfo.class);
                            initList(list);
                        }else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initList(List<ConvertListInfo> list){


        if (list == null) {
            list = new ArrayList<>();
        }

//        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
//            layoutRefresh.finishRefresh();
//        }else{
//            mAdapter.addData(list);
//            layoutRefresh.finishLoadMore();
//        }
//        if (list.isEmpty()) {
//            layoutRefresh.setEnableLoadMore(false);
//        }else{
//            layoutRefresh.setEnableLoadMore(true);
//        }

    }

    private void convert(int id){
        Kalle.get(HttpUrl.CONVERT_USE)
                .param("rule_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToastUtils.show("兑换成功");
                            getList();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_convert_list;
    }

    class ConvertAdapter extends BaseQuickAdapter<ConvertListInfo, BaseViewHolder> {

        public ConvertAdapter(@Nullable List<ConvertListInfo> data) {
            super(R.layout.item_rule, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, ConvertListInfo item) {
            helper.setText(R.id.tv_title, item.getRule_name())
                    .setText(R.id.tv_bi, "+" + item.getGold_num() + " 金币/个")
                    .setText(R.id.tv_des, item.getRule_desc());
            ImageView iv = helper.getView(R.id.iv_img);
            PicassoUtils.LoadImage(mContext, item.getRule_img(), iv);
            Button btn = helper.getView(R.id.btn);
            if (item.getGold_num() > strCount) {
                btn.setText("余额不足");
                btn.setEnabled(false);
            }else{
                btn.setText("去兑换");
                btn.setEnabled(true);
            }
            helper.addOnClickListener(R.id.btn);
        }
    }

}
