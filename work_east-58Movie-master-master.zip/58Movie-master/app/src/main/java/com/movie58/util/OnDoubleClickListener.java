package com.movie58.util;

import android.view.View;

/**
 * 避免双击造成的bug
 * Created by yangxing on 2017/4/6.
 */

public abstract class OnDoubleClickListener implements View.OnClickListener{

    public abstract void onValidClick(View v);

    @Override
    public void onClick(View v) {
        if (CanClick.NoClick()) {
            return;
        }
        onValidClick(v);
    }

    public static class CanClick {
        private static long lastTime;
        public static boolean NoClick() {
            long time = System.currentTimeMillis();
            long timeD = time - lastTime;
            if (timeD > 0 && timeD < 500) {
                return true;
            }
            lastTime = time;
            return false;
        }
    }
    
}
