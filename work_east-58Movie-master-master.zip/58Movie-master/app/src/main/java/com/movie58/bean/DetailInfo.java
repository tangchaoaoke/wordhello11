package com.movie58.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangxing on 2019/5/16 0016.
 */
public class DetailInfo {
    /**
     * id : 117
     * source_name : 疯狂的赛车
     * source_img : https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3188152122,3016498141&fm=26&gp=0.jpg
     * source_content : []
     * download_content : []
     * member_level : 1
     * detail_desc : 在一次全国自行车锦标赛上，倒霉的职业车手耿浩（黄渤 饰）以0.01秒的微弱差距败给撞到狗屎运的对手，屈居亚军，随后他又遭奸商李法拉（九孔 饰）算计，因药检呈阳性而被终身禁赛，他的教练（马少骅 饰）因此气倒。 　　多年后，耿浩靠开车运送水产为生，养活中风的教练，而当年的骗子李法拉则依靠其推销的补品“肾白银”大发其财。李嫌弃彪悍魁梧的老婆，因此雇用两个业余杀手（王双宝 & 巴多 饰）杀妻，结果杀手反被老婆买通；耿浩的教练急火攻心，一命呜呼，耿浩遵照师傅遗愿前去找李法拉讨说法，谁知反中了李的奸计；东海（戎祥 饰）所率领的台湾黑帮来到内地和泰国毒贩（Worapoj Thuantanon 饰）做生意，但耿浩和李法拉的争执引来了警车，也搅了他们的好事。原本不相干的几组人马，由于偶然的机缘而上演了连串好戏
     * description : null
     * lead_role : 黄渤,戎祥,九孔,徐峥,王双宝,巴多,董立范,高捷,马少骅,王迅,刘刚,Worapoj Thuantanon,赵奔,李麒麟,姜志刚,王鹭,宁浩
     * pingfen : 9.0
     * year : 2019
     * area_id : 14
     * up_right_text : 火爆
     * down_right_text :
     * gold_coin : 0
     * area_name : 大陆电影
     * cat_id : 2
     * cat_name : 电影
     * is_collect : 0
     * tags : []
     * types : []
     * play_num : 0
     * comment_count : 0
     */

    private String id;
    private String source_name;
    private String source_img;
    private String member_level;
    private String detail_desc;
    private Object description;
    private String lead_role;
    private String pingfen;
    private int year;
    private int update_schedule;
    private String area_id;
    private String up_right_text;
    private String down_right_text;
    private String gold_coin;
    private String area_name;
    private String cat_id;
    private String cat_name;
    private int is_collect;
    private String play_num;
    private int comment_count;
    private String director;
    private List<SourceContentBean> source_content = new ArrayList<>();
    private List<DownloadContentBean> download_content = new ArrayList<>();
    private List<TagBean> tags = new ArrayList<>();
    private List<TypeBean> types = new ArrayList<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getSource_name() {
        return source_name;
    }

    public int getUpdate_schedule() {
        return update_schedule;
    }

    public void setUpdate_schedule(int update_schedule) {
        this.update_schedule = update_schedule;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public String getSource_img() {
        return source_img;
    }

    public void setSource_img(String source_img) {
        this.source_img = source_img;
    }

    public String getMember_level() {
        return member_level;
    }

    public void setMember_level(String member_level) {
        this.member_level = member_level;
    }

    public String getDetail_desc() {
        return detail_desc;
    }

    public void setDetail_desc(String detail_desc) {
        this.detail_desc = detail_desc;
    }

    public Object getDescription() {
        return description;
    }

    public void setDescription(Object description) {
        this.description = description;
    }

    public String getLead_role() {
        return lead_role;
    }

    public void setLead_role(String lead_role) {
        this.lead_role = lead_role;
    }

    public String getPingfen() {
        return pingfen;
    }

    public void setPingfen(String pingfen) {
        this.pingfen = pingfen;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getArea_id() {
        return area_id;
    }

    public void setArea_id(String area_id) {
        this.area_id = area_id;
    }

    public String getUp_right_text() {
        return up_right_text;
    }

    public void setUp_right_text(String up_right_text) {
        this.up_right_text = up_right_text;
    }

    public String getDown_right_text() {
        return down_right_text;
    }

    public void setDown_right_text(String down_right_text) {
        this.down_right_text = down_right_text;
    }

    public String getGold_coin() {
        return gold_coin;
    }

    public void setGold_coin(String gold_coin) {
        this.gold_coin = gold_coin;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }

    public int getIs_collect() {
        return is_collect;
    }

    public void setIs_collect(int is_collect) {
        this.is_collect = is_collect;
    }

    public String getPlay_num() {
        return play_num;
    }

    public void setPlay_num(String play_num) {
        this.play_num = play_num;
    }

    public int getComment_count() {
        return comment_count;
    }

    public void setComment_count(int comment_count) {
        this.comment_count = comment_count;
    }

    public List<SourceContentBean> getSource_content() {
        return source_content;
    }

    public void setSource_content(List<SourceContentBean> source_content) {
        this.source_content = source_content;
    }

    public List<DownloadContentBean> getDownload_content() {
        return download_content;
    }

    public void setDownload_content(List<DownloadContentBean> download_content) {
        this.download_content = download_content;
    }

    public List<TagBean> getTags() {
        return tags;
    }

    public void setTags(List<TagBean> tags) {
        this.tags = tags;
    }

    public List<TypeBean> getTypes() {
        return types;
    }

    public void setTypes(List<TypeBean> types) {
        this.types = types;
    }

    public static class SourceContentBean{
        private boolean check;
        private String play_title;
        private String play_url;

        public boolean isCheck() {
            return check;
        }

        public void setCheck(boolean check) {
            this.check = check;
        }

        public String getPlay_title() {
            return play_title;
        }

        public void setPlay_title(String play_title) {
            this.play_title = play_title;
        }

        public String getPlay_url() {
            return play_url;
        }

        public void setPlay_url(String play_url) {
            this.play_url = play_url;
        }
    }

    public static class DownloadContentBean{
        private String down_title;

        public String getDown_title() {
            return down_title;
        }

        public void setDown_title(String down_title) {
            this.down_title = down_title;
        }

        public String getDown_url() {
            return down_url;
        }

        public void setDown_url(String down_url) {
            this.down_url = down_url;
        }

        private String down_url;


    }

    public static class TagBean{
        private String tag_id;
        private String tag_name;

        public String getTag_id() {
            return tag_id;
        }

        public void setTag_id(String tag_id) {
            this.tag_id = tag_id;
        }

        public String getTag_name() {
            return tag_name;
        }

        public void setTag_name(String tag_name) {
            this.tag_name = tag_name;
        }
    }

    public static class TypeBean{
        private String type_id;
        private String type_name;

        public String getType_id() {
            return type_id;
        }

        public void setType_id(String type_id) {
            this.type_id = type_id;
        }

        public String getType_name() {
            return type_name;
        }

        public void setType_name(String type_name) {
            this.type_name = type_name;
        }
    }
}
