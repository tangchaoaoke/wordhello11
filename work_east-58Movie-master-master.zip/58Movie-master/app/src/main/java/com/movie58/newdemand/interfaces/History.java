package com.movie58.newdemand.interfaces;


import android.text.TextUtils;

import com.movie58.newdemand.net.ApiListener;
import com.movie58.newdemand.net.ApiTool;
import com.movie58.account.Account;
import com.movie58.http.HttpUrl;

import org.xutils.http.RequestParams;

public class History {


    public void a(String token, String ipone, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/searchLog");
        params.addHeader("XX-Token", token);
        params.addHeader("XX-Device-Type", ipone);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "searchLog");
    }

    public void b(String token, String search_name, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/searchRecord");
        params.addHeader("XX-Token", token);
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("search_name", search_name);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "searchRecord");
    }

    //http://api.anboi.cn/api.php/member/play/searchDelete
    public void c(String token, String id, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/searchDelete");
        params.addHeader("XX-Token", token);
        params.addHeader("XX-Device-Type", "android");
        if (!TextUtils.isEmpty(id)) {
            params.addBodyParameter("id", id);
        }
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "searchDelete");
    }

    public void cAll(String token, String id, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "member/play/searchDelete");
        params.addHeader("XX-Token", token);
        params.addHeader("XX-Device-Type", "android");
        if (!TextUtils.isEmpty(id)) {
            params.addBodyParameter("id", id);
        }
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "searchDelete.all");
    }


    //联想搜索
    public void d(String name, ApiListener apiListener) {
        RequestParams params = new RequestParams(HttpUrl.baseUrl + "collect/collect/searchName");
        if (Account.getInstance().isLogined()) {
            params.addHeader("XX-Token", Account.getInstance().getToken());
        }
        params.addHeader("XX-Device-Type", "android");
        params.addBodyParameter("name", name);
        ApiTool apiTool = new ApiTool();
        apiTool.setCachestate(false);
        apiTool.setFirstCach(false);
        apiTool.postApi(params, apiListener, "searchName.ii");
    }


}
