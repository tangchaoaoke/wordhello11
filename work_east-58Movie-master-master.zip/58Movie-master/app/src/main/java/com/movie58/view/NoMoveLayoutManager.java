package com.movie58.view;

import android.content.Context;

/**
 * 设置RecyclerView不能滑动的LayoutManager
 */

public class NoMoveLayoutManager extends WrapContentLinearLayoutManager {

    private boolean isScrollEnabled = true;

    public NoMoveLayoutManager(Context context) {
        super(context);
    }

    public NoMoveLayoutManager setScrollEnabled(boolean flag) {
        this.isScrollEnabled = flag;
        return this;
    }

    @Override
    public boolean canScrollVertically() {
        //Similarly you can customize "canScrollHorizontally()" for managing horizontal scroll
        return isScrollEnabled && super.canScrollVertically();
    }
}
