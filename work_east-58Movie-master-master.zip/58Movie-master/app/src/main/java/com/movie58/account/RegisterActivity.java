package com.movie58.account;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.movie58.R;
import com.movie58.base.BaseActivity;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class RegisterActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.container, RegisterFragment.newInstance());
        }
    }
}
