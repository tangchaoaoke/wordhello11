//package com.movie58.a.ui;
//
//import android.os.Bundle;
//import android.util.Log;
//
//import com.movie58.R;
//import com.movie58.a.base.BaseAty;
//
//import java.io.BufferedInputStream;
//import java.io.BufferedReader;
//import java.io.DataOutputStream;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.Reader;
//import java.io.UnsupportedEncodingException;
//import java.net.HttpURLConnection;
//import java.net.MalformedURLException;
//import java.net.URL;
//import java.net.URLEncoder;
//import java.nio.charset.Charset;
//import java.util.Map;
//
//public class TestAty extends BaseAty {
//
//    private String urls = "https://8k.360360-dy.com/20190823/laRGUB1d/2000kb/hls/index.m3u8";
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.aty_test;
//    }
//
//    @Override
//    public void initPresenter() {
//    }
//
//    @Override
//    public void initView() {
//    }
//
//    @Override
//    public void requestData() {
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        try {
////            String start = start();
////            Log.e("00000000000=", start);
//        } catch (Exception e) {
//
//        }
//        a();
//
//    }
//
//    private void a() {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    URL url = new URL(urls);
//                    InputStream is = url.openStream();
//                    BufferedInputStream bis = new BufferedInputStream(is);
//                    StringBuffer sb = new StringBuffer("");
//                    int len = 0;
//                    byte[] temp = new byte[1024];
//                    while ((len = bis.read(temp)) != -1) {
//                        sb.append(new String(temp, 0, len));
//                    }
//                    sb.toString();
//
//
////                    Log.e("00000000000=", sb.toString());
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }).start();
//    }
//
//    public void b(String str) {
////        int a2 = str.indexOf(".ts");//*第一个出现的索引位置
////        while (a2 != -1) {
////            a2 = str.indexOf("]", a2 + 1);//*从这个索引往后开始第一个出现的位置
////            if (a2 != -1) {
////                list2.add(a2);
////            }
////
////        }
//
//        try {
//            URL url = new URL(urls);
//            InputStream is = url.openStream();
//            BufferedInputStream bis = new BufferedInputStream(is);
//        } catch (Exception e) {
//        }
//
//    }
//
//    public static String getURLContent(String requestUrl, Map<String, Object> data, String method) throws IOException {
//
//        HttpURLConnection conn = null;
//        BufferedReader br = null;
//        StringBuffer sb = new StringBuffer();
//        String content = null;
//        //GET请求的url链接
//        if (null == method || "GET" == method) {
//            requestUrl = requestUrl + "?" + urlEncode(data);
//        }
//        
//        try {
//            
//            URL url = new URL(requestUrl);
//            conn = (HttpURLConnection) url.openConnection();
//            
//            //设置请求方式
//            if ("GET" == method || null == method) {
//                conn.setRequestMethod("GET");
//            } else {
//                conn.setRequestMethod("POST");
//                //使用URL连接输出
//                conn.setDoOutput(true);
//            }
//            //设置请求内核
//            
//            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36");
//            //设置不使用缓存
//            conn.setUseCaches(false);
//            //设置链接超时时间,毫秒为单位
//conn.setConnectTimeout(1000);
////设置读取超时时间，毫秒为单位
//conn.setReadTimeout(1000);
////设置当前链接是否自动处理重定向。setFollowRedirects设置所有的链接是否自动处理重定向
//conn.setInstanceFollowRedirects(false);
////开启链接
//conn.connect();
////处理post请求时的参数
//if (null != data && "POST" == method) {
//DataOutputStream out = new DataOutputStream(conn.getOutputStream());
//out.writeBytes(urlEncode(data));
//}
////获取字符输入流
//br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
//String strContent = null;
//while ((strContent = br.readLine()) != null) {
//sb.append(strContent);
//}
//content = sb.toString();
//
//} catch (MalformedURLException e) {
//e.printStackTrace();
//} finally {
////关闭流和链接
//if (null != br) {
//br.close();
//}
//if (null != conn) {
//conn.disconnect();
//}
//}
//
//return content;
//}
//
//    //将map型转为请求参数型
//    public static String urlEncode(Map<String, ?> data) {
//        if (data == null) {
//            return "";
//        } else {
//            StringBuilder sb = new StringBuilder();
//            for (Map.Entry<String, ?> i : data.entrySet()) {
//                try {
//                    sb.append(i.getKey()).append("=").append(URLEncoder.encode(i.getValue() + "", "UTF-8")).append("&");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//
//
//}
//
//
