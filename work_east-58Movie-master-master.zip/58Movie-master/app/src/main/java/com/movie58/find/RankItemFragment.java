package com.movie58.find;

import android.os.Bundle;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.flyco.tablayout.SegmentTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.RankItemAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.RankItemInfo;
import com.movie58.home.MovieDetailActivity;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.orhanobut.logger.Logger;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/5/3 0003.
 */
public class RankItemFragment extends BaseFragment {

    @BindView(R.id.layout_tab4)
    SegmentTabLayout layoutTab;
    @BindView(R.id.rv4)
    RecyclerView rvList;

    private String[] mTitles = {"1天", "7天", "30天"};

    RankItemAdapter mAdapter;
    int catId;

    public static RankItemFragment newInstance(int catId) {
        RankItemFragment fragment = new RankItemFragment();
        Bundle b = new Bundle();
        b.putInt("id", catId);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        catId = b.getInt("id");
    }

    @Override
    protected void initView() {
        layoutTab.setTabData(mTitles);
        layoutTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                if (position == 0) {
                    getList("1");
                }else if(position == 1){
                    getList("7");
                }else{
                    getList("30");
                }
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
        layoutTab.setCurrentTab(0);
        getList("1");


        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).build());
        mAdapter = new RankItemAdapter(new ArrayList<>());
        mAdapter.bindToRecyclerView(rvList);

        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                if (view.getId() == R.id.btn_play) {
//                    if (Account.getInstance().isLogined()) {
                        ArrayMap<String, Object> map = new ArrayMap<>();
                        map.put("id", mAdapter.getItem(position).getId());
                        startActivity(MovieDetailActivity.class, map);
//                    }else{
//                        startActivity(LoginActivity.class);
//                    }
                }
            }
        });

    }

    private void getList(String str){

        Kalle.post(HttpUrl.MOST_LIST)
                .tag(tag + catId)
                .param("cat_id", catId)
                .param("section", str)
                .perform(new LoadingCallback<List<RankItemInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<RankItemInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        } else {
                            Logger.d(" cat_id = " + catId + " section = " + str);
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    private void initList(List<RankItemInfo> list){
        if (list == null) {
            list = new ArrayList<>();
        }

        mAdapter.setNewData(list);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Kalle.cancel(tag + catId);
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_rank_item;
    }


}
