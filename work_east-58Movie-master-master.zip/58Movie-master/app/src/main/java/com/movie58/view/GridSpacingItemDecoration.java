package com.movie58.view;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * 设置RecyclerView GridLayoutManager or StaggeredGridLayoutManager spacing
 */

public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

    private int widthSpace;//横向间距
    private int heightSpace;//竖向间距
    private int column ;//列数



    public GridSpacingItemDecoration(int column, int widthSpace, int heightSpace) {
        this.widthSpace = widthSpace;
        this.heightSpace = heightSpace;
        this.column = column;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        outRect.right = 0;
        outRect.bottom = heightSpace;
        //由于每行都只有3个，所以第一个都是3的倍数，把左边距设为0
        if (parent.getChildLayoutPosition(view) % column == 0) {
            outRect.left =  0;
        }else{
            outRect.left = widthSpace;
        }
    }

}