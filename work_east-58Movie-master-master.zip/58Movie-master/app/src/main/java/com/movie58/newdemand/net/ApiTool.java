package com.movie58.newdemand.net;


import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.zhy.base.cache.disk.DiskLruCacheHelper;

import org.xutils.common.Callback;
import org.xutils.common.util.KeyValue;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.io.IOException;
import java.util.List;


public class ApiTool {


    private RequestParams params;
    private String type;
    private ApiListener apiListener;
    private boolean isCache = false;
    private String key;
    private boolean isFirstCach;
    private String method;
    public int reConnectnum = 1;
    private DiskLruCacheHelper diskLruCacheHelper;
    private String result;

    public ApiTool() {
        try {
            diskLruCacheHelper = new DiskLruCacheHelper(x.app());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void setCachestate(boolean isCache) {
        this.isCache = isCache;
    }


    public void setFirstCach(boolean isFirstCach) {
        this.isFirstCach = isFirstCach;
    }

    public Callback.Cancelable getApi(RequestParams params, ApiListener apiListener, String type) {
        method = "get";
        this.params = params;
        this.type = type;
        this.params.setConnectTimeout(7000);
        this.apiListener = apiListener;


        if (TextUtils.isEmpty(key)) {
            initKey();
        }
        getCache();
        return null;
    }


    public Callback.Cancelable postApi(RequestParams params, ApiListener apiListener, String type) {
        method = "post";
        this.params = params;
        this.type = type;
        this.params.setConnectTimeout(7000);
        this.apiListener = apiListener;


        if (TextUtils.isEmpty(key)) {
            initKey();
        }
        getCache();
        return null;
    }

    private void initKey() {
        List<KeyValue> valueList = params.getStringParams();
        StringBuffer stringBuffer = new StringBuffer();
        for (KeyValue value : valueList) {
            String v1 = value.value.toString();
            String v2 = value.key;
            stringBuffer.append("&" + v2 + "=" + v1);
        }
        if (!TextUtils.isEmpty(stringBuffer.toString())){
            key = params.getUri() + stringBuffer.toString();
        }else{
            key = params.getUri();
        }

    }


    public void getCache() {
        try {
            if (isFirstCach) {
                threadGetCache();
            } else {
                goNet();
            }
        } catch (Exception e) {
        }
    }

    private void threadGetCache() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (diskLruCacheHelper != null) {
                    String time = diskLruCacheHelper.getAsString(key + "@_time");
                    if (!TextUtils.isEmpty(time) && System.currentTimeMillis() - Long.parseLong(time) <= 1000 * 30) {
                        result = diskLruCacheHelper.getAsString(key);
                    }
                }

                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        threadUI(result);
                    }
                });
            }
        }).start();
    }

    private void threadUI(String result) {
        if (TextUtils.isEmpty(result)) {
            goNet();
        } else {
            try {
                this.apiListener.onComplete(params, result, type);
            } catch (Exception e) {

            }
        }
    }


    private void goNet() {
        if (method.equals("post")) {
            x.http().post(this.params, new DefaultRequestCallBack());
        } else {
            x.http().get(this.params, new DefaultRequestCallBack());
        }
    }



    public void reConnet() {
        if (reConnectnum == 2) {
            if (isCache) {
                String result = null;
                if (diskLruCacheHelper != null) {
                    result = diskLruCacheHelper.getAsString(key);
                } else {
                    this.apiListener.onExceptionType(null, params, type);
                }

                if (TextUtils.isEmpty(result)) {
                    this.apiListener.onExceptionType(null, params, type);
                } else {
                    this.apiListener.onComplete(params, result, type);
                }
            } else {
                this.apiListener.onExceptionType(null, params, type);
            }
            reConnectnum = 1;

        } else if (reConnectnum < 2) {
            if (method.equals("post")) {
                postApi(params, apiListener, type);
            } else {
                getApi(params, apiListener, type);
            }
            reConnectnum++;
        } else {
            this.apiListener.onExceptionType(null, params, type);
            reConnectnum = 1;
        }
    }

    private class DefaultRequestCallBack implements Callback.CacheCallback<String> {


        @Override
        public void onSuccess(String result) {
            try {
                int e = parseError(result);
                if (e == 0) {
                    if (ApiTool.this.apiListener != null) {
                        reConnectnum = 1;
                        if (isCache) {
                            saveData(result);
                        }
                        ApiTool.this.apiListener.onComplete(params, result, type);
                    }
                } else if (ApiTool.this.apiListener != null) {
                    ApiTool.this.apiListener.onError(e, params);
                }
            } catch (Exception var4) {
                if (ApiTool.this.apiListener != null) {
                }
            }
        }

        public void saveData(String data) {

            if (diskLruCacheHelper == null) {
                return;
            }
            diskLruCacheHelper.remove(key);
            diskLruCacheHelper.remove(key + "@_time");
            diskLruCacheHelper.put(key, data);
            diskLruCacheHelper.put(key + "@_time", System.currentTimeMillis() + "");
        }

        public void onError(Throwable ex, boolean isOnCallback) {
            try {
                reConnet();
            } catch (Exception var4) {

            }
        }

        public void onCancelled(CancelledException cex) {

            try {
                ApiTool.this.apiListener.onCancelled(cex);
            } catch (Exception var4) {

            }
        }

        public void onFinished() {

        }


        @Override
        public boolean onCache(String result) {
            return false;
        }
    }

    public static int parseError(String json) {
        if (json.startsWith("[") && json.endsWith("]")) {
            return 0;
        } else if (json.startsWith("{") && json.endsWith("}")) {
            return 0;
        } else {
            return 2;
        }
    }
}

