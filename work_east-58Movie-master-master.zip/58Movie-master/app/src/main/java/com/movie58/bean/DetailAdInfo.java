package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/29 0029.
 */
public class DetailAdInfo {

    /**
     * vod_advert : {"id":10,"advert_name":"小红书","advert_url":"https://www.xiaohongshu.com/","advert_img":"http://47.105.218.54/upload/advert/20190509/b25649006891732a9cf9aad445925286.jpeg","advert_desc":"年轻人的穿搭指南11","create_time":1557204633,"update_time":1557204633}
     * barrage_advert : {"message":"弹幕广告走起"}
     */

    private VodAdvertBean vod_advert;
    private BarrageAdvertBean barrage_advert;

    public VodAdvertBean getVod_advert() {
        return vod_advert;
    }

    public void setVod_advert(VodAdvertBean vod_advert) {
        this.vod_advert = vod_advert;
    }

    public BarrageAdvertBean getBarrage_advert() {
        return barrage_advert;
    }

    public void setBarrage_advert(BarrageAdvertBean barrage_advert) {
        this.barrage_advert = barrage_advert;
    }

    public static class VodAdvertBean {
        /**
         * id : 10
         * advert_name : 小红书
         * advert_url : https://www.xiaohongshu.com/
         * advert_img : http://47.105.218.54/upload/advert/20190509/b25649006891732a9cf9aad445925286.jpeg
         * advert_desc : 年轻人的穿搭指南11
         * create_time : 1557204633
         * update_time : 1557204633
         */

        private int id;
        private String advert_name;
        private String advert_url;
        private String advert_img;
        private String advert_desc;
        private int create_time;
        private int update_time;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getAdvert_name() {
            return advert_name;
        }

        public void setAdvert_name(String advert_name) {
            this.advert_name = advert_name;
        }

        public String getAdvert_url() {
            return advert_url;
        }

        public void setAdvert_url(String advert_url) {
            this.advert_url = advert_url;
        }

        public String getAdvert_img() {
            return advert_img;
        }

        public void setAdvert_img(String advert_img) {
            this.advert_img = advert_img;
        }

        public String getAdvert_desc() {
            return advert_desc;
        }

        public void setAdvert_desc(String advert_desc) {
            this.advert_desc = advert_desc;
        }

        public int getCreate_time() {
            return create_time;
        }

        public void setCreate_time(int create_time) {
            this.create_time = create_time;
        }

        public int getUpdate_time() {
            return update_time;
        }

        public void setUpdate_time(int update_time) {
            this.update_time = update_time;
        }
    }

    public static class BarrageAdvertBean {
        /**
         * message : 弹幕广告走起
         */

        private String message;

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
