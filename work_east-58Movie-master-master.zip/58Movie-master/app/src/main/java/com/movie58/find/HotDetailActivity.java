package com.movie58.find;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.blankj.utilcode.util.ScreenUtils;
import com.cbman.roundimageview.RoundImageView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.gyf.immersionbar.ImmersionBar;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.HotImageAdapter;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.DetailInfo;
import com.movie58.bean.HotDetailInfo;
import com.movie58.bean.MovieReviewInfo;
import com.movie58.bean.ShareBean;
import com.movie58.event.Event;
import com.movie58.home.MovieDetailActivity;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.DensityUtil;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.PermissionUtil;
import com.movie58.util.ToolUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.movie58.view.ZoomOutPageTransformer;
import com.orhanobut.logger.Logger;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yanzhenjie.permission.runtime.Permission;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/5 0005.
 */
public class HotDetailActivity extends BaseUseActivity {

    @BindView(R.id.root)
    LinearLayout layoutRoot;
    @BindView(R.id.root1)
    LinearLayout layoutRoot1;
    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.iv_right)
    ImageView ivRight;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.top)
    LinearLayout top;
    @BindView(R.id.tv_send)
    TextView tvSend;
    @BindView(R.id.tv_comment)
    TextView tvComment;
    @BindView(R.id.et_common)
    EditText etCommon;
    @BindView(R.id.tv_title1)
    TextView tvTitle1;
    @BindView(R.id.tv_date)
    TextView tvDate;
    @BindView(R.id.tv_content)
    TextView tvContent;
    @BindView(R.id.vp)
    ViewPager vp;
    @BindView(R.id.tv_name)
    TextView tvName;
    @BindView(R.id.tv_type)
    TextView tvType;
    @BindView(R.id.btn_collect)
    SuperButton btnCollect;
    @BindView(R.id.tv_daoyan)
    TextView tvDaoyan;
    @BindView(R.id.tv_yanyuan)
    TextView tvYanyuan;
    @BindView(R.id.tv_info)
    TextView tvInfo;
    @BindView(R.id.tv_more)
    TextView tvMore;
    @BindView(R.id.tv_xiangguan)
    TextView tvXiangguan;
    @BindView(R.id.iv_play)
    ImageView ivPlay;
    @BindView(R.id.layout)
    LinearLayout layout;
    @BindView(R.id.rv_pl)
    RecyclerView rvPl;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.tv_null)
    TextView tvNull;
    @BindView(R.id.layout_bottom1)
    FrameLayout layoutBottom1;
    @BindView(R.id.layout_bottom2)
    RelativeLayout layoutBottom2;
    @BindView(R.id.layout_bottom3)
    RelativeLayout layoutBottom3;
    @BindView(R.id.btn_send)
    Button btnSend;

    String strId;

    HotDetailInfo hotInfo;
    DetailInfo movieInfo;

    int width, height;
    int page = 1;
    ReviewAdapter reviewAdapter;
    String bgImg;
    String bgColor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersionBar.with(getMActivity())
                .keyboardEnable(true)
                .init();
    }


    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        strId = b.getString("id");
        bgImg = b.getString("bg");
        bgColor = b.getString("color");
    }

    @Override
    protected void initView() {
        ivRight.setImageResource(R.drawable.top_share);

        int widthPix = ScreenUtils.getScreenWidth() - DensityUtil.dp2px(30);
        width = widthPix / 3;
        height = width / 2 * 3;
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.setMargins(DensityUtil.dp2px(15), DensityUtil.dp2px(15), 0, DensityUtil.dp2px(15));
        vp.setLayoutParams(params);

        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                ToolUtil.hideSoftInput(etCommon);
                layoutBottom2.setVisibility(View.VISIBLE);
                layoutBottom3.setVisibility(View.GONE);
                etCommon.clearFocus();

                return vp.dispatchTouchEvent(event);
            }
        });


        layoutRefresh.setEnableRefresh(false);

        etCommon.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (TextUtils.isEmpty(s)) {
                    btnSend.setEnabled(false);
                }else{
                    btnSend.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        layoutRefresh.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getReview();
            }
        });


        /**
         * 软键盘上推布局
         */
        layoutBottom1.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect rect = new Rect();
            layoutBottom1.getWindowVisibleDisplayFrame(rect);
            int availableHeight = rect.bottom - layoutBottom1.getTop();
            View focusedChild = layoutBottom1.getFocusedChild();
            float contentHeight = 0;
            if (focusedChild != null) {
                contentHeight = focusedChild.getY() + focusedChild.getHeight();
            }
            int deltaY = (int) (availableHeight - contentHeight);

            if (deltaY <0) {
                layoutBottom1.setTranslationY(deltaY);
            } else {
                layoutBottom1.setTranslationY(0);
            }
        });
        setupUI(layoutRoot);

        layoutRoot.postDelayed(new Runnable() {
            @Override
            public void run() {
                getDetail();

            }
        }, 100);
        if (!TextUtils.isEmpty(bgImg)) {
            PicassoUtils.downLoadImg(getMActivity(), bgImg, new PicassoUtils.DownLoadListener() {
                @Override
                public void DownLoadSuc(Bitmap path) {
                    layoutRoot.setBackground(new BitmapDrawable(path));

                    try {
                        String color = "#33" + bgColor.substring(1);
                        int color1 = Color.parseColor(color);
                        layoutRoot1.setBackgroundColor(color1);
                    }catch (Exception e){

                    }

                }

                @Override
                public void DownLoadFail() {

                }
            });
        }

    }


    /**
     * 点击edittext之外的部分使软键盘隐藏
     * @param view
     */
    public void setupUI(View view) {

        if (view.getId() != R.id.btn_send && view.getId() != R.id.et_common && view.getId() != R.id.layout) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    ToolUtil.hideSoftInput(etCommon);
                    layoutBottom2.setVisibility(View.VISIBLE);
                    layoutBottom3.setVisibility(View.GONE);
                    etCommon.clearFocus();
                    return false;
                }
            });
        }

        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView);
            }
        }
    }

    @OnClick({R.id.iv_back, R.id.iv_right, R.id.btn_collect, R.id.tv_more, R.id.tv_comment, R.id.btn_send})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.iv_right:
                new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                    @Override
                    public void onGranted() {
                        getShareInfo();
                    }
                }).showPermission(Permission.Group.STORAGE);
                break;
            case R.id.btn_collect:
                if (movieInfo == null) {
                    return;
                }
                if (movieInfo.getIs_collect() == 1) {
                    collectCancel();
                }else{
                    toCollect();
                }
                break;
            case R.id.tv_more:
                if (movieInfo == null) {
                    return;
                }
//                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("id", movieInfo.getId());
                    startActivity(MovieDetailActivity.class, map);
//                }else{
//                    startActivity(LoginActivity.class);
//                }
                break;
            case R.id.tv_comment:
                layoutBottom2.setVisibility(View.GONE);
                layoutBottom3.setVisibility(View.VISIBLE);
                etCommon.requestFocus();
                ToolUtil.showSoftInput(etCommon);
                break;
            case R.id.btn_send:
                String review = etCommon.getText().toString().trim();
                toReview(review);
                break;
        }
    }

    private void getShareInfo() {
        Kalle.get(HttpUrl.SHARE_INFO)
                .tag(tag)
                .perform(new LoadingCallback<ShareBean>(this) {

                    @Override
                    public void onFinaly(SimpleResponse<ShareBean, String> response) {
                        if (response.isSucceed()) {
                            ShareBean shareBean = response.succeed();
                            if (shareBean==null||TextUtils.isEmpty(shareBean.getShare_url())){
                                ToastUtils.show("获取分享地址失败");
                                return;
                            }
                            share(shareBean.getShare_url());
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });

    }

    private void share(String share_url){
        new ShareAction(HotDetailActivity.this)
                .setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE, SHARE_MEDIA.SINA)
                .setShareboardclickCallback(new ShareBoardlistener() {
                    @Override
                    public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                        UMImage image = new UMImage(getMActivity(), R.drawable.erweima);
                        UMWeb web = new UMWeb(share_url);
                        web.setTitle("58影视，各种大片抢先看");
                        web.setThumb(image);
                        web.setDescription("58影视，各种最新资源，各种热播大片，实时更新，带你一饱眼福");
                        new ShareAction(getMActivity())
                                .setPlatform(share_media)
                                .withMedia(web)
                                .setCallback(new UMShareListener() {
                                    @Override
                                    public void onStart(SHARE_MEDIA share_media) {
                                        Logger.d("33333333333333333333333333");
                                    }

                                    @Override
                                    public void onResult(SHARE_MEDIA share_media) {
                                        if (share_media == SHARE_MEDIA.WEIXIN || share_media == SHARE_MEDIA.WEIXIN_CIRCLE) {
                                            save(6);
                                        }else if(share_media == SHARE_MEDIA.QQ || share_media == SHARE_MEDIA.QZONE){
                                            save(6);
                                        }else{
                                            save(6);
                                        }
                                    }

                                    @Override
                                    public void onError(SHARE_MEDIA share_media, Throwable throwable) {
                                        Logger.d("222222222222222 " + throwable.getMessage());
                                    }

                                    @Override
                                    public void onCancel(SHARE_MEDIA share_media) {

                                    }
                                })
                                .share();
                    }
                }).open();
    }

    private void save(int id){
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            ToastUtils.show("分享成功，+" +gold + " 金币");
                        }else{

                        }
                    }
                });
    }

    private void getDetail(){
        Kalle.get(HttpUrl.PROJECT_DETAIL)
                .tag(tag)
                .param("project_id", strId)
                .perform(new LoadingCallback<HotDetailInfo>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<HotDetailInfo, String> response) {
                        if (response.isSucceed()) {
                            hotInfo = response.succeed();
                            if (hotInfo == null) {
                                return;
                            }
                            init();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void init(){
        tvTitle.setText(hotInfo.getProject_name());
        tvTitle1.setText(hotInfo.getProject_name());
        tvDate.setText(ToolUtil.getTime(hotInfo.getUpdate_time()));
        tvContent.setText(hotInfo.getProject_desc());
        List<HotDetailInfo.ParamsBean.ListBean> list = new ArrayList<>();
        list.addAll(hotInfo.getParams().getList());
        if (list != null && !list.isEmpty()) {
            vp.setAdapter(new HotImageAdapter(getMActivity(), list, width, height));
//        vp.setPageMargin(15);
            vp.setOffscreenPageLimit(list.size());
            vp.setPageTransformer(true, new ZoomOutPageTransformer());

            vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int i, float v, int i1) {

                }

                @Override
                public void onPageSelected(int i) {
                    initMovie(list.get(i));
                }

                @Override
                public void onPageScrollStateChanged(int i) {

                }
            });

            vp.setCurrentItem(0);
            initMovie(list.get(0));
        }

        reviewAdapter = new ReviewAdapter(new ArrayList<>());
        rvPl.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
//        rvPl.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
//                .color(getMActivity().getResources().getColor(R.color.line))
//                .marginProvider(new HorizontalDividerItemDecoration.MarginProvider() {
//                    @Override
//                    public int dividerLeftMargin(int position, RecyclerView parent) {
//                        return getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_15);
//                    }
//
//                    @Override
//                    public int dividerRightMargin(int position, RecyclerView parent) {
//                        return 0;
//                    }
//                }).build());
        reviewAdapter.bindToRecyclerView(rvPl);
        reviewAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                if (view.getId() == R.id.tv_zan) {
                    int zan = reviewAdapter.getItem(position).getIs_top();
                    int id = reviewAdapter.getItem(position).getId();
                    if (zan == 1) {
                        zanCancel(id);
                    }else{
                        toZan(id);
                    }
                }
            }
        });
        getReview();

    }

    private void initMovie(HotDetailInfo.ParamsBean.ListBean info){
        getMovie(info.getVod_id());

    }

    private void getMovie(String id) {
        Kalle.get(HttpUrl.DETAIL)
                .tag(tag)
                .param("id", id)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            movieInfo = FastJsonUtil.toBean(response.succeed(), "vod_info", DetailInfo.class);
                            tvName.setText(movieInfo.getSource_name());
                            tvDaoyan.setText(movieInfo.getDirector());
                            tvYanyuan.setText(movieInfo.getLead_role());
                            tvInfo.setText(movieInfo.getDetail_desc());
                            String strType = "";
                            for (DetailInfo.TypeBean bean : movieInfo.getTypes()){
                                strType = strType + "/" + bean.getType_name();
                            }
                            if (!TextUtils.isEmpty(strType)) {
                                tvType.setText(strType.substring(1));
                            }
                            if (movieInfo.getIs_collect() == 1) {
                                btnCollect.setText("已收藏");
                            }else{
                                btnCollect.setText("+收藏");
                            }
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void toCollect() {
        Kalle.post(HttpUrl.MOVIE_COLLECT)
                .tag(tag)
                .param("vod_id", movieInfo.getId())
                .param("cat_id", movieInfo.getCat_id())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            btnCollect.setText("已收藏");
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    private void collectCancel() {
        Kalle.post(HttpUrl.MOVIE_COLLECT_CANCEL)
                .tag(tag)
                .param("vod_id", movieInfo.getId())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            btnCollect.setText("+收藏");
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event e){
        switch (e.getEvent()){
            case Event.CODE_09_SCHOOL_RESULT_REFRESH:
                int pos = (Integer) e.getObj1();
                if (vp.getCurrentItem() == pos) {
                    if (movieInfo == null) {
                        return;
                    }
//                    if (Account.getInstance().isLogined()) {
                        ArrayMap<String, Object> map = new ArrayMap<>();
                        map.put("id", movieInfo.getId());
                        startActivity(MovieDetailActivity.class, map);
//                    }else{
//                        startActivity(LoginActivity.class);
//                    }
                }else{
                    vp.setCurrentItem(pos);
                }
                break;
        }
    }

    private void toReview(String str) {
        Kalle.post(HttpUrl.PROJECT_COMMENT_PUBLISH)
                .tag(tag)
                .param("project_id", strId)
                .param("comments", str)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToolUtil.hideSoftInput(etCommon);
                            layoutBottom2.setVisibility(View.VISIBLE);
                            layoutBottom3.setVisibility(View.GONE);
                            etCommon.clearFocus();
                            etCommon.setText("");
                            ToastUtils.show("评论成功");
                            page = 1;
                            getReview();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void getReview() {
        Kalle.post(HttpUrl.PROJECT_COMMENT)
                .tag(tag)
                .param("project_id", strId)
                .param("page", page)
                .param("size", 10)
                .perform(new LoadingCallback<List<MovieReviewInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<MovieReviewInfo>, String> response) {
                        if (response.isSucceed()) {
                            initReview(response.succeed());
                        } else {
                            ToastUtils.show(response.failed());
                            layoutRefresh.finishLoadMore();
                            page --;
                        }
                    }
                });
    }

    private void initReview(List<MovieReviewInfo> list){
        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                reviewAdapter.setNewData(null);
                tvNull.setVisibility(View.VISIBLE);
            }else{
                reviewAdapter.setNewData(list);
                tvNull.setVisibility(View.GONE);
            }
        }else{
            reviewAdapter.addData(list);
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }
        layoutRefresh.finishLoadMore();
    }

    private void toZan(int id) {
        Kalle.post(HttpUrl.PROJECT_ZAN)
                .tag(tag)
                .param("project_id", strId)
                .param("comment_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            for (MovieReviewInfo info : reviewAdapter.getData()){
                                if (info.getId() == id) {
                                    info.setIs_top(1);
                                    info.setTop_num(info.getTop_num() + 1);
                                    break;
                                }
                            }
                            reviewAdapter.notifyDataSetChanged();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void zanCancel(int id) {
        Kalle.post(HttpUrl.PROJECT_ZAN_CANCEL)
                .tag(tag)
                .param("comment_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            for (MovieReviewInfo info : reviewAdapter.getData()){
                                if (info.getId() == id) {
                                    info.setIs_top(0);
                                    info.setTop_num(info.getTop_num() - 1);
                                    break;
                                }
                            }
                            reviewAdapter.notifyDataSetChanged();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_hot_detail;
    }

    private class ReviewAdapter extends BaseQuickAdapter<MovieReviewInfo, BaseViewHolder> {

        public ReviewAdapter(@Nullable List<MovieReviewInfo> data) {
            super(R.layout.item_hot_review, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, MovieReviewInfo item) {
            RoundImageView ivImg = helper.getView(R.id.iv_head);
            PicassoUtils.LoadImageWithDetfult(mContext, item.getAvatar(), ivImg, R.drawable.avatar);
            helper.setText(R.id.tv_name1, item.getSend_user_name())
                    .setText(R.id.tv_date1, item.getUpdate_time())
                    .setText(R.id.tv_review, item.getComments())
                    .setText(R.id.tv_zan, item.getTop_num() + "")
                    .addOnClickListener(R.id.tv_zan);
            TextView tvZan = helper.getView(R.id.tv_zan);
            if (item.getIs_top() == 1) {
                tvZan.setCompoundDrawablesWithIntrinsicBounds(R.drawable.zan1, 0, 0, 0);
            }else{
                tvZan.setCompoundDrawablesWithIntrinsicBounds(R.drawable.zan, 0, 0, 0);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }
}
