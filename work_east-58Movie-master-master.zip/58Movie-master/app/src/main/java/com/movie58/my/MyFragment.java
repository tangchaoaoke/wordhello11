package com.movie58.my;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.allen.library.SuperTextView;
import com.blankj.utilcode.util.SPUtils;
import com.cbman.roundimageview.RoundImageView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.ui.history.PlayRecordNoLogin2Aty;
import com.movie58.newdemand.utils.PhoneIdUitls;
import com.movie58.account.Account;
import com.movie58.account.LoginActivity;
import com.movie58.account.RegisterActivity;
import com.movie58.activity.WebViewActivity;
import com.movie58.adapter.PlayTagAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.PlayTagInfo;
import com.movie58.bean.QQInfo;
import com.movie58.event.Event;
import com.movie58.home.MovieDetailActivity;
import com.movie58.home.PlayHistoryActivity;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.share.ShareActivity;
import com.movie58.task.ConvertListActivity;
import com.movie58.task.JinbiActivity;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.ResourceUtils;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.movie58.util.ToolsQQ;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.VerticalDividerItemDecoration;
import com.zhy.autolayout.utils.AutoUtils;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class MyFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.iv_right)
    ImageView ivRight;
    @BindView(R.id.iv_head)
    RoundImageView ivHead;
    @BindView(R.id.tv_name)
    TextView tvName;
    @BindView(R.id.btn_grade)
    SuperButton btnGrade;
    @BindView(R.id.layout_collect)
    SuperTextView layoutCollect;
    @BindView(R.id.layout_convert)
    SuperTextView layoutConvert;
    @BindView(R.id.layout_name)
    LinearLayout layoutName;
    @BindView(R.id.layout_login)
    LinearLayout layoutLogin;
    @BindView(R.id.tv_login)
    TextView tvLogin;
    @BindView(R.id.tv_register)
    TextView tvRegister;
    @BindView(R.id.tv_record)
    TextView tvRecord;
    @BindView(R.id.layout_record)
    RelativeLayout layoutRecord;
    @BindView(R.id.rv_more)
    RecyclerView rvMore;
    @BindView(R.id.iv_msg)
    ImageView ivMsg;
    @BindView(R.id.iv_ad)
    ImageView ivAd;
    @BindView(R.id.tv_gold)
    TextView tvGold;
    @BindView(R.id.relay_top)
    RelativeLayout relay_top;
    @BindView(R.id.relay)
    RelativeLayout relay;

    PlayTagAdapter mAdapter;
    String adUrl;
    String adImg;
    String adTitle;

    public static MyFragment newInstance() {
        return new MyFragment();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initTopview(relay, relay_top, AutoUtils.getPercentHeightSize(380));
    }

    @Override
    protected void initView() {
        tvTitle.setText("我的");


        //播放记录
        mAdapter = new PlayTagAdapter(new ArrayList<>());
        WrapContentLinearLayoutManager layoutManager = new WrapContentLinearLayoutManager(getMActivity());
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        rvMore.setLayoutManager(layoutManager);
        rvMore.addItemDecoration(new VerticalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.transparent)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvMore);
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                PlayTagInfo item = mAdapter.getItem(position);
                String strId = item.getVod_id();
                String playAnthology = item.getPlay_anthology();
                int playedTime = item.getPlayed_time();
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("id", strId);
                if (ResourceUtils.isNumeric(playAnthology)) {
                    map.put("play_anthology", Integer.valueOf(playAnthology));
                }
                map.put("played_time", playedTime);
                startActivity(MovieDetailActivity.class, map);
            }
        });
    }

    @Override
    public void onSupportVisible() {
        if (Account.getInstance().isLogined()) {
            layoutName.setVisibility(View.VISIBLE);
            layoutLogin.setVisibility(View.GONE);
            tvName.setText(TextUtils.isEmpty(Account.getInstance().getUserName()) ? Account.getInstance().getInviteCode() : Account.getInstance().getUserName());
            getGold();
            if (TextUtils.isEmpty(Account.getInstance().getAvatar())) {
                ivHead.setImageResource(R.drawable.avatar);
            } else {
                PicassoUtils.LoadImageWithDetfult(getMActivity(), Account.getInstance().getAvatar(), ivHead, R.drawable.avatar);
            }
            btnGrade.setText(Account.getInstance().getLevel());
//            if (SPUtils.getInstance().getBoolean(SPContant.PLAY_HISTORY, false)) {
//                getPlayLog();
//                SPUtils.getInstance().put(SPContant.PLAY_HISTORY, false);
//            } else {
//                if (mAdapter == null || mAdapter.getData() == null || mAdapter.getData().isEmpty()) {
//                    getPlayLog();
//                }
//            }
            getPlayLog();
            getAd();
        } else {
            layoutName.setVisibility(View.GONE);
            layoutLogin.setVisibility(View.VISIBLE);
            tvGold.setText("");
            tvRecord.setVisibility(View.GONE);
            if (mAdapter != null && !mAdapter.getData().isEmpty()) {
                mAdapter.getData().clear();
                mAdapter.notifyDataSetChanged();
            }
            rvMore.setVisibility(View.GONE);
        }
    }

    @OnClick({R.id.iv_back, R.id.iv_right, R.id.tv_record, R.id.layout_collect, R.id.layout_convert, R.id.tv_money, R.id.tv_task, R.id.tv_convert,
            R.id.tv_invite, R.id.tv_potato, R.id.tv_qq, R.id.tv_help, R.id.tv_home, R.id.tv_login, R.id.tv_register, R.id.layout_cache,
            R.id.btn_grade, R.id.iv_msg, R.id.iv_ad, R.id.layout_record})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                EventBus.getDefault().post(new Event(Event.CODE_01_TAB_HOME));
                break;
            case R.id.iv_msg:
                if (Account.getInstance().isLogined()) {
                    startActivity(MsgActivity.class);
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.iv_right:
                if (Account.getInstance().isLogined()) {
                    startActivity(SettingActivity.class);
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.tv_money:
                if (Account.getInstance().isLogined()) {
                    startActivity(JinbiActivity.class);
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.tv_task:
                if (Account.getInstance().isLogined()) {
                    EventBus.getDefault().post(new Event(Event.CODE_14_AVATAR));
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.tv_convert: //兑换中芯
                if (Account.getInstance().isLogined()) {
                    startActivity(ConvertListActivity.class);
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.tv_invite: //邀请好友
                if (Account.getInstance().isLogined()) {
                    startActivity(ShareActivity.class);
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.tv_record:
            case R.id.layout_record:
                if (Account.getInstance().isLogined()) {
                    startActivity(PlayHistoryActivity.class);
                } else {
                    startActivity(PlayRecordNoLogin2Aty.class);
                }
                break;
            case R.id.layout_collect:
                if (Account.getInstance().isLogined()) {
                    startActivity(CollectActivity.class);
                } else {
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.layout_convert:
                if (Account.getInstance().isLogined()) {
                    startActivity(ConvertActivity.class);
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.tv_potato:
                getQqInfo(true);
                break;
            case R.id.tv_qq:
                getQqInfo(false);
                break;
            case R.id.tv_help:
                startActivity(HelpActivity.class);
                break;
            case R.id.tv_home: {
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("url", "http://58ys.com");
                startActivity(WebViewActivity.class, map);
            }
            break;
            case R.id.tv_login:
                startActivity(LoginActivity.class);
                break;
            case R.id.tv_register:
                startActivity(RegisterActivity.class);
                break;
            case R.id.layout_cache:
                if (Account.getInstance().isLogined()) {
                    startActivity(CacheActivity.class);
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.btn_grade:
                if (Account.getInstance().isLogined()) {
                    startActivity(LevelActivity.class);
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
            case R.id.iv_ad:
                if (Account.getInstance().isLogined()) {
                    if (TextUtils.isEmpty(adUrl)) {
                        return;
                    }
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("url", adUrl);
                    map.put("title", adTitle);
                    startActivity(WebViewActivity.class, map);
                    addExp();
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
            default:
                break;
        }
    }

    private void getGold() {
        Kalle.get(HttpUrl.GOLD_LIST)
                .param("page", 1)
                .param("szie", 10)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String json = response.succeed();
                            String gold = FastJsonUtil.toString(json, "total_gold_num");
                            tvGold.setText(gold);
                        }
                    }
                });
    }

    private void getPlayLog() {
        Kalle.post(HttpUrl.PLAY_LOG)
                .tag(tag)
                .param("page", 1)
                .param("size", 10)
                .param("imei", PhoneIdUitls.getID(getActivity()))
                .perform(new NormalCallback<List<PlayTagInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<PlayTagInfo>, String> response) {
                        if (response.isSucceed()) {
                            if (response.succeed() == null || response.succeed().isEmpty()) {
                                tvRecord.setVisibility(View.GONE);
                                rvMore.setVisibility(View.GONE);
                            } else {
                                mAdapter.setNewData(response.succeed());
                                tvRecord.setVisibility(View.VISIBLE);
                                rvMore.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                });
    }

    private void getQqInfo(boolean isQQ) {
        Kalle.post(HttpUrl.QQ_INFOR)
                .tag(tag)
                .perform(new LoadingCallback<QQInfo>(getActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<QQInfo, String> response) {
                        if (response.isSucceed()) {
                            actionQq(isQQ, response.succeed());
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void actionQq(boolean isQq, QQInfo data) {
        if (isQq && !TextUtils.isEmpty(data.getPotato_url())) {
            ToolsQQ.joinQQ(getContext(), data.getPotato_url());
            return;
        }
        if (!isQq && !TextUtils.isEmpty(data.getQq())) {
            ToolUtil.copyString(data.getQq(), getContext());
        }
    }

    private void getAd() {
        Kalle.post(HttpUrl.GET_AD)
                .tag(tag)
                .param("position_code", "personal")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            adUrl = FastJsonUtil.toString(response.succeed(), "advert_url");
                            if (!TextUtils.isEmpty(adUrl)) {
                                ivAd.setVisibility(View.VISIBLE);
                                adImg = FastJsonUtil.toString(response.succeed(), "advert_img");
                                adTitle = FastJsonUtil.toString(response.succeed(), "advert_name");
                                PicassoUtils.LoadImageWithDetfult(getMActivity(), adImg, ivAd, R.drawable.pic_emptypage_failure);
                            }

                        } else {
                            ivAd.setVisibility(View.GONE);
                        }
                    }
                });
    }

    private void addExp() {
        Kalle.get(HttpUrl.ADD_EXP)
                .tag(tag)
                .param("rule_code", "play_advert")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            SPUtils.getInstance().put(SPContant.LOGIN_SUC, ToolUtil.getCurrentDate());
//                            String bi = FastJsonUtil.toString(response.succeed(), "experience_num");
//                            ToastUtils.show("登录成功,+" + bi + " 经验值");
                        } else {

                        }
                    }
                });
    }


//    @Override
//    public void onResume() {
//        super.onResume();
//        if (Account.getInstance().isLogined()){
//            Log.e("")
//            tvName.setText(Account.getInstance().getUserName());
//            layoutName.setVisibility(View.VISIBLE);
//            layoutLogin.setVisibility(View.GONE);
//        }else{
//            layoutName.setVisibility(View.GONE);
//            layoutLogin.setVisibility(View.VISIBLE);
//        }
//    }

//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void onEvent(Event event) {
//        switch (event.getEvent()) {
//            case Event.CODE_48_LOGIN_IN:
//                tvName.setText(Account.getInstance().getUserName());
//                layoutName.setVisibility(View.VISIBLE);
//                layoutLogin.setVisibility(View.GONE);
//                break;
//            case Event.CODE_49_LOGIN_OUT:
//                layoutName.setVisibility(View.GONE);
//                layoutLogin.setVisibility(View.VISIBLE);
//                break;
//            case Event.CODE_61_REFRESH_PLAY_HISTORY:
//                getPlayLog();
//                break;
//            default:
//                break;
//        }
//    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_my;
    }
}
