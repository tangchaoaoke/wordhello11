package com.movie58.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.movie58.R;
import com.movie58.bean.UpdateInfo;

/**
 * Created by yangxing on 2019/6/21 0021.
 */
public class UpdateDialog extends Dialog {

    UpdateInfo updateInfo;
    Context ctx;

    public UpdateDialog(@NonNull Context context, UpdateInfo info) {
        super(context);
        updateInfo = info;
        ctx = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_update);

        TextView tvTitle = findViewById(R.id.tv_title);
        TextView tvName = findViewById(R.id.tv_content);
        tvTitle.setText(updateInfo.getTitle());
        tvName.setText(updateInfo.getContent());


        findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dismiss();
            }
        });

        findViewById(R.id.btn1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(updateInfo.getAndroid_redirect_url()));
                    ctx.startActivity(intent);
                } catch (Exception e) {


                }
                dismiss();
            }
        });
    }
}
