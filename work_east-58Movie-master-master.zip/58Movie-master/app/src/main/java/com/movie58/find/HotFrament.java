package com.movie58.find;

import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.adapter.HotAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.FindHotInfo;
import com.movie58.bean.ShareBean;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.PermissionUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.orhanobut.logger.Logger;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yanzhenjie.permission.runtime.Permission;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/4/26 0026.
 */
public class HotFrament extends BaseFragment {

    @BindView(R.id.rv_list1)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh1)
    SmartRefreshLayout layoutRefresh;

    int page = 1;
    HotAdapter mAdapter;

    public static HotFrament newInstance() {
        return new HotFrament();
    }

    @Override
    protected void initView() {
        mAdapter = new HotAdapter(new ArrayList<>());
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvList);
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("id", mAdapter.getItem(position).getId());
                    map.put("color", mAdapter.getItem(position).getProject_color());
                    map.put("bg", mAdapter.getItem(position).getProject_background());
                    startActivity(HotDetailActivity.class, map);
//                }else{
//                    startActivity(LoginActivity.class);
//                }

            }
        });

        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                switch (view.getId()){
                    case R.id.iv_share:
                        new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                            @Override
                            public void onGranted() {
                                getShareInfo();
                            }
                        }).showPermission(Permission.Group.STORAGE);
                        break;
                }
            }
        });
        layoutRefresh.autoRefresh();
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page ++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });

    }

    private void getShareInfo() {
        Kalle.get(HttpUrl.SHARE_INFO)
                .tag(tag)
                .perform(new LoadingCallback<ShareBean>(getActivity()) {

                    @Override
                    public void onFinaly(SimpleResponse<ShareBean, String> response) {
                        if (response.isSucceed()) {
                            ShareBean shareBean = response.succeed();
                            if (shareBean==null|| TextUtils.isEmpty(shareBean.getShare_url())){
                                ToastUtils.show("获取分享地址失败");
                                return;
                            }
                            share(shareBean.getShare_url());
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void getList(){
        Kalle.post(HttpUrl.PROJECT_LIST)
                .tag(tag)
                .param("page", page)
                .param("size", 10)
                .perform(new NormalCallback<List<FindHotInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<FindHotInfo>, String> response) {
                        if (response.isSucceed()) {
                            initList(response.succeed());
                        }else{
                            initList(null);
                        }
                    }
                });
    }

    private void initList(List<FindHotInfo> list){
        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            }else{
                mAdapter.setNewData(list);
            }
            layoutRefresh.finishRefresh();
        }else{
            mAdapter.addData(list);
            layoutRefresh.finishLoadMore();
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        }else{
            layoutRefresh.setEnableLoadMore(true);
        }

    }


    private void share(String share_url){
        new ShareAction(getMActivity())
                .setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE, SHARE_MEDIA.SINA)
                .setShareboardclickCallback(new ShareBoardlistener() {
                    @Override
                    public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                        UMImage image = new UMImage(getMActivity(), R.drawable.erweima);
                        UMWeb web = new UMWeb(share_url);
                        web.setTitle("58影视，各种大片抢先看");
                        web.setThumb(image);
                        web.setDescription("58影视，各种最新资源，各种热播大片，实时更新，带你一饱眼福");
                        new ShareAction(getMActivity())
                                .setPlatform(share_media)
                                .withMedia(web)
                                .setCallback(new UMShareListener() {
                                    @Override
                                    public void onStart(SHARE_MEDIA share_media) {
                                        Logger.d("33333333333333333333333333");
                                    }

                                    @Override
                                    public void onResult(SHARE_MEDIA share_media) {
                                        Logger.d("1111111111111111111 " + share_media.getName());

                                        if (share_media == SHARE_MEDIA.WEIXIN || share_media == SHARE_MEDIA.WEIXIN_CIRCLE) {
                                            save(6);
                                        }else if(share_media == SHARE_MEDIA.QQ || share_media == SHARE_MEDIA.QZONE){
                                            save(6);
                                        }else{
                                            save(6);
                                        }
                                    }

                                    @Override
                                    public void onError(SHARE_MEDIA share_media, Throwable throwable) {
                                        Logger.d("222222222222222 " + throwable.getMessage());
                                    }

                                    @Override
                                    public void onCancel(SHARE_MEDIA share_media) {

                                    }
                                })
                                .share();
                    }
                }).open();
    }


    private void save(int id){
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            ToastUtils.show("分享成功，+" +gold + " 金币");
                        }else{

                        }
                    }
                });
    }


    @Override
    protected int getLayout() {
        return R.layout.fragment_hot;
    }
}
