package com.movie58.my;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allen.library.SuperTextView;
import com.blankj.utilcode.util.CacheDiskUtils;
import com.blankj.utilcode.util.ConvertUtils;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.SPUtils;
import com.cbman.roundimageview.RoundImageView;
import com.hjq.toast.ToastUtils;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;
import com.lxj.xpopup.interfaces.OnSelectListener;
import com.lxj.xpopup.interfaces.XPopupCallback;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.activity.MainActivity;
import com.movie58.base.BaseFragment;
import com.movie58.bean.UpdateInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.LogUtil;
import com.movie58.util.PermissionUtil;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.FileBinary;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yanzhenjie.permission.runtime.Permission;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;

import butterknife.BindView;
import butterknife.OnClick;
import top.zibin.luban.CompressionPredicate;
import top.zibin.luban.Luban;
import top.zibin.luban.OnCompressListener;

/**
 * Created by yangxing on 2019/5/7 0007.
 */
public class SettingFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvRight;
    @BindView(R.id.layout_avatar)
    RelativeLayout layoutAvatar;
    @BindView(R.id.iv_avatar)
    RoundImageView ivAvatar;
    @BindView(R.id.layout_center)
    SuperTextView layoutCenter;
    @BindView(R.id.layout_nick)
    SuperTextView layoutNick;
    @BindView(R.id.layout_sex)
    SuperTextView layoutSex;
    @BindView(R.id.layout_version)
    SuperTextView layoutVersion;
    @BindView(R.id.layout_clear)
    SuperTextView layoutClear;
    @BindView(R.id.layout_clear1)
    SuperTextView layoutClear1;
    @BindView(R.id.layout_cache)
    SuperTextView layoutCache;
    @BindView(R.id.layout_push)
    SuperTextView layoutPush;
    @BindView(R.id.layout_code)
    SuperTextView layoutCode;

    UpdateInfo updateInfo;

    public static SettingFragment newInstance() {
        return new SettingFragment();
    }

    @Override
    protected void initView() {
        tvRight.setText("设置");
        layoutNick.setRightString(Account.getInstance().getUserName());
        PicassoUtils.LoadImageWithDetfult(getMActivity(), Account.getInstance().getAvatar(), ivAvatar, R.drawable.avatar);
        String sex = Account.getInstance().getSex();
        switch (sex) {
            case "0":
                layoutSex.setRightString("保密");
                break;
            case "1":
                layoutSex.setRightString("男");
                break;
            case "2":
                layoutSex.setRightString("女");
                break;
            default:
                break;
        }

        layoutVersion.setRightString("V" + ToolUtil.getVersion());

        long cache = setCacheSize();

        if (SPUtils.getInstance().getBoolean(SPContant.CACHE_100)) {
            layoutClear1.setSwitchIsChecked(true);

            if (cache >= 100 * 1024 * 1024) {
                CacheDiskUtils.getInstance().clear();
            }

        } else {
            layoutClear1.setSwitchIsChecked(false);
        }

        if (SPUtils.getInstance().getBoolean(SPContant.CACHE_34)) {
            layoutCache.setSwitchIsChecked(true);
        } else {
            layoutCache.setSwitchIsChecked(false);
        }

        layoutClear1.setSwitchCheckedChangeListener(new SuperTextView.OnSwitchCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SPUtils.getInstance().put(SPContant.CACHE_100, isChecked);
            }
        });

        layoutCache.setSwitchCheckedChangeListener(new SuperTextView.OnSwitchCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SPUtils.getInstance().put(SPContant.CACHE_34, isChecked);
            }
        });

    }

    @OnClick({R.id.iv_back, R.id.layout_avatar, R.id.layout_center, R.id.layout_nick, R.id.layout_sex, R.id.layout_version, R.id.layout_clear,
            R.id.layout_push, R.id.layout_code, R.id.btn_out})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                getMActivity().finish();
                break;
            case R.id.layout_avatar:
                new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                    @Override
                    public void onGranted() {
                        PictureSelector.create(SettingFragment.this)
                                .openGallery(PictureConfig.TYPE_IMAGE)
                                .maxSelectNum(1)
                                .selectionMode(PictureConfig.SINGLE)
                                .forResult(PictureConfig.CHOOSE_REQUEST);//结果回调onActivityResult code
                    }
                }).showPermission(Permission.Group.CAMERA, Permission.Group.STORAGE);
                break;
            case R.id.layout_center:
                start(SafeCenterFragment.newInstance());
                break;
            case R.id.layout_nick:
                start(NickFragment.newInstance());
                break;
            case R.id.layout_sex:
                start(SexFragment.newInstance());

//                new XPopup.Builder(getMActivity())
//                        .asCenterList("请选择性别", new String[]{"男", "女"},
//                                new OnSelectListener() {
//                                    @Override
//                                    public void onSelect(int position, String text) {
//                                        layoutSex.setRightString(text);
//                                    }
//                                })
//                        .show();

                break;
            case R.id.layout_version:
                Update();
                break;
            case R.id.layout_clear:
                CacheDiskUtils.getInstance().clear();
                setCacheSize();
                ToastUtils.show("已清空");
                break;
            case R.id.layout_push:

                break;
            case R.id.layout_code:
                start(CodeFragment.newInstance());
                break;
            case R.id.btn_out:
                out();
                break;
            default:
                break;
        }
    }

    private long setCacheSize() {
        long cache = CacheDiskUtils.getInstance().getCacheSize();
        LogUtils.e(cache);
        layoutClear.setRightString(ConvertUtils.byte2FitMemorySize(cache));
        return cache;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case PictureConfig.CHOOSE_REQUEST:
                    String path = PictureSelector.obtainMultipleResult(data).get(0).getPath();
                    lubam(path);
                    break;
                default:
                    break;
            }

        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_04_SCHOOL_TIME_FILE:
                layoutNick.setRightString(Account.getInstance().getUserName());
                break;
            case Event.CODE_07_SCHOOL_SORT:
                String sex = Account.getInstance().getSex();
                switch (sex) {
                    case "0":
                        layoutSex.setRightString("保密");
                        break;
                    case "1":
                        layoutSex.setRightString("男");
                        break;
                    case "2":
                        layoutSex.setRightString("女");
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    private void lubam(String path) {
        Luban.with(getMActivity())
                .load(path)
                .ignoreBy(100)
                .filter(new CompressionPredicate() {
                    @Override
                    public boolean apply(String path) {
                        return !(TextUtils.isEmpty(path) || path.toLowerCase().endsWith(".gif"));
                    }
                })
                .setCompressListener(new OnCompressListener() {
                    @Override
                    public void onStart() {
                        // TODO 压缩开始前调用，可以在方法内启动 loading UI
                    }

                    @Override
                    public void onSuccess(File file) {
                        uploadAvatar(file.getPath());
                    }

                    @Override
                    public void onError(Throwable e) {
                        uploadAvatar(path);
                    }
                }).launch();
    }

    private void uploadAvatar(String path) {
        FileBinary binary = new FileBinary(new File(path));
        Kalle.post(HttpUrl.UPLOAD_AVATAR)
                .tag(tag)
                .addHeader("Content-Type", "form-data")
                .binary("avatar", binary)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String url = FastJsonUtil.toString(response.succeed(), "file_path");
                            changeAvatar(url);
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void changeAvatar(String avatar) {
        Kalle.get(HttpUrl.CHANGE_USER)
                .tag(tag)
                .param("avatar", avatar)
                .param("user_id", Account.getInstance().getUserId())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            Account.getInstance().setAvatar(avatar);
                            PicassoUtils.LoadImageWithDetfult(getMActivity(), avatar, ivAvatar, R.drawable.avatar);
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void out() {
        Kalle.get(HttpUrl.LOGOUT)
                .tag(tag)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            getMActivity().finish();
                            ToastUtils.show("退出成功");
                            Account.getInstance().loginOut();
                            EventBus.getDefault().post(new Event(Event.CODE_49_LOGIN_OUT));
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void Update() {
        Kalle.get(HttpUrl.UPDATE)
                .tag(tag)
                .perform(new NormalCallback<UpdateInfo>() {
                    @Override
                    public void onFinaly(SimpleResponse<UpdateInfo, String> response) {
                        if (response.isSucceed()) {
                            updateInfo = response.succeed();
                            if (!updateInfo.getVersion().equals(ToolUtil.getVersion()) && "1".equals(updateInfo.getIs_open())) {
                                update();
                            } else {
                                ToastUtils.show("已经是最新版本");
                            }
                        } else {

                        }
                    }
                });
    }

    private void update() {
        new XPopup.Builder(getMActivity())
                .setPopupCallback(new XPopupCallback() {
                    @Override
                    public void onShow() {

                    }

                    @Override
                    public void onDismiss() {

                    }
                }).asConfirm(updateInfo.getTitle(), updateInfo.getContent(),
                new OnConfirmListener() {
                    @Override
                    public void onConfirm() {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(updateInfo.getRedirect_url()));
                            startActivity(intent);
                        } catch (Exception e) {


                        }
                    }
                }, null, false)
                .show();
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_settting;
    }

}
