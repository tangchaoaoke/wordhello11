package com.movie58.my;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.account.Account;
import com.movie58.base.BaseFragment;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/5/8 0008.
 */
public class ChangePhoneFragment extends BaseFragment {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_phone)
    TextView tvPhone;
    @BindView(R.id.et_code)
    EditText etCode;
    @BindView(R.id.btn_verify)
    SuperButton btnVerify;
    @BindView(R.id.et_phone)
    EditText etPhone;
    @BindView(R.id.btn_reset)
    SuperButton btnReset;

    private String strCode, strPhone;


    public static ChangePhoneFragment newInstance() {
        return new ChangePhoneFragment();
    }

    @Override
    protected void initView() {
        tvTitle.setText("更换手机号");
        tvPhone.setText(ToolUtil.getPhone(Account.getInstance().getUserTel()));
    }

    @OnClick({R.id.iv_back, R.id.btn_verify, R.id.btn_reset})
    void click(View v){
        hideSoftInput();
        switch (v.getId()){
            case R.id.iv_back:
                pop();
                break;
            case R.id.btn_verify:
                getCode(Account.getInstance().getUserTel());
                break;
            case R.id.btn_reset:
                strCode  = etCode.getText().toString().trim();
                if (TextUtils.isEmpty(strCode)) {
                    ToastUtils.show("请输入验证码");
                    return;
                }
                strPhone = etPhone.getText().toString().trim();
                if (!ToolUtil.isMobileNum(strPhone)) {
                    ToastUtils.show("请输入正确手机号");
                    return;
                }
                checkCode();
                break;
        }
    }

    private void getCode(String phone){
        Kalle.get(HttpUrl.VERIFY_CODE)
                .tag(tag)
                .param("user_mobile", phone)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToolUtil.countDown(btnVerify, 60000, 1000, "获取验证码");
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void checkCode(){
        Kalle.get(HttpUrl.CHECK_CODE)
                .tag(tag)
                .param("user_mobile", Account.getInstance().getUserTel())
                .param("verification_code", strCode)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            checkPhone();
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void checkPhone(){
        Kalle.get(HttpUrl.CHECK_PHONE)
                .tag(tag)
                .param("user_mobile", strPhone)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            start(ChangePhoneFragment2.newInstance(strPhone));
                        }else{
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }




    @Override
    protected int getLayout() {
        return R.layout.fragment_change_phone;
    }

}
