package com.movie58.bean;

import java.io.Serializable;

/**
 * Created by yangxing on 2019/6/27 0027.
 */
public class LimitInfo implements Serializable {
    /**
     * scale : 0.01
     * max_gold : 10000
     * max_exchange_num : 0
     * is_open : 1
     */

    private float scale;
    private int max_gold;  //每日最大兑换金币数
    private String max_exchange_num;  //每日最大兑换次数
    private int is_open;
    private int min_gold;


    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public int getMax_gold() {
        return max_gold;
    }

    public void setMax_gold(int max_gold) {
        this.max_gold = max_gold;
    }

    public String getMax_exchange_num() {
        return max_exchange_num;
    }

    public void setMax_exchange_num(String max_exchange_num) {
        this.max_exchange_num = max_exchange_num;
    }

    public int getMin_gold() {
        return min_gold;
    }

    public void setMin_gold(int min_gold) {
        this.min_gold = min_gold;
    }

    public int getIs_open() {
        return is_open;
    }

    public void setIs_open(int is_open) {
        this.is_open = is_open;
    }
}
