package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/26 0026.
 */
public class HelpInfo {
    /**
     * id : 3
     * title : 2.有视频下载不了怎么办?
     * content : 尝试多点击几次或重启手机,并查看手机空间是否足够,如果还是无法下载,请点击“我要反馈”把问题告诉我们,我们会尽快解决,谢谢!
     * create_time : 0
     * update_time : 0
     */

    private int id;
    private String title;
    private String content;
    private int create_time;
    private int update_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getCreate_time() {
        return create_time;
    }

    public void setCreate_time(int create_time) {
        this.create_time = create_time;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }
}
