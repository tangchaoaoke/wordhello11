package com.movie58.account;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.PhoneUtils;
import com.blankj.utilcode.util.SPUtils;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.interfaces.Lar;
import com.movie58.newdemand.utils.PhoneIdUitls;
import com.movie58.newdemand.utils.ToastUitl;
import com.movie58.base.BaseFragment;
import com.movie58.bean.LoginInfo;
import com.movie58.bean.UserInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by yangxing on 2019/4/25 0025.
 */
public class LoginFastFragment extends BaseFragment {


    @BindView(R.id.et_phone)
    EditText etPhone;
    @BindView(R.id.iv_phone)
    ImageView ivPhone;
    @BindView(R.id.tv_error)
    TextView tvError;
    @BindView(R.id.tv_error1)
    TextView tvError1;
    @BindView(R.id.et_pwd)
    EditText etPwd;
    @BindView(R.id.btn_verify)
    Button btnVerify;


    String strPhone;

    public static LoginFastFragment newInstance() {
        return new LoginFastFragment();
    }

    @Override
    protected void initView() {
        strPhone = SPUtils.getInstance().getString(SPContant.PHONE);
        if (!TextUtils.isEmpty(strPhone)) {
            etPhone.setText(strPhone);
            etPhone.setSelection(strPhone.length());
        }
        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s.toString().trim())) {
                    ivPhone.setVisibility(View.GONE);
                } else {
                    ivPhone.setVisibility(View.VISIBLE);
                }
            }
        });
        etPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s.toString().trim())) {

                } else {

                    tvError1.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    @OnClick({R.id.iv_phone, R.id.btn_verify, R.id.btn_login})
    void click(View v) {
        switch (v.getId()) {
            case R.id.iv_phone:
                etPhone.setText("");
                break;
            case R.id.btn_verify:
                strPhone = etPhone.getText().toString().trim();
                if (!ToolUtil.isMobileNum(strPhone)) {
                    tvError.setText("请输入正确的手机号");
                    tvError.setVisibility(View.VISIBLE);
                    return;
                }
                getCode(strPhone);
                break;
            case R.id.btn_login:
                strPhone = etPhone.getText().toString().trim();
                if (!ToolUtil.isMobileNum(strPhone)) {
                    tvError.setText("请输入正确的手机号");
                    tvError.setVisibility(View.VISIBLE);
                    return;
                }
                String verify = etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(verify)) {
                    tvError1.setText("请输入验证码");
                    tvError1.setVisibility(View.VISIBLE);
                    return;
                }
                login(verify);
                break;
        }
    }

    private void getCode(String phone) {
        Kalle.get(HttpUrl.VERIFY_CODE)
                .tag(tag)
                .param("user_mobile", phone)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToolUtil.countDown(btnVerify, 60000, 1000, "获取验证码");
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void login(String code) {
        Kalle.post(HttpUrl.LOGIN)
                .tag(tag)
                .param("user_name", strPhone)
                .param("device_type", "android")
                .param("is_verify", 1)
                .param("password", code)
                .perform(new LoadingCallback<LoginInfo>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<LoginInfo, String> response) {
                        if (response.isSucceed()) {
                            com.hjq.toast.ToastUtils.show("登录成功!");
                            UserInfo info = response.succeed().getUser();
                            Account.getInstance().setUserTel(strPhone)
                                    .setToken(response.succeed().getToken())
                                    .setUserId(info.getId())
                                    .setUserName(info.getUser_nickname())
                                    .setSex(info.getSex())
                                    .setInviteCode(info.getUser_login())
                                    .setAvatar(info.getAvatar())
                                    .setGold(info.getCoin());

                            Kalle.getConfig().getHeaders().set("XX-Token", Account.getInstance().getToken());

                            EventBus.getDefault().post(new Event(Event.CODE_48_LOGIN_IN));
                            getMActivity().finish();
                            relationId();
                        } else {
                            com.hjq.toast.ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_login_fast;
    }

    private Lar lar;

    private void relationId() {
        if (lar == null) {
            lar = new Lar();
        }
        String im = PhoneUtils.getIMEI();
        if (TextUtils.isEmpty(im)) {
            im = PhoneIdUitls.getID(getActivity());
        }else{
            ToastUitl.showShort(getActivity(), im);
        }
        lar.d(im, this);
    }

}
