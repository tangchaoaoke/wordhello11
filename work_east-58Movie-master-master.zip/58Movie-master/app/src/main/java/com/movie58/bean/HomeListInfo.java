package com.movie58.bean;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangxing on 2019/5/10 0010.
 */
public class HomeListInfo  implements MultiItemEntity {
    /**
     * id : 26
     * widget_name : rotation_chart
     * params : {"list":[{"img_url":"http://47.105.218.54/upload/decorate/20190508/6ce98fe4400f40fa136b43323d0111ac.jpeg","img_title":"变形金刚5-最后的骑士","vod_id":"113","is_advert":"0","vod_name":"变形金刚5：最后的骑士","description":"该片讲述了地球陷入毁灭危机，以凯德·伊格尔为首的人类反抗小组，与汽车人联手反击霸天虎在内的入侵者的故事。","pingfen":"8.9","lead_role":"马克·沃尔伯格,彼特·库伦,伊莎贝拉·莫奈,乔什·杜哈明,泰瑞斯·吉布森","down_right_text":"1","up_right_text":"火爆","img_link":"http://47.105.218.54/collect/collect/show/id/113.html"},{},{}]}
     * order_sort : 0
     * create_time : 1557207743
     * update_time : 1557207743
     * cat_id : 9
     */

    private int id;
    private String widget_name;
    private ParamsBean params = new ParamsBean();
    private int order_sort;
    private int cat_id;
    private int type;
    private MoreParams more_params = new MoreParams();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWidget_name() {
        return widget_name;
    }

    public void setWidget_name(String widget_name) {
        this.widget_name = widget_name;
    }

    public ParamsBean getParams() {
        return params;
    }

    public void setParams(ParamsBean params) {
        this.params = params;
    }

    public int getOrder_sort() {
        return order_sort;
    }

    public void setOrder_sort(int order_sort) {
        this.order_sort = order_sort;
    }

    public int getCat_id() {
        return cat_id;
    }

    public void setCat_id(int cat_id) {
        this.cat_id = cat_id;
    }

    public void setType(int type){
        this.type = type;
    }

    @Override
    public int getItemType() {
        return type;
    }

    public MoreParams getMore_params() {
        return more_params;
    }

    public void setMore_params(MoreParams more_params) {
        this.more_params = more_params;
    }

    public static class ParamsBean {
        private String title;
        private List<ListBean> list = new ArrayList<>();

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public static class ListBean {
            /**
             * img_url : http://47.105.218.54/upload/decorate/20190508/6ce98fe4400f40fa136b43323d0111ac.jpeg
             * img_title : 变形金刚5-最后的骑士
             * vod_id : 113
             * is_advert : 0
             * vod_name : 变形金刚5：最后的骑士
             * description : 该片讲述了地球陷入毁灭危机，以凯德·伊格尔为首的人类反抗小组，与汽车人联手反击霸天虎在内的入侵者的故事。
             * pingfen : 8.9
             * lead_role : 马克·沃尔伯格,彼特·库伦,伊莎贝拉·莫奈,乔什·杜哈明,泰瑞斯·吉布森
             * down_right_text : 1
             * up_right_text : 火爆
             * img_link : http://47.105.218.54/collect/collect/show/id/113.html
             */

            private String img_url;
            private String img_title;
            private String vod_id;
            private String is_advert;
            private String vod_name;
            private String description;
            private String pingfen;
            private String lead_role;
            private String down_right_text;
            private String up_right_text;
            private String img_link;

            public String getImg_url() {
                return img_url;
            }

            public void setImg_url(String img_url) {
                this.img_url = img_url;
            }

            public String getImg_title() {
                return img_title;
            }

            public void setImg_title(String img_title) {
                this.img_title = img_title;
            }

            public String getVod_id() {
                return vod_id;
            }

            public void setVod_id(String vod_id) {
                this.vod_id = vod_id;
            }

            public String getIs_advert() {
                return is_advert;
            }

            public void setIs_advert(String is_advert) {
                this.is_advert = is_advert;
            }

            public String getVod_name() {
                return vod_name;
            }

            public void setVod_name(String vod_name) {
                this.vod_name = vod_name;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public String getPingfen() {
                return pingfen;
            }

            public void setPingfen(String pingfen) {
                this.pingfen = pingfen;
            }

            public String getLead_role() {
                return lead_role;
            }

            public void setLead_role(String lead_role) {
                this.lead_role = lead_role;
            }

            public String getDown_right_text() {
                return down_right_text;
            }

            public void setDown_right_text(String down_right_text) {
                this.down_right_text = down_right_text;
            }

            public String getUp_right_text() {
                return up_right_text;
            }

            public void setUp_right_text(String up_right_text) {
                this.up_right_text = up_right_text;
            }

            public String getImg_link() {
                return img_link;
            }

            public void setImg_link(String img_link) {
                this.img_link = img_link;
            }
        }
    }

    public static class MoreParams{
        private String source_tag;
        private String source_type;
        private String cat_id;

        public String getCat_id() {
            return cat_id;
        }

        public void setCat_id(String cat_id) {
            this.cat_id = cat_id;
        }

        public String getSource_tag() {
            return source_tag;
        }

        public void setSource_tag(String source_tag) {
            this.source_tag = source_tag;
        }

        public String getSource_type() {
            return source_type;
        }

        public void setSource_type(String source_type) {
            this.source_type = source_type;
        }
    }
}
