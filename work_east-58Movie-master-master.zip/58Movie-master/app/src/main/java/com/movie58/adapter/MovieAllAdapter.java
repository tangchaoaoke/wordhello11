package com.movie58.adapter;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.blankj.utilcode.util.ScreenUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.movie58.R;
import com.movie58.bean.MovieListInfo;
import com.movie58.img.PicassoUtils;

import java.util.List;

/**
 * Created by yangxing on 2019/5/9 0009.
 */
public class MovieAllAdapter extends BaseQuickAdapter<MovieListInfo, BaseViewHolder> {


    public MovieAllAdapter(@Nullable List<MovieListInfo> data) {
        super(R.layout.include_list_xiao, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, MovieListInfo item) {

        int margin = mContext.getResources().getDimensionPixelOffset(R.dimen.dp_6);
        int widthPix = ScreenUtils.getScreenWidth();
        int width = (widthPix - (margin * 2)) / 3;
        int height = width / 2 * 3;
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
        int mo = helper.getLayoutPosition() % 3;
        if (mo == 0) {
            params.leftMargin = 0;
            params.rightMargin = margin / 2;
        } else if (mo == 1) {
            params.leftMargin = margin / 2;
            params.rightMargin = margin / 2;
        } else {
            params.leftMargin = margin / 2;
            params.rightMargin = 0;
        }
        ImageView ivImg = helper.getView(R.id.iv_small);
        ivImg.setLayoutParams(params);
        helper.itemView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        PicassoUtils.LoadImageWithDetfult(mContext, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
        if (TextUtils.isEmpty(item.getUp_right_text())) {
            helper.setGone(R.id.tv_tag, false);
        } else {
            helper.setVisible(R.id.tv_tag, true);
            helper.setText(R.id.tv_tag, item.getUp_right_text());
        }

        helper.setText(R.id.tv_small_title, item.getSource_name())
                .setText(R.id.tv_small_content, item.getDescription());
        if (TextUtils.isEmpty(item.getDown_right_text())) {
            helper.setGone(R.id.tv_small_bottom, false);
        } else {
            helper.setVisible(R.id.tv_small_bottom, true);
            helper.setText(R.id.tv_small_bottom, item.getDown_right_text())
                    .setTextColor(R.id.tv_small_bottom, mContext.getResources().getColor(R.color.color_ff5722));
        }

    }
}
