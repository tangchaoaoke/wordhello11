package com.movie58.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ScreenUtils;
import com.carlt.networklibs.NetType;
import com.carlt.networklibs.NetworkManager;
import com.carlt.networklibs.annotation.NetWork;
import com.cbman.roundimageview.RoundImageView;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.movie58.App;
import com.movie58.R;
import com.movie58.newdemand.database.Record;
import com.movie58.newdemand.interfaces.Other;
import com.movie58.newdemand.utils.JSONUtils;
import com.movie58.newdemand.utils.PhoneIdUitls;
import com.movie58.newdemand.view.LoadingTip;
import com.movie58.account.Account;
import com.movie58.account.LoginActivity;
import com.movie58.activity.WebViewActivity;
import com.movie58.base.BaseUseActivity;
import com.movie58.bean.DanmuInfo;
import com.movie58.bean.DetailAdInfo;
import com.movie58.bean.DetailInfo;
import com.movie58.bean.DetailLikeInfo;
import com.movie58.bean.DownloadInfo;
import com.movie58.bean.MovieReviewInfo;
import com.movie58.bean.ShareBean;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.img.PicassoUtils;
import com.movie58.my.FeedbackActivity;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.OnDoubleClickListener;
import com.movie58.util.PermissionUtil;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.movie58.view.VideoPlayer;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.orhanobut.logger.Logger;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yanzhenjie.permission.runtime.Permission;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;
import com.yqritc.recyclerviewflexibledivider.VerticalDividerItemDecoration;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.xutils.DbManager;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.ex.DbException;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.OnClick;
import cn.jzvd.Jzvd;

/**
 * Created by yangxing on 2019/5/11 0011.
 */
public class MovieDetailActivity extends BaseUseActivity implements LoadingTip.onReloadListener {

    @BindView(R.id.root)
    RelativeLayout layoutRoot;
    @BindView(R.id.detail_player)
    VideoPlayer detailPlayer;
    @BindView(R.id.layout_player)
    RelativeLayout layoutPlayer;
    @BindView(R.id.tv_name)
    TextView tvName;
    @BindView(R.id.iv_type)
    ImageView ivType;
    @BindView(R.id.tv_jieshao)
    TextView tvJieshao;
    @BindView(R.id.tv_fen)
    TextView tvFen;
    @BindView(R.id.tv_count)
    TextView tvCount;
    @BindView(R.id.tv_type)
    TextView tvType;
    @BindView(R.id.tv_review)
    TextView tvReview;
    @BindView(R.id.tv_feedback)
    TextView ivFeedback;
    @BindView(R.id.rv_pl)
    RecyclerView rvPl;
    @BindView(R.id.iv_cache)
    ImageView ivCache;
    @BindView(R.id.iv_collect)
    ImageView ivCollect;
    @BindView(R.id.iv_share)
    ImageView ivShare;
    @BindView(R.id.layout_bottom1)
    FrameLayout layoutBottom1;
    @BindView(R.id.layout_bottom2)
    RelativeLayout layoutBottom2;
    @BindView(R.id.layout_bottom3)
    RelativeLayout layoutBottom3;
    @BindView(R.id.layout_xuanji)
    LinearLayout layoutXuanji;
    @BindView(R.id.tv_xuanji)
    TextView tvXuanji;
    @BindView(R.id.rv_xuanji)
    RecyclerView rvXuanji;
    @BindView(R.id.rv_type)
    RecyclerView rvType;
    @BindView(R.id.layout_like)
    LinearLayout layoutLike;
    @BindView(R.id.iv_like)
    ImageView ivLike;
    @BindView(R.id.rv_like)
    RecyclerView rvLike;
    @BindView(R.id.et_common)
    EditText etCommon;
    @BindView(R.id.btn_send)
    Button btnSend;
    @BindView(R.id.sv)
    NestedScrollView sv;
    @BindView(R.id.layout_refresh)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.tv_null)
    TextView tvNull;
    @BindView(R.id.iv_ad2)
    ImageView ivAd2;
    @BindView(R.id.iv_ad1)
    ImageView ivAd1;
    @BindView(R.id.loadedTip)
    LoadingTip loadedTip;
    @BindView(R.id.relay_video_bg)
    RelativeLayout relay_video_bg;


    private String strId;
    int page = 1;
    String strType;
    List<DanmuInfo> listDanmu = new ArrayList<>();
    int danmuPage = 1;
    private List<DetailLikeInfo> listLike = new ArrayList<>();
    private DetailInfo detailInfo;
    private String adInfo;
    ReviewAdapter reviewAdapter;
    String adUrl;
    String adImg;
    String adTitle;
    String adUrl1;
    String adImg1;
    String adTitle1;
    private long startTime;
    BasePopupView dialogReview;
    private int playAnthology;
    private int playedTime;
    private DbManager db;
    private String jsonDetails;

    private Other other;

    public String getJsonDetails() {
        return jsonDetails;
    }

    public int getPlayAnthology() {
        return playAnthology;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setFitsSystem(false);
        super.onCreate(savedInstanceState);
        setStatus("#000000");
        other = new Other();
        startTime = System.currentTimeMillis();
        //你也可以在这里初始化，对当前页面网络实时监听
        NetworkManager.getInstance().init(getApplication());
        //注册
        NetworkManager.getInstance().registerObserver(this);
        ainit();
        loadedTip.setOnReloadListener(this);
        layoutRefresh.setEnableRefresh(false);
        setupUI(layoutRoot);

        etCommon.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (TextUtils.isEmpty(s)) {
                    btnSend.setEnabled(false);
                } else {
                    btnSend.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        layoutRefresh.setOnLoadMoreListener(refreshLayout -> {
            page++;
            getReview();
        });

        reviewAdapter = new ReviewAdapter(new ArrayList<>());
        rvPl.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvPl.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity())
                .color(getMActivity().getResources().getColor(R.color.line))
                .marginProvider(new HorizontalDividerItemDecoration.MarginProvider() {
                    @Override
                    public int dividerLeftMargin(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelOffset(R.dimen.dp_15);
                    }

                    @Override
                    public int dividerRightMargin(int position, RecyclerView parent) {
                        return 0;
                    }
                }).build());
        reviewAdapter.bindToRecyclerView(rvPl);
        reviewAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                if (view.getId() == R.id.tv_zan) {
                    int zan = reviewAdapter.getItem(position).getIs_top();
                    int id = reviewAdapter.getItem(position).getId();
                    if (zan == 1) {
                        zanCancel(id);
                    } else {
                        toZan(id);
                    }
                }
            }
        });
    }

    @Override
    protected void getIntentExtra() {
        Bundle b = getIntent().getExtras();
        strId = b.getString("id");
        if (getIntent().hasExtra("play_anthology")) {
            playAnthology = b.getInt("play_anthology", -1);
        }
        if (getIntent().hasExtra("played_time")) {
            playedTime = b.getInt("played_time", -1);
        }
    }

    @Override
    protected void initView() {
        requestData();
//        SPUtils.getInstance().put(SPContant.PLAY_HISTORY, true);

//        /**
//         * 软键盘上推布局
//         */
//        layoutBottom1.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
//            Rect rect = new Rect();
//            layoutBottom1.getWindowVisibleDisplayFrame(rect);
//            int availableHeight = rect.bottom - layoutBottom1.getTop();
//            View focusedChild = layoutBottom1.getFocusedChild();
//            float contentHeight = 0;
//            if (focusedChild != null) {
//                contentHeight = focusedChild.getY() + focusedChild.getHeight();
//            }
//            int deltaY = (int) (availableHeight - contentHeight);
//
//            if (deltaY < 0) {
//                layoutBottom1.setTranslationY(deltaY);
//            } else {
//                layoutBottom1.setTranslationY(0);
//            }
//        });

    }

    public void requestData() {
        page = 1;
        loadedTip.setLoadingTip(LoadingTip.LoadStatus.loading);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                /**
                 *要执行的操作
                 */
                getAd1();
                getAd();
                getDetail();
                getDanmu();
            }
        }, 1000);//3秒后执行Runnable中的run方法


    }

    /**
     * 点击edittext之外的部分使软键盘隐藏
     */
    public void setupUI(View view) {
        if (view.getId() != R.id.btn_send && view.getId() != R.id.et_common) {
            if (view.getId() == R.id.danmaku_view || view.getId() == R.id.surface_container) {

            } else {
                view.setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View v, MotionEvent event) {
                        ToolUtil.hideSoftInput(etCommon);
                        layoutBottom2.setVisibility(View.VISIBLE);
                        layoutBottom3.setVisibility(View.GONE);
                        etCommon.clearFocus();
                        return false;
                    }
                });
            }
        }

        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView);
            }
        }
    }


    @OnClick({R.id.tv_jieshao, R.id.tv_feedback, R.id.tv_xuanji, R.id.iv_like, R.id.tv_common, R.id.iv_cache,
            R.id.iv_share, R.id.iv_collect, R.id.btn_send, R.id.iv_ad1, R.id.relay_back, R.id.relay_video_bg})
    void click(View v) {
        switch (v.getId()) {
            case R.id.relay_back:
                finish();
                break;
            case R.id.relay_video_bg:
                break;
            case R.id.tv_jieshao:
                new XPopup.Builder(getMActivity())
                        .moveUpToKeyboard(false)
                        .asCustom(new MovieIntroDialog(getMActivity(), detailInfo, strType))
                        .show();
                break;
            case R.id.tv_feedback:
                startActivity(FeedbackActivity.class);
                break;
            case R.id.tv_xuanji:
                new XPopup.Builder(getMActivity())
                        .moveUpToKeyboard(false)
                        .asCustom(new MovieMoreDialog(getMActivity(), detailInfo))
                        .show();
                break;
            case R.id.iv_like:
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("list", listLike);
                startActivity(MovieLikeListActivity.class, map);
                break;
            case R.id.tv_common:
                layoutBottom2.setVisibility(View.GONE);
                layoutBottom3.setVisibility(View.VISIBLE);
                etCommon.requestFocus();
                ToolUtil.showSoftInput(etCommon);
                break;
            case R.id.iv_cache:
                if (detailInfo == null || detailInfo.getDownload_content().isEmpty()) {
                    return;
                }
                List<DownloadInfo> list = new ArrayList<>();
                for (DetailInfo.DownloadContentBean bean : detailInfo.getDownload_content()) {
                    if (!TextUtils.isEmpty(bean.getDown_url())) {
                        DownloadInfo info = new DownloadInfo();
                        info.setImg(detailInfo.getSource_img());
                        info.setTitle(bean.getDown_title());
                        info.setUrl(bean.getDown_url());
                        list.add(info);
                    }
                }
                new XPopup.Builder(getMActivity())
                        .moveUpToKeyboard(false)
                        .asCustom(new CacheDialog(getMActivity(), list, detailInfo.getCat_name()))
                        .show();
                break;
            case R.id.iv_share:
                new PermissionUtil(getMActivity()).setCallBack(new PermissionUtil.CallBack() {
                    @Override
                    public void onGranted() {
                        getShareInfo();
                    }
                }).showPermission(Permission.Group.STORAGE);
                break;
            case R.id.iv_collect:
                if (detailInfo != null) {
                    if (detailInfo.getIs_collect() == 1) {
                        collectCancel();
                    } else {
                        toCollect();
                    }
                }
                break;
            case R.id.btn_send:
                String review = etCommon.getText().toString().trim();
                toReview(review);
                break;
            case R.id.iv_ad1:
                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map1 = new ArrayMap<>();
                    map1.put("url", adUrl);
                    map1.put("title", adTitle);
                    startActivity(WebViewActivity.class, map1);
                    addExp("play_advert");
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
        }
    }

    private void getShareInfo() {
        Kalle.get(HttpUrl.SHARE_INFO)
                .tag(tag)
                .perform(new NormalCallback<ShareBean>() {

                    @Override
                    public void onFinaly(SimpleResponse<ShareBean, String> response) {
                        if (response.isSucceed()) {
                            ShareBean shareBean = response.succeed();
                            if (shareBean == null || TextUtils.isEmpty(shareBean.getShare_url())) {
                                ToastUtils.show("获取分享地址失败");
                                return;
                            }
                            share(shareBean.getShare_url());
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_08_SCHOOL_SEARCH:
                int position = (int) event.getObj1();
                detailInfo.getSource_content().get(position).setCheck(true);
                rvXuanji.smoothScrollToPosition(position);
                xuanjiPlayer1(detailInfo.getSource_content().get(position).getPlay_url());
                break;
            case Event.CODE_11_SCHOOL_RESULT_CLICK:
                String danmu = (String) event.getObj1();
                sendDanmu(danmu);
                break;
            case Event.CODE_12_SCHOOL_CARD_CLICK:
                danmuPage++;
                getDanmu();
                break;
            case Event.CODE_13_SCHOOL_REVIEW_STATE:
                if (listDanmu == null || listDanmu.isEmpty()) {
                    return;
                }
                detailPlayer.setDanmaKu(listDanmu);
                break;
            case Event.CODE_15_MESSAGE_UNREAD:
                onBackPressedSupport();

                break;
            case Event.CODE_17_IM_UNREAD:
                try {
                    if (detailPlayer.screen == detailPlayer.SCREEN_FULLSCREEN) {
                        detailPlayer.backPress();
                        super.onBackPressedSupport();
                    }
                } catch (IllegalStateException e) {

                }


                break;
            case Event.CODE_19_MODE:
                DetailAdInfo info = (DetailAdInfo) event.getObj1();
                if (info == null || info.getVod_advert() == null || TextUtils.isEmpty(info.getVod_advert().getAdvert_url())) {
                    return;
                }
                if (Account.getInstance().isLogined()) {
                    ArrayMap<String, Object> map1 = new ArrayMap<>();
                    map1.put("url", info.getVod_advert().getAdvert_url());
                    map1.put("title", info.getVod_advert().getAdvert_name());
                    startActivity(WebViewActivity.class, map1);
                    addExp("play_advert");
                } else {
                    ToastUtils.show("请先登录");
                    startActivity(LoginActivity.class);
                }
                break;
        }
    }

    //视频详情接口
    private void getDetail() {
        Kalle.get(HttpUrl.DETAIL)
                .tag(tag)
                .param("id", strId)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        getReview();
                        //广告
                        jsonDetails = FastJsonUtil.toString(response.succeed(), "vod_info");
                        adInfo = FastJsonUtil.toString(response.succeed(), "advert_info");
                        //猜你喜欢
                        listLike = FastJsonUtil.toList(response.succeed(), "like_list", DetailLikeInfo.class);
                        //详情
                        detailInfo = FastJsonUtil.toBean(response.succeed(), "vod_info", DetailInfo.class);
                        init();
                        initLunx();
                    }

                    @Override
                    public void onFinnalyException() {
                        loadedTip.setLoadingTip(LoadingTip.LoadStatus.error);
                    }
                });
    }

    ArrayList<Map<String, String>> barrage_advert;
    ArrayList<String> barrage_advert2;

    //轮询执行弹幕广告
    public void initLunx() {

        Map<String, String> map = JSONUtils.parseKeyAndValueToMap(adInfo);
        barrage_advert = JSONUtils.parseKeyAndValueToMapList(map.get("barrage_advert"));
        if (barrage_advert == null || barrage_advert.size() == 0) {
            return;
        }
        barrage_advert2 = new ArrayList<>();
        for (int i = 0; i < barrage_advert.size(); i++) {
            barrage_advert2.add(barrage_advert.get(i).get("minute"));
        }

        if (!Account.getInstance().isLogined()) {
            return;
        }
        startLunx();
    }


    public void startLunx() {
        if (barrage_advert == null || barrage_advert.size() == 0) {
            return;
        }
        cancelTimer();
        timer = new Timer();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                long pos = detailPlayer.getCurrentPositionWhenPlaying() / 1000;
                long duration = detailPlayer.getDuration() / 1000;
                for (int i = 0; i < barrage_advert2.size(); i++) {
                    if (barrage_advert2.get(i).equals(pos + "")) {
                        detailPlayer.addDanmaku(barrage_advert.get(i).get("advert"));
                        break;
                    }
                }
                //20分钟领取金币
                if (pos >= 20 * 60 && switchThirty == 0) {
                    switchThirty++;
                    other.c("10", MovieDetailActivity.this);
                }

                //片尾五分钟领取金币
                if (duration - pos <= 5 * 60 && switchFive == 0 && duration - pos > 0) {
                    switchFive++;
                    other.c("10", MovieDetailActivity.this);
                }
            }
        };
        timer.schedule(timerTask, 0, 1000);
    }

    public int switchThirty = 0;
    public int switchFive = 0;

    @Override
    public void onComplete(RequestParams var1, String var2, String type) {
        super.onComplete(var1, var2, type);
        if (type.equals("getGoldReward")) {
            Map<String, String> map = JSONUtils.parseDataToMap(var2);
            if (map == null || TextUtils.isEmpty(map.get("gold_num"))) {
                return;
            }
            ToastUtils.show("观看任务已完成，+" + map.get("gold_num") + " 金币");
        }
    }

private XuanjiAdapter adapter;
    private void init() {
        int position = playAnthology >= 0 ? playAnthology : 0;
        if (playAnthology < 0) {
            playAnthology = 0;
        }
        //初始化视频
        xuanjiPlayer(detailInfo.getSource_content().get(position).getPlay_url());
        switch (detailInfo.getUp_right_text()) {
            case "火爆":
                ivType.setVisibility(View.VISIBLE);
                ivType.setImageResource(R.drawable.hot_huobao);
                break;
            case "热播":
                ivType.setVisibility(View.VISIBLE);
                ivType.setImageResource(R.drawable.hot_rebo);
                break;
            case "1080P":
                ivType.setVisibility(View.VISIBLE);
                ivType.setImageResource(R.drawable.hot_1080);
                break;
            default:
                ivType.setVisibility(View.GONE);
                break;
        }

        tvName.setText(detailInfo.getSource_name());
        tvFen.setText(detailInfo.getPingfen() + "分");
        tvCount.setText(detailInfo.getPlay_num() + "次播放");

        if (detailInfo.getTypes() != null && !detailInfo.getTypes().isEmpty()) {
            strType = "";
            for (DetailInfo.TypeBean bean : detailInfo.getTypes()) {
                strType = strType + "/" + bean.getType_name();
            }
            if (!TextUtils.isEmpty(strType)) {
                tvType.setText(strType.substring(1));
            }
        }
        tvReview.setText(detailInfo.getComment_count() + "条评论");
        if ("电影".equals(detailInfo.getCat_name())) {
            layoutXuanji.setVisibility(View.GONE);
        } else {
            if (detailInfo.getSource_content() != null && !detailInfo.getSource_content().isEmpty()) {
                layoutXuanji.setVisibility(View.VISIBLE);
                detailInfo.getSource_content().get(position).setCheck(true);
                 adapter = new XuanjiAdapter(detailInfo.getSource_content());
                WrapContentLinearLayoutManager layoutManager = new WrapContentLinearLayoutManager(getMActivity());
                layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                rvXuanji.setLayoutManager(layoutManager);
                rvXuanji.addItemDecoration(new VerticalDividerItemDecoration.Builder(getMActivity())
                        .colorResId(R.color.white)
                        .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                            @Override
                            public int dividerSize(int position, RecyclerView parent) {
                                return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                            }
                        }).build());
                adapter.bindToRecyclerView(rvXuanji);
                if (detailInfo.getSource_content().size() > position + 1) {
                    ToolUtil.MoveToPosition(layoutManager, rvXuanji, position);
                }
                adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                        for (DetailInfo.SourceContentBean bean : detailInfo.getSource_content()) {
                            bean.setCheck(false);
                        }
                        playAnthology = position;
                        detailInfo.getSource_content().get(position).setCheck(true);
                        adapter.notifyDataSetChanged();
                        xuanjiPlayer1(detailInfo.getSource_content().get(position).getPlay_url());
                    }
                });

                if (detailInfo.getUpdate_schedule() == 1) {
                    if ("综艺".equals(detailInfo.getCat_name())) {
                        tvXuanji.setText("已完结" + detailInfo.getSource_content().size() + "期");
                    } else {
                        tvXuanji.setText("已完结" + detailInfo.getSource_content().size() + "集");
                    }

                } else {
                    if ("综艺".equals(detailInfo.getCat_name())) {
                        tvXuanji.setText("更新至" + detailInfo.getSource_content().get(detailInfo.getSource_content().size() - 1).getPlay_title());
                    } else {
                        tvXuanji.setText("更新至" + detailInfo.getSource_content().get(detailInfo.getSource_content().size() - 1).getPlay_title());
                    }
                }

            }
        }
        if (detailInfo.getIs_collect() == 1) {
            ivCollect.setImageResource(R.drawable.detail_collect1);
        } else {
            ivCollect.setImageResource(R.drawable.detail_collect);
        }
        TypeAdapter adapter1 = new TypeAdapter(detailInfo.getTypes());
        WrapContentLinearLayoutManager layoutManager1 = new WrapContentLinearLayoutManager(getMActivity());
        layoutManager1.setOrientation(LinearLayoutManager.HORIZONTAL);
        rvType.setLayoutManager(layoutManager1);
        rvType.addItemDecoration(new VerticalDividerItemDecoration.Builder(getMActivity())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        adapter1.bindToRecyclerView(rvType);
        adapter1.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                ArrayMap<String, Object> map = new ArrayMap<>();
                map.put("name", adapter1.getItem(position).getType_name());
                map.put("type", adapter1.getItem(position).getType_id());
                map.put("id", detailInfo.getCat_id());
                startActivity(MovieTypeListActivity.class, map);
            }
        });

        if (listLike == null || listLike.isEmpty()) {
            layoutLike.setVisibility(View.GONE);
        } else {
            layoutLike.setVisibility(View.VISIBLE);
            LikeAdapter adapter2 = new LikeAdapter(listLike);
            WrapContentLinearLayoutManager layoutManager2 = new WrapContentLinearLayoutManager(getMActivity());
            layoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
            rvLike.setLayoutManager(layoutManager2);
            rvLike.addItemDecoration(new VerticalDividerItemDecoration.Builder(getMActivity())
                    .colorResId(android.R.color.transparent)
                    .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                        @Override
                        public int dividerSize(int position, RecyclerView parent) {
                            return getMActivity().getResources().getDimensionPixelSize(R.dimen.dp_6);
                        }
                    }).build());
            adapter2.bindToRecyclerView(rvLike);
            adapter2.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                    MovieDetailActivity.this.finish();
//                    ArrayMap<String, Object> map = new ArrayMap<>();
//                    map.put("id", adapter2.getItem(position).getId());
//                    startActivity(MovieDetailActivity.class, map);

//                    requestData();
                    Intent intent = new Intent(MovieDetailActivity.this, MovieDetailActivity.class);
                    intent.putExtra("id", adapter2.getItem(position).getId());
                    startActivity(intent);
                    MovieDetailActivity.this.finish();
                    finish();
                }
            });
        }
    }


    private void xuanjiPlayer(String url) {
        if (detailInfo.getSource_content() == null || detailInfo.getSource_content().isEmpty()) {
            return;
        }
        if (playedTime > 0) {
            detailPlayer.seekToInAdvance = playedTime * 1000;
        }
        detailPlayer.setUp(url, "");
        detailPlayer.setPlayUrl(url);
        detailPlayer.setAd(adInfo);
    }

    private void xuanjiPlayer1(String url) {
        if (detailInfo.getSource_content() == null || detailInfo.getSource_content().isEmpty()) {
            return;
        }
        detailPlayer.setUp(url, "");
        detailPlayer.setPlayUrl(url);
        detailPlayer.start();
    }


    public void onStateAutoComplete() {
        if (detailInfo.getSource_content() == null || detailInfo.getSource_content().size() < 2) {
            return;
        }
        if (playAnthology == detailInfo.getSource_content().size() - 1) {
            return;
        }
        playAnthology++;

        xuanjiPlayer1(detailInfo.getSource_content().get(playAnthology).getPlay_url());

        if (adapter!=null){
            for (DetailInfo.SourceContentBean bean : detailInfo.getSource_content()) {
                bean.setCheck(false);
            }
            detailInfo.getSource_content().get(playAnthology).setCheck(true);
            adapter.notifyDataSetChanged();
        }

    }

    //评论
    private void toReview(String str) {
        Kalle.post(HttpUrl.PUBLISH_COMMENT)
                .tag(tag)
                .param("vod_id", strId)
                .param("comments", str)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ToolUtil.hideSoftInput(etCommon);
                            layoutBottom2.setVisibility(View.VISIBLE);
                            layoutBottom3.setVisibility(View.GONE);
                            etCommon.clearFocus();
                            etCommon.setText("");
                            tvReview.setText((detailInfo.getComment_count() + 1) + "条评论");
                            ToastUtils.show("评论成功");
                            page = 1;
                            getReview();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    //获取评论
    private void getReview() {
        Kalle.post(HttpUrl.MOVIE_COMMENTS)
                .tag(tag)
                .param("vod_id", strId)
                .param("page", page)
                .param("size", 10)
                .perform(new NormalCallback<List<MovieReviewInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<MovieReviewInfo>, String> response) {
                        loadedTip.setLoadingTip(LoadingTip.LoadStatus.finish);
                        relay_video_bg.setVisibility(View.GONE);
                        initReview(response.succeed());
                    }

                    @Override
                    public void onFinnalyException() {
                        if (page > 1) {
                            layoutRefresh.finishLoadMore();
                            page--;
                        } else {
                            loadedTip.setLoadingTip(LoadingTip.LoadStatus.error);
                        }

                    }
                });
    }

    //获取评论
    private void initReview(List<MovieReviewInfo> list) {
        if (list == null) {
            list = new ArrayList<>();
        }
        if (page == 1) {
            if (list.isEmpty()) {
                reviewAdapter.setNewData(null);
                tvNull.setVisibility(View.VISIBLE);
            } else {
                reviewAdapter.setNewData(list);
                tvNull.setVisibility(View.GONE);
            }
        } else {
            reviewAdapter.addData(list);
        }
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        } else {
            layoutRefresh.setEnableLoadMore(true);
        }
        layoutRefresh.finishLoadMore();
    }

    //点赞
    private void toZan(int id) {
        Kalle.post(HttpUrl.MOVIE_ZAN)
                .tag(tag)
                .param("vod_id", strId)
                .param("comment_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            for (MovieReviewInfo info : reviewAdapter.getData()) {
                                if (info.getId() == id) {
                                    info.setIs_top(1);
                                    info.setTop_num(info.getTop_num() + 1);
                                    break;
                                }
                            }
                            reviewAdapter.notifyDataSetChanged();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    //取消点赞
    private void zanCancel(int id) {
        Kalle.post(HttpUrl.MOVIE_ZAN_CANCEL)
                .tag(tag)
                .param("comment_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            for (MovieReviewInfo info : reviewAdapter.getData()) {
                                if (info.getId() == id) {
                                    info.setIs_top(0);
                                    info.setTop_num(info.getTop_num() - 1);
                                    break;
                                }
                            }
                            reviewAdapter.notifyDataSetChanged();
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    //收藏
    private void toCollect() {
        Kalle.post(HttpUrl.MOVIE_COLLECT)
                .tag(tag)
                .param("vod_id", strId)
                .param("cat_id", detailInfo.getCat_id())
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ivCollect.setImageResource(R.drawable.detail_collect1);
                            detailInfo.setIs_collect(1);
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }


    //取消收藏
    private void collectCancel() {
        Kalle.post(HttpUrl.MOVIE_COLLECT_CANCEL)
                .tag(tag)
                .param("vod_id", strId)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            ivCollect.setImageResource(R.drawable.detail_collect);
                            detailInfo.setIs_collect(0);
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    //弹幕
    private void getDanmu() {
        Kalle.post(HttpUrl.DANMU_LIST)
                .tag(tag)
                .param("vod_id", strId)
                .param("page", danmuPage)
                .param("size", 10000)
                .perform(new NormalCallback<List<DanmuInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<DanmuInfo>, String> response) {
                        if (response.isSucceed()) {
                            if (page == 1 && (response.succeed() == null || response.succeed().isEmpty())) {
                                return;
                            }
                            listDanmu.addAll(0, response.succeed());
                            detailPlayer.setDanmaKu(listDanmu);

                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    //发送弹幕
    private void sendDanmu(String content) {
        Kalle.post(HttpUrl.DANMU_SEND)
                .tag(tag)
                .param("vod_id", strId)
                .param("content", content)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {

                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    // 没想到太好的逻辑计算观看30分钟 +金币
    private void playProgress() {
        if (ToolUtil.getCurrentDate().equals(SPUtils.getInstance().getString(SPContant.PLAY_30))) {
            return;
        }
        long playTime = (System.currentTimeMillis() - startTime) / 1000;
        long pos = detailPlayer.getCurrentPositionWhenPlaying() / 1000;
        if (pos == 0 && detailPlayer.isComplete) {
            pos = detailPlayer.getDuration() / 1000;
        }
        long time = 0;
        if (detailInfo == null) {
            return;
        }
        if ("电影".equals(detailInfo.getCat_name())) {
            if ((pos - playTime) > 60 * 10) { //播放进度时间大于 进入详情页计时时间超过10分钟 视为用户快进过 只计进入时间
                time = playTime;
            } else {
                time = pos;
            }
        } else {// 电视机、动漫等 有选集 只计进入时间
            time = playTime;
        }

        long time1 = SPUtils.getInstance().getLong(SPContant.PLAY_PROGRESS);
        if (time + time1 >= 60 * 30) {
            save(5);
        } else {
            SPUtils.getInstance().put(SPContant.PLAY_PROGRESS, (time + time1));
        }
    }

    //保存观看记录
    private void playRecord() {
        long pos = detailPlayer.getCurrentPositionWhenPlaying() / 1000;
        if (pos <= 0) {
            return;
        }
        long total = detailPlayer.getDuration() / 1000;
        String anthology = "-1";
        if ("电影".equals(detailInfo.getCat_name())) {
            anthology = "-1";
        } else {
            for (int i = 0; i < detailInfo.getSource_content().size(); i++) {
                if (detailInfo.getSource_content().get(i).isCheck()) {
                    anthology = i + "";
                    break;
                }
            }
        }
        if (!Account.getInstance().isLogined()) {
            saveVieoRecord(strId, detailInfo.getSource_name(), detailInfo.getSource_img(), pos + "", total + "");
        }
        Kalle.post(HttpUrl.PLAY_RECORD)
                .param("vod_id", strId)
                .param("played_time", pos)
                .param("play_anthology", anthology)
                .param("total_time", total)
                .param("imei", PhoneIdUitls.getID(this))
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
//                        EventBus.getDefault().post(new Event(Event.CODE_61_REFRESH_PLAY_HISTORY));
                    }
                });
    }

    @Override
    public void onBackPressedSupport() {
        try {
            if (detailPlayer.screen == detailPlayer.SCREEN_FULLSCREEN) {
                detailPlayer.backPress();
                return;
            }
        } catch (IllegalStateException e) {
        }

        if (dialogReview != null && dialogReview.isShow()) {
            dialogReview.dismiss();
            return;
        }
        super.onBackPressedSupport();
    }

    int i = 0;

    @NetWork(netType = NetType.AUTO)
    public void network(NetType netType) {
        if (i == 0) {
            i = 1;
            return;
        }
        if (detailPlayer.isAd()) {
            return;
        }
        switch (netType) {
            case WIFI:
                detailPlayer.closeMobile();
                break;
            case CMNET:
            case CMWAP:
                detailPlayer.showMobile();
                break;
            case AUTO:
                break;
            case NONE:
                break;
            default:
                break;
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        detailPlayer.goOnPlayOnResume();
        if (!Account.getInstance().isLogined()) {
            return;
        }
        startLunx();
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            detailPlayer.goOnPlayOnPause();
        } catch (NullPointerException e) {
        }
        cancelTimer();
    }

    private Timer timer;
    private TimerTask timerTask;

    public void cancelTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        if (timerTask != null) {
            timerTask.cancel();
            timerTask = null;
        }
    }


    @Override
    protected void onDestroy() {
        addExp();
//        playProgress();
        playRecord();
        detailPlayer.releaseDanmaku();
        Jzvd.releaseAllVideos();
//        detailPlayer.clearFloatScreen();
        super.onDestroy();
        //注销
        NetworkManager.getInstance().unRegisterObserver(this);
        //注销所有
        //NetworkManager.getInstance().unRegisterAllObserver();
    }


    private void share(String share_url) {
        new ShareAction(getMActivity())
                .setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE, SHARE_MEDIA.SINA)
                .setShareboardclickCallback(new ShareBoardlistener() {
                    @Override
                    public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                        UMImage image = new UMImage(getMActivity(), R.drawable.erweima);
                        UMWeb web = new UMWeb(share_url);
                        web.setTitle("58影视，各种大片抢先看");
                        web.setThumb(image);
                        web.setDescription("58影视，各种最新资源，各种热播大片，实时更新，带你一饱眼福");
                        new ShareAction(getMActivity())
                                .setPlatform(share_media)
                                .withMedia(web)
                                .setCallback(new UMShareListener() {
                                    @Override
                                    public void onStart(SHARE_MEDIA share_media) {
                                        Logger.d("33333333333333333333333333");
                                    }

                                    @Override
                                    public void onResult(SHARE_MEDIA share_media) {
                                        if (share_media == SHARE_MEDIA.WEIXIN || share_media == SHARE_MEDIA.WEIXIN_CIRCLE) {
                                            save(7);
                                        } else if (share_media == SHARE_MEDIA.QQ || share_media == SHARE_MEDIA.QZONE) {
                                            save(8);
                                        } else {
                                            save(9);
                                        }
                                        addExp("share_vod");
                                    }

                                    @Override
                                    public void onError(SHARE_MEDIA share_media, Throwable throwable) {
                                        Logger.d("222222222222222 " + throwable.getMessage());
                                    }

                                    @Override
                                    public void onCancel(SHARE_MEDIA share_media) {

                                    }
                                })
                                .share();
                    }
                }).open();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }


    //观看30分钟 奖励金币接口
    private void save(int id) {
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", id)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            if (id == 5) {
                                ToastUtils.show("观看任务已完成，+" + gold + " 金币");
                                SPUtils.getInstance().put(SPContant.PLAY_30, ToolUtil.getCurrentDate());
                            } else {
                                ToastUtils.show("分享成功，+" + gold + " 金币");
                            }
                        } else {

                        }
                    }
                });
    }


    //增加经验
    private void addExp() {
        long pos = detailPlayer.getCurrentPositionWhenPlaying() / 1000;
        if (pos > 0 || (pos == 0 && detailPlayer.isComplete)) {
            addExp("play_vod");
        }
    }

    //增加经验
    private void addExp(String type) {
        Kalle.get(HttpUrl.ADD_EXP)
                .tag(tag)
                .param("rule_code", type)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            SPUtils.getInstance().put(SPContant.LOGIN_SUC, ToolUtil.getCurrentDate());
                            String bi = FastJsonUtil.toString(response.succeed(), "experience_num");
//                            ToastUtils.show("登录成功,+" + bi + " 经验值");
                        } else {

                        }
                    }
                });
        addRule();
    }

    //点击广告奖励金币接口
    private void addRule() {
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", 4)
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            ToastUtils.show("点击广告，+" + gold + " 金币");
                        } else {
                        }
                    }
                });
    }


    //顶部广告
    private void getAd1() {
        Kalle.post(HttpUrl.GET_AD)
                .tag(tag)
                .param("position_code", "personal")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            adUrl1 = FastJsonUtil.toString(response.succeed(), "advert_url");
                            if (!TextUtils.isEmpty(adUrl1)) {
                                ivAd1.setVisibility(View.VISIBLE);
                                adImg1 = FastJsonUtil.toString(response.succeed(), "advert_img");
                                adTitle1 = FastJsonUtil.toString(response.succeed(), "advert_name");
                                PicassoUtils.LoadImageWithDetfult(getMActivity(), adImg1, ivAd1, R.drawable.pic_emptypage_failure);
                            }
                        } else {
                        }
                    }
                });
    }

    //底部广告
    private void getAd() {
        Kalle.post(HttpUrl.GET_AD)
                .tag(tag)
                .param("position_code", "vod_comment")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            adUrl = FastJsonUtil.toString(response.succeed(), "advert_url");
                            if (!TextUtils.isEmpty(adUrl)) {
                                adImg = FastJsonUtil.toString(response.succeed(), "advert_img");

                                adTitle = FastJsonUtil.toString(response.succeed(), "advert_name");
                                ivAd2.setVisibility(View.VISIBLE);
                                PicassoUtils.LoadImageWithDetfult(getMActivity(), adImg, ivAd2, R.drawable.pic_emptypage_failure);
                                ivAd2.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                                        ArrayMap<String, Object> map = new ArrayMap<>();
                                        map.put("url", adUrl);
                                        map.put("title", adTitle);
                                        startActivity(WebViewActivity.class, map);
                                        addExp("play_advert");
                                    }
                                });

                            }

                        } else {

                        }
                    }
                });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_movie_detail;
    }

    @Override
    public void reload() {
        requestData();
    }

    private class XuanjiAdapter extends BaseQuickAdapter<DetailInfo.SourceContentBean, BaseViewHolder> {

        public XuanjiAdapter(@Nullable List<DetailInfo.SourceContentBean> data) {
            super(R.layout.item_xuanji, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, DetailInfo.SourceContentBean item) {
            if (item.isCheck()) {
                helper.setChecked(R.id.rb_xuanji, true);
            } else {
                helper.setChecked(R.id.rb_xuanji, false);
            }
            helper.setText(R.id.rb_xuanji, item.getPlay_title());
        }
    }

    private class TypeAdapter extends BaseQuickAdapter<DetailInfo.TypeBean, BaseViewHolder> {

        public TypeAdapter(@Nullable List<DetailInfo.TypeBean> data) {
            super(R.layout.item_type, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, DetailInfo.TypeBean item) {
            helper.setText(R.id.tv_type, item.getType_name());
        }
    }

    private class LikeAdapter extends BaseQuickAdapter<DetailLikeInfo, BaseViewHolder> {

        public LikeAdapter(@Nullable List<DetailLikeInfo> data) {
            super(R.layout.include_list_xiao, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, DetailLikeInfo item) {
            int margin = MovieDetailActivity.this.getResources().getDimensionPixelOffset(R.dimen.dp_6);
            int widthPix = ScreenUtils.getScreenWidth();
            int width = (widthPix - (margin * 2)) / 3;
            int height = width / 2 * 3;
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(width, height);


            ImageView ivImg = helper.getView(R.id.iv_small);
            ivImg.setLayoutParams(params);
            helper.itemView.setLayoutParams(new RelativeLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT));
            PicassoUtils.LoadImageWithDetfult(MovieDetailActivity.this, item.getSource_img(), ivImg, R.drawable.pic_emptypage_failure);
            RelativeLayout layout = helper.getView(R.id.layout);
            layout.setLayoutParams(new LinearLayout.LayoutParams(width, height));
            if (TextUtils.isEmpty(item.getUp_right_text())) {
                helper.setGone(R.id.tv_tag, false);
            } else {
                helper.setVisible(R.id.tv_tag, true);
                helper.setText(R.id.tv_tag, item.getUp_right_text());
            }
            helper.setText(R.id.tv_small_title, item.getSource_name())
                    .setText(R.id.tv_small_content, item.getDescription());
            if (TextUtils.isEmpty(item.getDown_right_text())) {
                helper.setGone(R.id.tv_small_bottom, false);
            } else {
                helper.setVisible(R.id.tv_small_bottom, true);
                helper.setText(R.id.tv_small_bottom, item.getDown_right_text())
                        .setTextColor(R.id.tv_small_bottom, MovieDetailActivity.this.getResources().getColor(R.color.color_ff5722));
            }
        }
    }

    private class ReviewAdapter extends BaseMultiItemQuickAdapter<MovieReviewInfo, BaseViewHolder> {

        public ReviewAdapter(@Nullable List<MovieReviewInfo> data) {
            super(data);
            addItemType(0, R.layout.item_detail_review);
            addItemType(1, R.layout.item_review_ad);
        }

        @Override
        protected void convert(BaseViewHolder helper, MovieReviewInfo item) {
            if (helper.getItemViewType() == 0) {
                RoundImageView ivImg = helper.getView(R.id.iv_head);
                PicassoUtils.LoadImageWithDetfult(MovieDetailActivity.this, item.getAvatar(), ivImg, R.drawable.avatar);
                helper.setText(R.id.tv_name1, item.getSend_user_name())
                        .setText(R.id.tv_date1, item.getUpdate_time())
                        .setText(R.id.tv_review, item.getComments())
                        .setText(R.id.tv_zan, item.getTop_num() + "")
                        .addOnClickListener(R.id.tv_zan);
                TextView tvZan = helper.getView(R.id.tv_zan);
                if (item.getIs_top() == 1) {
                    tvZan.setCompoundDrawablesWithIntrinsicBounds(R.drawable.zan1, 0, 0, 0);
                } else {
                    tvZan.setCompoundDrawablesWithIntrinsicBounds(R.drawable.zan, 0, 0, 0);
                }
                helper.getView(R.id.tv_reply).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                        dialogReview = new XPopup.Builder(getMActivity())
                                .moveUpToKeyboard(false)
                                .asCustom(new ReviewReplyDialog(getMActivity(), item))
                                .show();
                    }
                });
            } else {
                ImageView ivAd = helper.getView(R.id.iv_ad);
                PicassoUtils.LoadImageWithDetfult(MovieDetailActivity.this, item.getAdvert_img(), ivAd, R.drawable.pic_emptypage_failure);

                ivAd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (OnDoubleClickListener.CanClick.NoClick()) return;
                        adImg = item.getAdvert_img();
                        adUrl = item.getAdvert_url();
                        adTitle = item.getAdvert_name();

                        ArrayMap<String, Object> map = new ArrayMap<>();
                        map.put("url", adUrl);
                        map.put("title", adTitle);
                        startActivity(WebViewActivity.class, map);
                        addExp("play_advert");
                    }
                });
            }

        }
    }

    private void ainit() {
        db = x.getDb(((App) getApplicationContext()).getDaoConfig());
    }

    private void saveVieoRecord(String id, String source_name, String source_img, String played_time, String total_time) {
        try {
            db.delete(Record.class, WhereBuilder.b("ids", "=", id));
        } catch (DbException e) {
            e.printStackTrace();
        }

        Record first = null;
        try {
            first = db.selector(Record.class).where("ids", "=", id).findFirst();
        } catch (DbException e) {
            e.printStackTrace();
        }

        if (first == null) {
            Record account = new Record();
            account.setIds(id);
            account.setSource_name(source_name);
            account.setSource_img(source_img);
            account.setPlayed_time(played_time);
            account.setTotal_time(total_time);
            try {
                db.save(account);
            } catch (DbException e) {
                e.printStackTrace();
            }
        }
    }
}
