package com.movie58.newdemand.base;

public class AppConfig {

    public static final boolean Debug = true;
}
