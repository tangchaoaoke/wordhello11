package com.movie58.my;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.movie58.R;
import com.movie58.base.BaseActivity;

/**
 * Created by yangxing on 2019/5/7 0007.
 */
public class SettingActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        if (savedInstanceState == null) {
            loadRootFragment(R.id.container, SettingFragment.newInstance());
        }
    }
}
