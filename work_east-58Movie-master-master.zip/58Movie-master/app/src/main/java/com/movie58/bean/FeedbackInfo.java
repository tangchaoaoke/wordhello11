package com.movie58.bean;

import java.util.List;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class FeedbackInfo {
    /**
     * back_content : 考虑考虑
     * back_type_name : 无法投屏
     * qq : 999955
     * email :
     * create_time : 2019-05-21 15:22:47
     * source_name : null
     * id : 4
     * reply_content : [{"back_content":"再去辽阔的个快递费考虑过快递费考虑过","admin_name":"58app","create_time":"2019-05-23 10:58:32","qq":"","email":""}]
     */

    private String back_content;
    private String back_type_name;
    private String qq;
    private String email;
    private String create_time;
    private String source_name;
    private int id;
    private List<ReplyContentBean> reply_content;

    public String getBack_content() {
        return back_content;
    }

    public void setBack_content(String back_content) {
        this.back_content = back_content;
    }

    public String getBack_type_name() {
        return back_type_name;
    }

    public void setBack_type_name(String back_type_name) {
        this.back_type_name = back_type_name;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<ReplyContentBean> getReply_content() {
        return reply_content;
    }

    public void setReply_content(List<ReplyContentBean> reply_content) {
        this.reply_content = reply_content;
    }

    public static class ReplyContentBean {
        /**
         * back_content : 再去辽阔的个快递费考虑过快递费考虑过
         * admin_name : 58app
         * create_time : 2019-05-23 10:58:32
         * qq :
         * email :
         */

        private String back_content;
        private String admin_name;
        private String create_time;
        private String qq;
        private String email;

        public String getBack_content() {
            return back_content;
        }

        public void setBack_content(String back_content) {
            this.back_content = back_content;
        }

        public String getAdmin_name() {
            return admin_name;
        }

        public void setAdmin_name(String admin_name) {
            this.admin_name = admin_name;
        }

        public String getCreate_time() {
            return create_time;
        }

        public void setCreate_time(String create_time) {
            this.create_time = create_time;
        }

        public String getQq() {
            return qq;
        }

        public void setQq(String qq) {
            this.qq = qq;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }
}
