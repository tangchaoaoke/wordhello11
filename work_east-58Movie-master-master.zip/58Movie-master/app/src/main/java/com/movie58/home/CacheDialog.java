package com.movie58.home;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.allen.library.SuperButton;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hjq.toast.ToastUtils;
import com.lxj.xpopup.core.BottomPopupView;
import com.lxj.xpopup.util.XPopupUtils;
import com.movie58.R;
import com.movie58.bean.DownloadInfo;
import com.movie58.my.CacheActivity;
import com.movie58.util.ToolUtil;
import com.orhanobut.logger.Logger;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.download.Callback;
import com.yanzhenjie.kalle.download.Download;
import com.yqritc.recyclerviewflexibledivider.FlexibleDividerDecoration;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;
import com.yqritc.recyclerviewflexibledivider.VerticalDividerItemDecoration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangxing on 2019/8/7 0007.
 */
public class CacheDialog extends BottomPopupView {

    ImageView ivClose;
    TextView tvCount;
    RecyclerView rvList;
    SuperButton btnAll;
    SuperButton btnGo;

    List<DownloadInfo> list = new ArrayList<>();
    String strCatName;
    Context ctx;

    public CacheDialog(@NonNull Context context, List<DownloadInfo> list, String catName) {
        super(context);
        ctx = context;
        this.list = list;
        strCatName = catName;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_cache;
    }

    @Override
    protected void onCreate() {
        super.onCreate();

        ivClose = findViewById(R.id.iv_close);
        tvCount = findViewById(R.id.tv_count);
        rvList = findViewById(R.id.rv_list);
        btnAll = findViewById(R.id.btn_all);
        btnGo = findViewById(R.id.btn_go);

//        if (detailInfo.getUpdate_schedule() == 1) {
//            if ("综艺".equals(detailInfo.getCat_name())) {
//                tvCount.setText("已完结"+ detailInfo.getSource_content().size() + "期");
//            }else{
//                tvCount.setText("已完结"+ detailInfo.getSource_content().size() + "集");
//            }
//
//        }else{
//            if ("综艺".equals(detailInfo.getCat_name())) {
//                tvCount.setText("更新至" + detailInfo.getSource_content().get(detailInfo.getSource_content().size() - 1).getPlay_title());
//            }else{
//                tvCount.setText("更新至" + detailInfo.getSource_content().get(detailInfo.getSource_content().size() - 1).getPlay_title() + "集");
//            }
//        }

        XuanjiAdapter mAdapter = new XuanjiAdapter(list);
        if ("电视剧".equals(strCatName)) {
            rvList.setLayoutManager(new GridLayoutManager(getContext(), 4));
        }else{
            rvList.setLayoutManager(new GridLayoutManager(getContext(), 2));
        }
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getContext())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getContext().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        rvList.addItemDecoration(new VerticalDividerItemDecoration.Builder(getContext())
                .colorResId(R.color.white)
                .sizeProvider(new FlexibleDividerDecoration.SizeProvider() {
                    @Override
                    public int dividerSize(int position, RecyclerView parent) {
                        return getContext().getResources().getDimensionPixelSize(R.dimen.dp_8);
                    }
                }).build());
        mAdapter.bindToRecyclerView(rvList);

        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                if (view.getId() == R.id.rb_download) {
                    if (!TextUtils.isEmpty(mAdapter.getItem(position).getUrl())
                            && (mAdapter.getItem(position).getUrl().contains(".mp4") || mAdapter.getItem(position).getUrl().contains(".MP4"))) {
                        mAdapter.getItem(position).setCheck(!mAdapter.getItem(position).isCheck());
                        mAdapter.notifyDataSetChanged();
                    }else{
                        ToastUtils.show("该资源下载链接已失效");
                    }

                }
            }
        });

        ivClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        btnGo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                List<DownloadInfo> list1 = new ArrayList<>();
                for(DownloadInfo info : mAdapter.getData()){
                    if (info.isCheck()) {
                        list1.add(info);
                    }
                }

                Intent intent = new Intent(ctx, CacheActivity.class);
                intent.putExtra("cache", (Serializable) list1);
                ctx.startActivity(intent);
            }
        });

        btnAll.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void download(String url){
        Kalle.Download.get(url).directory(ToolUtil.getAppRootPath(ctx))
                .onProgress(new Download.ProgressBar() {
                    @Override
                    public void onProgress(int progress, long byteCount, long speed) {
                        Logger.d(" prgress = " + progress + " count = " + byteCount + " speed = " + speed);
                    }
                })
                .perform(new Callback() {
                    @Override
                    public void onStart() {
                        Logger.d(".........start");
                    }

                    @Override
                    public void onFinish(String path) {
                        Logger.d("finish = " + path);
                    }

                    @Override
                    public void onException(Exception e) {
                        Logger.d(e.getMessage());
                    }

                    @Override
                    public void onCancel() {
                        Logger.d(".........cancel");
                    }

                    @Override
                    public void onEnd() {
                        Logger.d(".........end");
                    }
                });
    }


    @Override
    protected int getMaxHeight() {
        return (int) (XPopupUtils.getWindowHeight(getContext())*.60f);
    }

    private class XuanjiAdapter extends BaseQuickAdapter<DownloadInfo, BaseViewHolder> {

        public XuanjiAdapter(@Nullable List<DownloadInfo> data) {
            super(R.layout.item_download, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, DownloadInfo item) {
            if (item.isCheck()) {
                helper.setTextColor(R.id.rb_download, mContext.getResources().getColor(R.color.color_base));
                helper.setGone(R.id.iv_download, true);
            }else{
                helper.setTextColor(R.id.rb_download, mContext.getResources().getColor(R.color.color_323233));
                helper.setGone(R.id.iv_download, false);
            }
            helper.setText(R.id.rb_download, item.getTitle());
            helper.addOnClickListener(R.id.rb_download);
        }
    }
}
