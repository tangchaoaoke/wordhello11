package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/27 0027.
 */
public class LevelUpInfo {
    /**
     * id : 23
     * rule_id : 1
     * rule_name : 每日登录
     * experience_num : 10
     * create_time : 2019-05-27 09:43:28
     * user_id : 8
     * update_time : 1558921408
     */

    private int id;
    private int rule_id;
    private String rule_name;
    private int experience_num;
    private String create_time;
    private int user_id;
    private int update_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRule_id() {
        return rule_id;
    }

    public void setRule_id(int rule_id) {
        this.rule_id = rule_id;
    }

    public String getRule_name() {
        return rule_name;
    }

    public void setRule_name(String rule_name) {
        this.rule_name = rule_name;
    }

    public int getExperience_num() {
        return experience_num;
    }

    public void setExperience_num(int experience_num) {
        this.experience_num = experience_num;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }
}
