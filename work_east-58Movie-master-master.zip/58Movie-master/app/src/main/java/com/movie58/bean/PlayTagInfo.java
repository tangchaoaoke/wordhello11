package com.movie58.bean;

/**
 * Created by yangxing on 2019/5/25 0025.
 */
public class PlayTagInfo {

    /**
     * id : 23
     * vod_id : 144
     * user_id : 8
     * played_time : 87640
     * play_anthology : 0
     * create_time : 2019-05-25 15:37:54
     * update_time : 2019-05-25 15:48:10
     * total_time : 1226800
     * source_name : 雪鹰领主
     * source_img : https://tupian.tupianzy.com/pic/upload/vod/2018-12-20/201812201545275863.jpg
     */

    private int id;
    private String vod_id;
    private int user_id;
    private int played_time;
    private String play_anthology;
    private int total_time;
    private String source_name;
    private String source_img;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVod_id() {
        return vod_id;
    }

    public void setVod_id(String vod_id) {
        this.vod_id = vod_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getPlayed_time() {
        return played_time;
    }

    public void setPlayed_time(int played_time) {
        this.played_time = played_time;
    }

    public String getPlay_anthology() {
        return play_anthology;
    }

    public void setPlay_anthology(String play_anthology) {
        this.play_anthology = play_anthology;
    }

    public int getTotal_time() {
        return total_time;
    }

    public void setTotal_time(int total_time) {
        this.total_time = total_time;
    }

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    public String getSource_img() {
        return source_img;
    }

    public void setSource_img(String source_img) {
        this.source_img = source_img;
    }
}
