package com.movie58.home;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;

import com.blankj.utilcode.util.SPUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.hjq.toast.ToastUtils;
import com.movie58.R;
import com.movie58.newdemand.view.LoadingTip;
import com.movie58.activity.WebViewActivity;
import com.movie58.adapter.MovieAdapter;
import com.movie58.base.BaseFragment;
import com.movie58.bean.HomeListInfo;
import com.movie58.bean.MovieListInfo;
import com.movie58.event.Event;
import com.movie58.http.HttpUrl;
import com.movie58.http.LoadingCallback;
import com.movie58.http.NormalCallback;
import com.movie58.util.FastJsonUtil;
import com.movie58.util.OnDoubleClickListener;
import com.movie58.util.SPContant;
import com.movie58.util.ToolUtil;
import com.movie58.view.WrapContentLinearLayoutManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yanzhenjie.kalle.FormBody;
import com.yanzhenjie.kalle.Kalle;
import com.yanzhenjie.kalle.simple.SimpleResponse;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * Created by yangxing on 2019/4/26 0026.
 */
public class MovieFragment extends BaseFragment implements LoadingTip.onReloadListener {

    @BindView(R.id.rv_list2)
    RecyclerView rvList;
    @BindView(R.id.layout_refresh2)
    SmartRefreshLayout layoutRefresh;
    @BindView(R.id.loadedTip)
    LoadingTip loadedTip;

    MovieAdapter mAdapter;
    int page = 1;
    int catId;
    private String sourceId;
    int selPostion, selPage = 1;  //selPostion 大列表分组的下标   selpage 每个分组换一批的page
    String sourceType, sourceTag;

    public static MovieFragment newInstance(int id) {
        MovieFragment fragment = new MovieFragment();
        Bundle b = new Bundle();
        b.putInt("id", id);
        fragment.setArguments(b);
        return fragment;
    }


    @Override
    protected void getIntentExtra() {
        Bundle b = getArguments();
        catId = b.getInt("id");
    }

    @Override
    protected void initView() {
        mAdapter = new MovieAdapter(new ArrayList<>(), catId);
        rvList.setLayoutManager(new WrapContentLinearLayoutManager(getMActivity()));
        rvList.addItemDecoration(new HorizontalDividerItemDecoration.Builder(getMActivity()).build());
        mAdapter.bindToRecyclerView(rvList);

        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {

            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                if (OnDoubleClickListener.CanClick.NoClick()) return;
                HomeListInfo info = mAdapter.getItem(position);

                switch (view.getId()) {
                    case R.id.tv_more:
                        ArrayMap<String, Object> map = new ArrayMap<>();
                        map.put("catid", info.getMore_params().getCat_id());
                        map.put("type", info.getMore_params().getSource_type());
                        map.put("tag", info.getMore_params().getSource_tag());
                        map.put("title", info.getParams().getTitle());
                        startActivity(MovieMoreActivity.class, map);
                        break;
                    case R.id.tv_refresh:
                        sourceTag = info.getMore_params().getSource_tag();
                        sourceType = info.getMore_params().getSource_type();
                        sourceId = info.getMore_params().getCat_id();
                        if (selPostion == position) {
                            selPage++;
                        } else {
                            selPostion = position;
                            selPage = 1;
                        }
                        int size = 1;
                        switch (mAdapter.getItem(position).getWidget_name()) {
                            case "one_image":
                                size = 1;
                                break;
                            case "two_vod":
                                size = 2;
                                break;
                            case "three_vod":
                                size = 3;
                                break;
                            case "four_vod":
                                size = 4;
                                break;
                            case "five_vod":
                                size = 4;
                                break;
                            case "six_vod":
                                size = 6;
                                break;
                            case "seven_vod":
                                size = 6;
                                break;
                            default:
                                break;
                        }
                        change(size);
                        break;
                    default:
                        break;
                }
            }
        });
        layoutRefresh.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                page++;
                getList();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                getList();
            }
        });
    }

    @Override
    protected void initData() {
//        if (mAdapter.getData().isEmpty()) {
//            layoutRefresh.autoRefresh();
//        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        requestData();
        loadedTip.setOnReloadListener(this);
    }

    public void requestData() {
        loadedTip.setLoadingTip(LoadingTip.LoadStatus.loading);
        getList();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(Event event) {
        switch (event.getEvent()) {
            case Event.CODE_06_SCHOOL_PROFRESS:
                HomeListInfo.ParamsBean.ListBean bean = (HomeListInfo.ParamsBean.ListBean) event.getObj2();
                if ("1".equals(bean.getIs_advert())) {
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    map.put("url", bean.getImg_link());
                    map.put("title", bean.getImg_title());
                    startActivity(WebViewActivity.class, map);
                    addExp();
                } else {
                    int id = (int) event.getObj1();
                    if (catId == id) {
                        String strId = bean.getVod_id();
                        ArrayMap<String, Object> map = new ArrayMap<>();
                        map.put("id", strId);
                        startActivity(MovieDetailActivity.class, map);
                    }
                }
//                }else{
//                    ToastUtils.show("请先登录");
//                    startActivity(LoginActivity.class);
//                }
                break;
            default:
                break;
        }
    }

    private void getList() {
        Kalle.post(HttpUrl.HOME_LIST)
                .tag(tag + catId)
                .param("cat_id", catId)
                .param("page", page)
                .param("size", 10)
                .perform(new NormalCallback<List<HomeListInfo>>() {
                    @Override
                    public void onFinaly(SimpleResponse<List<HomeListInfo>, String> response) {
                        loadedTip.setLoadingTip(LoadingTip.LoadStatus.finish);

                        try {
                            if (response.isSucceed()) {
                                initList(response.succeed());
                            } else {
                                ToastUtils.show(response.failed());
                                layoutRefresh.finishRefresh();
                                layoutRefresh.finishLoadMore();
                            }
                        } catch (Exception e) {

                        }

                    }

                    @Override
                    public void onFinnalyException() {
                        if (mAdapter.getData().isEmpty()) {
                            loadedTip.setLoadingTip(LoadingTip.LoadStatus.error);
                        } else {
                            loadedTip.setLoadingTip(LoadingTip.LoadStatus.finish);
                        }
                    }
                });
    }

    private void initList(List<HomeListInfo> list) {
        if (list == null) {
            list = new ArrayList<>();
        }

        for (HomeListInfo info : list) {
            switch (info.getWidget_name()) {
                case "rotation_chart":
                    info.setType(MovieAdapter.TYPE_BANNER);
                    break;
                case "center_nav":
                    info.setType(MovieAdapter.TYPE_CENTER);
                    break;
                case "one_image":
                    info.setType(MovieAdapter.TYPE_1);
                    break;
                case "two_vod":
                    info.setType(MovieAdapter.TYPE_2);
                    break;
                case "three_vod":
                    info.setType(MovieAdapter.TYPE_3);
                    break;
                case "four_vod":
                    info.setType(MovieAdapter.TYPE_4);
                    break;
                case "five_vod":
                    info.setType(MovieAdapter.TYPE_5);
                    break;
                case "six_vod":
                    info.setType(MovieAdapter.TYPE_6);
                    break;
                case "seven_vod":
                    info.setType(MovieAdapter.TYPE_7);
                    break;
                default:
                    break;
            }
        }

        if (page == 1) {
            if (list.isEmpty()) {
                mAdapter.setNewData(null);
                mAdapter.setEmptyView(LayoutInflater.from(getMActivity()).inflate(R.layout.empty_view, null));
            } else {
                mAdapter.setNewData(list);
            }
        } else {
            mAdapter.addData(list);
        }
        layoutRefresh.finishRefresh();
        layoutRefresh.finishLoadMore();
        if (list.isEmpty()) {
            layoutRefresh.setEnableLoadMore(false);
        } else {
            layoutRefresh.setEnableLoadMore(true);
        }

    }

    private void change(int size) {
        FormBody.Builder builder = FormBody.newBuilder();
        builder.param("cat_id", sourceId)
                .param("page", selPage)
                .param("size", size)
                .param("is_more", false);
        if (!TextUtils.isEmpty(sourceTag)) {
            builder.param("source_tag", sourceTag);
        }
        if (!TextUtils.isEmpty(sourceType)) {
            builder.param("source_type", sourceType);
        }
        Kalle.post(HttpUrl.CHANGE_MORE)
                .tag(tag + catId)
                .body(builder.build())
                .perform(new LoadingCallback<List<MovieListInfo>>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<List<MovieListInfo>, String> response) {
                        if (response.isSucceed()) {
                            initChange(response.succeed());
                        } else {
                            ToastUtils.show(response.failed());
                        }
                    }
                });
    }

    private void initChange(List<MovieListInfo> list) {
        if (list == null || list.isEmpty()) {
            ToastUtils.show("没有更多");
        } else {
            List<HomeListInfo.ParamsBean.ListBean> list2 = new ArrayList<>();
            List<HomeListInfo.ParamsBean.ListBean> list1 = mAdapter.getItem(selPostion).getParams().getList();
            if (mAdapter.getItem(selPostion).getItemType() == MovieAdapter.TYPE_5
                    || mAdapter.getItem(selPostion).getItemType() == MovieAdapter.TYPE_7) {
                list2.add(list1.get(0));
            }
            list1.clear();
            for (MovieListInfo info : list) {
                HomeListInfo.ParamsBean.ListBean bean = new HomeListInfo.ParamsBean.ListBean();
                bean.setDescription(info.getDescription());
                bean.setDown_right_text(info.getDown_right_text());
                bean.setImg_link(info.getImg_link());
                bean.setImg_title(info.getSource_name());
                bean.setImg_url(info.getSource_img());
                bean.setLead_role(info.getLead_role());
                bean.setPingfen(info.getPingfen());
                bean.setUp_right_text(info.getUp_right_text());
                bean.setVod_id(info.getId());
                bean.setVod_name(info.getSource_name());
                list2.add(bean);
            }
            list1.addAll(list2);
            mAdapter.notifyDataSetChanged();

        }
    }

    private void addExp() {
        Kalle.get(HttpUrl.ADD_EXP)
                .tag(tag)
                .param("rule_code", "play_advert")
                .perform(new NormalCallback<String>() {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            SPUtils.getInstance().put(SPContant.LOGIN_SUC, ToolUtil.getCurrentDate());
                            String bi = FastJsonUtil.toString(response.succeed(), "experience_num");
//                            ToastUtils.show("登录成功,+" + bi + " 经验值");
                        } else {

                        }
                    }
                });
        addRule();
    }

    private void addRule() {
        Kalle.get(HttpUrl.RULE_REWARD)
                .param("rule_id", 4)
                .perform(new LoadingCallback<String>(getMActivity()) {
                    @Override
                    public void onFinaly(SimpleResponse<String, String> response) {
                        if (response.isSucceed()) {
                            String gold = FastJsonUtil.toString(response.succeed(), "gold_num");
                            ToastUtils.show("点击广告，+" + gold + " 金币");

                        } else {

                        }
                    }
                });
    }

    @Override
    public void onDestroyView() {
        Kalle.cancel(tag + catId);
        super.onDestroyView();
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_movie;
    }

    @Override
    public void reload() {
        requestData();
    }
}
